import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, normalize, extname, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AppError } from './booking.js';
import { json, readBody } from './core.js';
import { registerPublic, publicOrg } from './routes-public.js';
import { registerPro } from './routes-pro.js';
import { registerAdmin } from './routes-admin.js';
import { seo } from './seo.js';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json' };

const SEC = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com 'unsafe-inline'; font-src https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()', ...(process.env.NODE_ENV === 'production' ? { 'Strict-Transport-Security': 'max-age=63072000; includeSubDomains' } : {}),
};

// Supervision : chaque erreur 500 est ecrite sur stderr (JSON) et, si ERROR_WEBHOOK_URL est defini, envoyee a votre outil (Slack, Sentry-compatible, etc.)
function reportError(e, req) {
  const body = { level: 'error', message: String(e?.message), stack: String(e?.stack || '').split('\n').slice(0, 6).join('\n'), path: req.url, method: req.method, ts: new Date().toISOString() };
  console.error(JSON.stringify(body));
  if (process.env.ERROR_WEBHOOK_URL) fetch(process.env.ERROR_WEBHOOK_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: `RENDEZVOO ${body.method} ${body.path}: ${body.message}`, ...body }) }).catch(() => {});
}
export function createApp(db) {
  const routes = [];
  const add = (method) => (path, fn) => {
    const keys = []; const re = new RegExp('^' + path.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method: method.toUpperCase(), re, keys, fn });
  };
  const r = { get: add('GET'), post: add('POST'), put: add('PUT'), patch: add('PATCH'), delete: add('DELETE') };
  registerPublic(r, db); registerPro(r, db); registerAdmin(r, db);
  r.get('/healthz', (c) => json(c.res, 200, { ok: true, db: !!db.prepare('SELECT 1 x').get() }));
  const seoHandler = seo(db, publicOrg);

  return async function handler(req, res) {
    for (const [k, v] of Object.entries(SEC)) res.setHeader(k, v);
    const url = new URL(req.url, 'http://x'); const path = decodeURIComponent(url.pathname);
    try {
      if (path.startsWith('/api/') || path === '/healthz') {
        if (!['GET', 'HEAD'].includes(req.method)) {   // defense CSRF : meme origine + JSON obligatoires
          const origin = req.headers.origin; if (origin && new URL(origin).host !== req.headers.host) throw new AppError('bad_origin', 403);
          if (!String(req.headers['content-type'] || '').startsWith('application/json') && Number(req.headers['content-length'] || 0) > 0) throw new AppError('json_required', 415);
        }
        const route = routes.find(x => x.method === (req.method === 'HEAD' ? 'GET' : req.method) && x.re.test(path));
        if (!route) throw new AppError('not_found', 404);
        const m = path.match(route.re); const params = Object.fromEntries(route.keys.map((k, i) => [k, m[i + 1]]));
        const body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readBody(req) : {};
        return await route.fn({ req, res, params, body, query: Object.fromEntries(url.searchParams) });
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new AppError('not_found', 404);
      if (await seoHandler(req, res, path, url)) return;
      return serveStatic(req, res, path);
    } catch (e) {
      if (e instanceof AppError) return json(res, e.status, { error: e.code, ...(e.extra || {}) });
      console.error(e); reportError(e, req); if (!res.headersSent) json(res, 500, { error: 'server_error' }); else res.end();
    }
  };
}

function serveStatic(req, res, path) {
  const pages = { '/': '/index.html', '/login': '/login.html', '/inscription': '/login.html', '/reset': '/login.html', '/app': '/app.html', '/admin': '/admin.html', '/tarifs': '/index.html' };
  let rel = pages[path] || path; const file = normalize(join(ROOT, rel));
  if (!file.startsWith(ROOT) || !existsSync(file) || !statSync(file).isFile()) {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(readFileSync(join(ROOT, '404.html')));
  }
  const ext = extname(file); const data = readFileSync(file);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' || path === '/sw.js' || ext === '.webmanifest' ? 'no-cache' : 'public, max-age=3600', ...(path === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {}) });
  res.end(req.method === 'HEAD' ? undefined : data);
}
