import { randomBytes } from 'node:crypto';
import { tx } from './db.js';
import { zonedToUtcMs, weekdayOf, localDate, localTime, isDate } from './time.js';
import { queueForBooking, cancelPendingReminders } from './notify.js';

export class AppError extends Error {
  constructor(code, status = 400, extra) { super(code); this.code = code; this.status = status; this.extra = extra; }
}
const STEP = 15 * 60e3;

export function availableSlots(db, orgId, serviceId, date, staffId = null, { ignoreNotice = false, excludeBooking = 0 } = {}) {
  if (!isDate(date)) throw new AppError('invalid_date');
  const org = db.prepare('SELECT * FROM orgs WHERE id=? AND suspended=0').get(orgId);
  const svc = db.prepare('SELECT * FROM services WHERE id=? AND org_id=? AND active=1').get(serviceId, orgId);
  if (!org || !svc) return [];
  const earliest = Date.now() + (ignoreNotice ? 0 : org.min_notice_min * 60e3);
  const wd = weekdayOf(date);
  const staffRows = db.prepare(`SELECT s.id FROM staff s JOIN staff_services ss ON ss.staff_id=s.id AND ss.service_id=?
    WHERE s.org_id=? AND s.active=1 ${staffId ? 'AND s.id=?' : ''} ORDER BY s.id`).all(...(staffId ? [serviceId, orgId, staffId] : [serviceId, orgId]));
  const out = [];
  for (const { id: sid } of staffRows) {
    const hours = db.prepare('SELECT start,end FROM working_hours WHERE staff_id=? AND weekday=? ORDER BY start').all(sid, wd);
    if (!hours.length) continue;
    const dayStart = zonedToUtcMs(date, '00:00', org.timezone), dayEnd = dayStart + 36 * 3600e3;
    const busy = db.prepare(`SELECT start_ms s, occ_end_ms e FROM bookings WHERE staff_id=? AND id<>? AND status IN ('pending','confirmed') AND start_ms<? AND occ_end_ms>?
      UNION ALL SELECT start_ms, end_ms FROM time_off WHERE staff_id=? AND start_ms<? AND end_ms>?`).all(sid, excludeBooking, dayEnd, dayStart, sid, dayEnd, dayStart);
    for (const h of hours) {
      const ws = zonedToUtcMs(date, h.start, org.timezone), we = zonedToUtcMs(date, h.end, org.timezone);
      for (let st = ws; st + svc.duration_min * 60e3 <= we; st += STEP) {
        const en = st + svc.duration_min * 60e3, occ = en + svc.buffer_min * 60e3;
        if (st < earliest) continue;
        if (busy.some(b => b.s < occ && st < b.e)) continue;
        out.push({ staff_id: sid, start_ms: st, end_ms: en });
      }
    }
  }
  return out.sort((a, b) => a.start_ms - b.start_ms || a.staff_id - b.staff_id);
}

export function normPhone(p) { return String(p || '').replace(/[^\d+]/g, ''); }

export function createBooking(db, o) {
  const name = String(o.name || '').trim(), phone = normPhone(o.phone);
  if (name.length < 2 || name.length > 80) throw new AppError('invalid_name');
  if (!/^\+?\d{6,15}$/.test(phone)) throw new AppError('invalid_phone');
  const email = String(o.email || '').trim().slice(0, 120);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new AppError('invalid_email');
  const notes = String(o.notes || '').slice(0, 500);
  const booking = tx(db, () => {
    const org = db.prepare('SELECT * FROM orgs WHERE id=?').get(o.orgId);
    if (!org || org.suspended) throw new AppError('org_unavailable', 404);
    const sub = db.prepare('SELECT * FROM subscriptions WHERE org_id=?').get(o.orgId);
    if (!sub || sub.status === 'cancelled' || (sub.status === 'trialing' && sub.trial_ends_ms < Date.now()))
      throw new AppError('subscription_inactive', 403);
    const svc = db.prepare('SELECT * FROM services WHERE id=? AND org_id=? AND active=1').get(o.serviceId, o.orgId);
    if (!svc) throw new AppError('service_not_found', 404);
    const manual = o.source === 'manual';
    let staffId = o.staffId ? Number(o.staffId) : null;
    if (!manual) {
      const date = localDate(o.startMs, org.timezone);
      const slots = availableSlots(db, o.orgId, o.serviceId, date, staffId).filter(s => s.start_ms === o.startMs);
      if (!slots.length) throw new AppError('slot_unavailable', 409);
      staffId = slots[0].staff_id;
    } else {
      if (!staffId) throw new AppError('staff_required');
      const st = db.prepare('SELECT 1 FROM staff WHERE id=? AND org_id=?').get(staffId, o.orgId);
      if (!st) throw new AppError('staff_not_found', 404);
    }
    const endMs = o.startMs + svc.duration_min * 60e3, occ = endMs + svc.buffer_min * 60e3;
    db.prepare('INSERT OR IGNORE INTO customers(org_id,name,phone,email,created_at) VALUES (?,?,?,?,?)').run(o.orgId, name, phone, email, Date.now());
    const cust = db.prepare('SELECT id FROM customers WHERE org_id=? AND phone=?').get(o.orgId, phone);
    if (email) db.prepare("UPDATE customers SET email=? WHERE id=? AND email=''").run(email, cust.id);
    let id;
    try {
      id = db.prepare(`INSERT INTO bookings(org_id,staff_id,service_id,customer_id,start_ms,end_ms,occ_end_ms,price,status,token,notes,source,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(o.orgId, staffId, svc.id, cust.id, o.startMs, endMs, occ, svc.price, 'confirmed',
        randomBytes(16).toString('hex'), notes, manual ? 'manual' : 'online', Date.now()).lastInsertRowid;
    } catch (e) { if (/slot_unavailable/.test(e.message)) throw new AppError('slot_unavailable', 409); throw e; }
    db.prepare('INSERT INTO logs(org_id,actor,action,detail,ts) VALUES (?,?,?,?,?)').run(o.orgId, o.actor || null, 'booking.created', JSON.stringify({ id, source: manual ? 'manual' : 'online' }), Date.now());
    queueForBooking(db, id, 'booking_confirmed'); queueForBooking(db, id, 'reminder');
    return db.prepare('SELECT * FROM bookings WHERE id=?').get(id);
  });
  return booking;
}

export function cancelBooking(db, booking, { byClient, actor }) {
  if (!['pending', 'confirmed'].includes(booking.status)) throw new AppError('not_cancellable', 409);
  if (byClient) {
    const org = db.prepare('SELECT cancel_window_hours FROM orgs WHERE id=?').get(booking.org_id);
    if (booking.start_ms - Date.now() < org.cancel_window_hours * 3600e3) throw new AppError('too_late_to_cancel', 409, { hours: org.cancel_window_hours });
  }
  db.prepare("UPDATE bookings SET status='cancelled' WHERE id=?").run(booking.id);
  cancelPendingReminders(db, booking.id);
  queueForBooking(db, booking.id, 'booking_cancelled');
  db.prepare('INSERT INTO logs(org_id,actor,action,detail,ts) VALUES (?,?,?,?,?)').run(booking.org_id, actor || null, 'booking.cancelled', JSON.stringify({ id: booking.id, byClient: !!byClient }), Date.now());
}

export function rescheduleBooking(db, booking, newStartMs, { actor, staffId } = {}) {
  return tx(db, () => {
    const svc = db.prepare('SELECT * FROM services WHERE id=?').get(booking.service_id);
    const end = newStartMs + svc.duration_min * 60e3, occ = end + svc.buffer_min * 60e3;
    try {
      db.prepare('UPDATE bookings SET start_ms=?, end_ms=?, occ_end_ms=?, staff_id=? WHERE id=?').run(newStartMs, end, occ, staffId || booking.staff_id, booking.id);
    } catch (e) { if (/slot_unavailable/.test(e.message)) throw new AppError('slot_unavailable', 409); throw e; }
    cancelPendingReminders(db, booking.id);
    queueForBooking(db, booking.id, 'booking_modified'); queueForBooking(db, booking.id, 'reminder');
    db.prepare('INSERT INTO logs(org_id,actor,action,detail,ts) VALUES (?,?,?,?,?)').run(booking.org_id, actor || null, 'booking.rescheduled', JSON.stringify({ id: booking.id }), Date.now());
    return db.prepare('SELECT * FROM bookings WHERE id=?').get(booking.id);
  });
}
export { localDate, localTime };
