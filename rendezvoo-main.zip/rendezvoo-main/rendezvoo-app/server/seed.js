// Donnees de demonstration (jamais en production sans SEED_DEMO=1). Cree aussi le premier super-administrateur.
import { openDb, seedReference } from './db.js';
import { hashPassword } from './auth.js';
import { ensureNotifDefaults } from './notify.js';
import { createBooking } from './booking.js';
import { zonedToUtcMs, localDate, addDays } from './time.js';

const db = openDb(); seedReference(db);
const adminEmail = process.env.ADMIN_EMAIL, adminPass = process.env.ADMIN_PASSWORD;
if (adminEmail && adminPass) {
  if (adminPass.length < 12) { console.error('ADMIN_PASSWORD : 12 caracteres minimum'); process.exit(1); }
  db.prepare("INSERT INTO users(email,pass_hash,name,platform_role,created_at) VALUES (?,?,?,'superadmin',?) ON CONFLICT(email) DO UPDATE SET platform_role='superadmin', pass_hash=excluded.pass_hash")
    .run(adminEmail.toLowerCase(), hashPassword(adminPass), 'Administrateur', Date.now());
  console.log('Super-administrateur pret :', adminEmail);
} else console.log('ADMIN_EMAIL / ADMIN_PASSWORD absents : aucun administrateur cree.');

if (process.env.SEED_DEMO === '1') {
  const demo = [
    { slug: 'maison-teranga', name: 'Maison Teranga', category: 'coiffure', city: 'Dakar', bio: 'Salon de coiffure et soins capillaires aux Almadies. Tresses, coupes, lissages, coloration végétale.', address: 'Route des Almadies, Dakar', phone: '+221770001122', accent: '#2B3CFF',
      staff: ['Awa', 'Mariama', 'Coumba'], services: [['Coupe femme', 45, 10, 8000], ['Tresses africaines', 180, 15, 25000], ['Lissage brésilien', 120, 15, 35000], ['Soin profond', 40, 5, 6000]] },
    { slug: 'barber-corniche', name: 'Barber Corniche', category: 'barbier', city: 'Dakar', bio: 'Coupes nettes, dégradés et taille de barbe. Sur rendez-vous, sans attente.', address: 'Corniche Ouest, Dakar', phone: '+221770003344', accent: '#2B3CFF',
      staff: ['Modou', 'Ibrahima'], services: [['Coupe homme', 30, 5, 3000], ['Barbe', 20, 5, 2000], ['Coupe + barbe', 45, 5, 4500]] },
    { slug: 'studio-lumiere', name: 'Studio Lumière', category: 'photographe', city: 'Saint-Louis', bio: 'Portraits, mariages et photographie de marque. Séances en studio ou en extérieur.', address: 'Île de Saint-Louis', phone: '+221770005566', accent: '#2B3CFF',
      staff: ['Cheikh'], services: [['Séance portrait', 60, 15, 30000], ['Photo de produits', 90, 15, 45000]] },
    { slug: 'spa-baobab', name: 'Spa Baobab', category: 'spa', city: 'Abidjan', country: 'CI', bio: 'Massages, hammam et soins du visage. Un lieu calme au cœur de Cocody.', address: 'Cocody, Abidjan', phone: '+2250700112233', accent: '#2B3CFF',
      staff: ['Aïcha', 'Fanta'], services: [['Massage relaxant', 60, 15, 20000], ['Soin du visage', 45, 10, 15000]] },
  ];
  const uid = db.prepare("INSERT INTO users(email,pass_hash,name,created_at) VALUES ('demo@rendezvoo.com',?,'Démo',?) ON CONFLICT(email) DO UPDATE SET name=name RETURNING id").get(hashPassword(process.env.DEMO_PASSWORD || 'demo-rendezvoo-2026'), Date.now()).id;
  for (const d of demo) {
    if (db.prepare('SELECT 1 FROM orgs WHERE slug=?').get(d.slug)) continue;
    const c = db.prepare('SELECT * FROM countries WHERE code=?').get(d.country || 'SN');
    const orgId = db.prepare('INSERT INTO orgs(slug,name,category,city,country,timezone,currency,bio,address,phone,accent,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(d.slug, d.name, d.category, d.city, c.code, c.timezone, c.currency, d.bio, d.address, d.phone, d.accent, Date.now()).lastInsertRowid;
    db.prepare("INSERT INTO members VALUES (?,?,'owner')").run(orgId, uid);
    db.prepare("INSERT INTO subscriptions(org_id,plan,status,trial_ends_ms,period_end_ms) VALUES (?,'business','active',?,?)").run(orgId, Date.now(), Date.now() + 30 * 864e5);
    const svc = d.services.map(s => db.prepare('INSERT INTO services(org_id,name,duration_min,buffer_min,price) VALUES (?,?,?,?,?)').run(orgId, ...s).lastInsertRowid);
    const staff = d.staff.map(n => db.prepare('INSERT INTO staff(org_id,name) VALUES (?,?)').run(orgId, n).lastInsertRowid);
    for (const st of staff) { for (const sv of svc) db.prepare('INSERT INTO staff_services VALUES (?,?)').run(st, sv); for (const wd of [1, 2, 3, 4, 5, 6]) db.prepare('INSERT INTO working_hours(org_id,staff_id,weekday,start,end) VALUES (?,?,?,?,?)').run(orgId, st, wd, '09:00', wd === 6 ? '16:00' : '18:00'); }
    ensureNotifDefaults(db, orgId);
    const names = ['Fatou Ndiaye', 'Moussa Fall', 'Aminata Sow', 'Cheikh Ba', 'Khady Diop', 'Ibou Sy', 'Rokhaya Gueye', 'Omar Thiam'];
    const today = localDate(Date.now(), c.timezone); let n = 0;
    for (let off = -10; off <= 6; off++) for (let k = 0; k < 3; k++) {
      const date = addDays(today, off); const wd = new Date(date + 'T00:00:00Z').getUTCDay(); if (wd === 0) continue;
      const time = ['10:00', '12:30', '15:00'][k]; const sv = svc[(off + k + 10) % svc.length];
      try { const b = createBooking(db, { orgId, serviceId: sv, staffId: staff[(off + k + 10) % staff.length], startMs: zonedToUtcMs(date, time, c.timezone), name: names[n % names.length], phone: '+22177' + String(1000000 + n * 7919).slice(0, 7), source: 'manual' });
        if (off < 0) db.prepare("UPDATE bookings SET status=? WHERE id=?").run(n % 9 === 0 ? 'cancelled' : n % 11 === 0 ? 'no_show' : 'completed', b.id); n++; } catch {}
    }
    for (const [a, r, t] of [['Fatou', 5, 'Accueil chaleureux et travail impeccable.'], ['Moussa', 5, 'Ponctuel, propre, je recommande.'], ['Aminata', 4, 'Très bien, un peu d’attente à l’arrivée.']]) {
      const bid = db.prepare("SELECT id FROM bookings WHERE org_id=? AND status='completed' AND id NOT IN (SELECT booking_id FROM reviews WHERE booking_id IS NOT NULL) LIMIT 1").get(orgId)?.id;
      if (bid) db.prepare('INSERT INTO reviews(org_id,booking_id,author,rating,comment,published,created_at) VALUES (?,?,?,?,?,1,?)').run(orgId, bid, a, r, t, Date.now());
    }
    console.log('Demo :', d.slug);
  }
  console.log('Compte demo : demo@rendezvoo.com /', process.env.DEMO_PASSWORD || 'demo-rendezvoo-2026');
}
db.close();
