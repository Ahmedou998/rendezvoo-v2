import { scryptSync, randomBytes, timingSafeEqual, createHmac } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';

export function hashPassword(pw) {
  const salt = randomBytes(16); const h = scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return salt.toString('hex') + ':' + h.toString('hex');
}
export function verifyPassword(pw, stored) {
  const [s, h] = String(stored).split(':'); if (!s || !h) return false;
  const a = scryptSync(pw, Buffer.from(s, 'hex'), 64, { N: 16384, r: 8, p: 1 }); const b = Buffer.from(h, 'hex');
  return a.length === b.length && timingSafeEqual(a, b);
}
let SECRET;
export function secret() {
  if (SECRET) return SECRET;
  if (process.env.SESSION_SECRET) return (SECRET = process.env.SESSION_SECRET);
  const f = (process.env.DATA_DIR || 'data') + '/session.secret';
  if (existsSync(f)) return (SECRET = readFileSync(f, 'utf8'));
  mkdirSync(process.env.DATA_DIR || 'data', { recursive: true });
  SECRET = randomBytes(32).toString('hex'); writeFileSync(f, SECRET, { mode: 0o600 }); return SECRET;
}
const b64 = (s) => Buffer.from(s).toString('base64url');
export function signSession(uid, ttlMs = 14 * 864e5) {
  const p = b64(JSON.stringify({ uid, exp: Date.now() + ttlMs }));
  return p + '.' + createHmac('sha256', secret()).update(p).digest('base64url');
}
export function readSession(token) {
  if (!token || !token.includes('.')) return null;
  const [p, sig] = token.split('.');
  const good = createHmac('sha256', secret()).update(p).digest('base64url');
  const a = Buffer.from(sig), b = Buffer.from(good);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try { const d = JSON.parse(Buffer.from(p, 'base64url').toString()); return d.exp > Date.now() ? d : null; } catch { return null; }
}
export function parseCookies(h = '') {
  return Object.fromEntries(h.split(';').map(x => x.trim().split('=')).filter(x => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
}
export const cookie = (token, maxAge = 14 * 86400) =>
  `rv_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`;

// Limiteur de debit en memoire (par cle et fenetre)
const hits = new Map();
export function rateLimit(key, max, windowMs) {
  const t = Date.now(); const arr = (hits.get(key) || []).filter(x => t - x < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return false; }
  arr.push(t); hits.set(key, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || t - v[v.length - 1] > windowMs) hits.delete(k);
  return true;
}
export const PERMS = {
  superadmin: ['*'],
  support: ['orgs.read', 'orgs.suspend', 'complaints', 'logs.read', 'users.read', 'content'],
  finance: ['orgs.read', 'subscriptions', 'invoices', 'stats', 'offers'],
};
export const can = (role, perm) => !!role && (PERMS[role].includes('*') || PERMS[role].includes(perm));
