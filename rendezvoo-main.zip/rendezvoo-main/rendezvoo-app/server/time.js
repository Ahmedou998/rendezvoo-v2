// Utilitaires fuseaux horaires (Intl, sans dependance)
const dtfCache = new Map();
function dtf(tz) {
  if (!dtfCache.has(tz)) dtfCache.set(tz, new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  return dtfCache.get(tz);
}
export function tzOffsetMs(ms, tz) {
  const p = Object.fromEntries(dtf(tz).formatToParts(new Date(ms)).map(x => [x.type, x.value]));
  return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - Math.floor(ms / 1000) * 1000;
}
export function zonedToUtcMs(date, hhmm, tz) {
  const [y, m, d] = date.split('-').map(Number); const [H, M] = hhmm.split(':').map(Number);
  const guess = Date.UTC(y, m - 1, d, H, M);
  let r = guess - tzOffsetMs(guess, tz);
  r = guess - tzOffsetMs(r, tz);
  return r;
}
export function localDate(ms, tz) {
  const p = Object.fromEntries(dtf(tz).formatToParts(new Date(ms)).map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}
export function localTime(ms, tz) {
  const p = Object.fromEntries(dtf(tz).formatToParts(new Date(ms)).map(x => [x.type, x.value]));
  return `${p.hour}:${p.minute}`;
}
export const weekdayOf = (date) => { const [y, m, d] = date.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)).getUTCDay(); };
export const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s + 'T00:00:00Z'));
export const isTime = (s) => typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
export const addDays = (date, n) => { const [y, m, d] = date.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };
