import { hashPassword } from './auth.js';
import { AppError, createBooking, cancelBooking, rescheduleBooking, normPhone } from './booking.js';
import { json, str, int, proContext, needAdmin, log, RESERVED } from './core.js';
import { tx } from './db.js';
import { ensureNotifDefaults, queueForBooking } from './notify.js';
import { localDate, localTime, zonedToUtcMs, isDate, isTime, addDays } from './time.js';

const need = (plan, key, code = 'plan_required') => { if (!plan[key]) throw new AppError(code, 402, { feature: key }); };

export function registerPro(r, db) {
  const P = (method, path, fn, opts = {}) => r[method]('/api/pro' + path, (c) => {
    const ctx = proContext(db, c.req); if (opts.admin) needAdmin(ctx); return fn(c, ctx);
  });
  const decorate = (rows, tz) => rows.map(b => ({ ...b, date: localDate(b.start_ms, tz), time: localTime(b.start_ms, tz), end_time: localTime(b.end_ms, tz) }));
  const BK = `SELECT b.id,b.start_ms,b.end_ms,b.status,b.price,b.notes,b.source,b.staff_id,b.service_id,b.customer_id,b.token,
    c.name customer,c.phone,s.name service,st.name staff FROM bookings b JOIN customers c ON c.id=b.customer_id
    JOIN services s ON s.id=b.service_id JOIN staff st ON st.id=b.staff_id WHERE b.org_id=?`;
  const owned = (table, id, org) => { const x = db.prepare(`SELECT * FROM ${table} WHERE id=? AND org_id=?`).get(id, org.id); if (!x) throw new AppError('not_found', 404); return x; };

  // ---- Vue generale
  P('get', '/overview', (c, { org, plan }) => {
    const tz = org.timezone, today = localDate(Date.now(), tz), mStart = zonedToUtcMs(today.slice(0, 8) + '01', '00:00', tz);
    const n = (sql, ...a) => db.prepare(sql).get(org.id, ...a).n;
    const month = n(`SELECT COUNT(*) n FROM bookings WHERE org_id=? AND start_ms>=? AND status<>'cancelled'`, mStart);
    const monthAll = n(`SELECT COUNT(*) n FROM bookings WHERE org_id=? AND start_ms>=?`, mStart);
    const cancelled = n(`SELECT COUNT(*) n FROM bookings WHERE org_id=? AND start_ms>=? AND status='cancelled'`, mStart);
    const revenue = db.prepare(`SELECT COALESCE(SUM(price),0) v FROM bookings WHERE org_id=? AND start_ms>=? AND status='completed'`).get(org.id, mStart).v;
    const expected = db.prepare(`SELECT COALESCE(SUM(price),0) v FROM bookings WHERE org_id=? AND start_ms>=? AND status IN ('pending','confirmed')`).get(org.id, Date.now()).v;
    const upcoming = decorate(db.prepare(BK + ` AND b.start_ms>=? AND b.status IN ('pending','confirmed') ORDER BY b.start_ms LIMIT 8`).all(org.id, Date.now()), tz);
    const recent = db.prepare(`SELECT c.id,c.name,c.phone,(SELECT COUNT(*) FROM bookings WHERE customer_id=c.id) visits FROM customers c WHERE c.org_id=? ORDER BY c.created_at DESC, c.id DESC LIMIT 6`).all(org.id);
    const sub = db.prepare('SELECT * FROM subscriptions WHERE org_id=?').get(org.id);
    json(c.res, 200, { org: { name: org.name, slug: org.slug, currency: org.currency, suspended: !!org.suspended }, plan: plan.code, subscription: sub,
      month_bookings: month, cancel_rate: monthAll ? Math.round(cancelled / monthAll * 100) : 0, revenue_declared: revenue, revenue_expected: expected, upcoming, recent_customers: recent });
  });

  // ---- Reservations
  P('get', '/bookings', (c, { org }) => {
    const from = str(c.query.from, 10), to = str(c.query.to, 10); if (!isDate(from) || !isDate(to)) throw new AppError('invalid_date');
    const a = zonedToUtcMs(from, '00:00', org.timezone), b = zonedToUtcMs(addDays(to, 1), '00:00', org.timezone);
    const st = str(c.query.status, 20), staff = int(c.query.staff);
    json(c.res, 200, decorate(db.prepare(BK + ` AND b.start_ms>=? AND b.start_ms<? ${st ? 'AND b.status=?' : ''} ${staff ? 'AND b.staff_id=?' : ''} ORDER BY b.start_ms`)
      .all(org.id, a, b, ...(st ? [st] : []), ...(staff ? [staff] : [])), org.timezone));
  });
  P('get', '/bookings/:id', (c, { org }) => {
    const b = db.prepare(BK + ' AND b.id=?').get(org.id, int(c.params.id)); if (!b) throw new AppError('not_found', 404);
    json(c.res, 200, decorate([b], org.timezone)[0]);
  });
  P('post', '/bookings', (c, { org, user }) => {
    const b = c.body; if (!isDate(b.date) || !isTime(b.time)) throw new AppError('invalid_date');
    const bk = createBooking(db, { orgId: org.id, serviceId: int(b.service_id), staffId: int(b.staff_id), startMs: zonedToUtcMs(b.date, b.time, org.timezone),
      name: b.name, phone: b.phone, email: b.email, notes: b.notes, source: 'manual', actor: user.id });
    json(c.res, 201, { id: bk.id });
  });
  P('patch', '/bookings/:id', (c, { org, user }) => {
    const b = owned('bookings', int(c.params.id), org); const body = c.body;
    if (body.status === 'cancelled') cancelBooking(db, b, { byClient: false, actor: user.id });
    else if (['completed', 'no_show', 'confirmed', 'pending'].includes(body.status)) {
      try { db.prepare('UPDATE bookings SET status=? WHERE id=?').run(body.status, b.id); }
      catch (e) { if (/slot_unavailable/.test(e.message)) throw new AppError('slot_unavailable', 409); throw e; }
      log(db, org.id, user.id, 'booking.status', { id: b.id, status: body.status });
    }
    if (isDate(body.date) && isTime(body.time)) rescheduleBooking(db, db.prepare('SELECT * FROM bookings WHERE id=?').get(b.id), zonedToUtcMs(body.date, body.time, org.timezone), { actor: user.id, staffId: int(body.staff_id) || undefined });
    if (typeof body.notes === 'string') db.prepare('UPDATE bookings SET notes=? WHERE id=?').run(str(body.notes, 500), b.id);
    json(c.res, 200, { ok: true });
  });

  // ---- Clients
  P('get', '/customers', (c, { org }) => {
    const q = `%${str(c.query.q, 60).toLowerCase()}%`;
    json(c.res, 200, db.prepare(`SELECT c.id,c.name,c.phone,c.email,c.notes,COUNT(b.id) visits,COALESCE(SUM(CASE WHEN b.status='completed' THEN b.price END),0) spent,MAX(b.start_ms) last_ms
      FROM customers c LEFT JOIN bookings b ON b.customer_id=c.id WHERE c.org_id=? AND (lower(c.name) LIKE ? OR c.phone LIKE ?) GROUP BY c.id ORDER BY last_ms DESC LIMIT 200`).all(org.id, q, q));
  });
  P('get', '/customers/:id', (c, { org }) => {
    const cu = owned('customers', int(c.params.id), org);
    json(c.res, 200, { ...cu, bookings: decorate(db.prepare(BK + ' AND b.customer_id=? ORDER BY b.start_ms DESC').all(org.id, cu.id), org.timezone) });
  });
  P('patch', '/customers/:id', (c, { org }) => {
    const cu = owned('customers', int(c.params.id), org);
    db.prepare('UPDATE customers SET name=?, email=?, notes=? WHERE id=?').run(str(c.body.name, 80) || cu.name, str(c.body.email, 120), str(c.body.notes, 1000), cu.id);
    json(c.res, 200, { ok: true });
  });

  // ---- Prestations
  const svcOut = (org) => db.prepare('SELECT * FROM services WHERE org_id=? ORDER BY id').all(org.id).map(s => ({ ...s, staff_ids: db.prepare('SELECT staff_id FROM staff_services WHERE service_id=?').all(s.id).map(x => x.staff_id) }));
  const saveSvc = (id, org, b) => {
    const dur = int(b.duration_min), buf = int(b.buffer_min), price = int(b.price);
    if (str(b.name, 80).length < 2 || dur < 5 || dur > 720 || buf < 0 || buf > 240 || price < 0) throw new AppError('invalid_service');
    if (id) db.prepare('UPDATE services SET name=?,description=?,duration_min=?,buffer_min=?,price=?,active=? WHERE id=?').run(str(b.name, 80), str(b.description, 300), dur, buf, price, b.active === false ? 0 : 1, id);
    else id = db.prepare('INSERT INTO services(org_id,name,description,duration_min,buffer_min,price) VALUES (?,?,?,?,?,?)').run(org.id, str(b.name, 80), str(b.description, 300), dur, buf, price).lastInsertRowid;
    if (Array.isArray(b.staff_ids)) {
      db.prepare('DELETE FROM staff_services WHERE service_id=?').run(id);
      for (const sid of b.staff_ids) if (db.prepare('SELECT 1 FROM staff WHERE id=? AND org_id=?').get(int(sid), org.id)) db.prepare('INSERT OR IGNORE INTO staff_services VALUES (?,?)').run(int(sid), id);
    }
    return id;
  };
  P('get', '/services', (c, { org }) => json(c.res, 200, svcOut(org)));
  P('post', '/services', (c, { org, user }) => { const id = saveSvc(null, org, { staff_ids: db.prepare('SELECT id FROM staff WHERE org_id=? AND active=1').all(org.id).map(s => s.id), ...c.body }); log(db, org.id, user.id, 'service.created', { id }); json(c.res, 201, { id }); }, { admin: true });
  P('put', '/services/:id', (c, { org }) => { owned('services', int(c.params.id), org); saveSvc(int(c.params.id), org, c.body); json(c.res, 200, { ok: true }); }, { admin: true });
  P('delete', '/services/:id', (c, { org }) => {
    owned('services', int(c.params.id), org);
    db.prepare('UPDATE services SET active=0 WHERE id=?').run(int(c.params.id)); json(c.res, 200, { ok: true });   // archive : l'historique est conserve
  }, { admin: true });

  // ---- Employes
  P('get', '/staff', (c, { org }) => json(c.res, 200, db.prepare('SELECT * FROM staff WHERE org_id=? ORDER BY id').all(org.id)));
  P('post', '/staff', (c, { org, plan }) => {
    const count = db.prepare('SELECT COUNT(*) n FROM staff WHERE org_id=? AND active=1').get(org.id).n;
    if (plan.staff_max !== null && count >= plan.staff_max) throw new AppError('staff_limit_reached', 402, { max: plan.staff_max });
    const name = str(c.body.name, 80); if (name.length < 2) throw new AppError('invalid_name');
    const id = db.prepare('INSERT INTO staff(org_id,name) VALUES (?,?)').run(org.id, name).lastInsertRowid;
    const wh = db.prepare('INSERT INTO working_hours(org_id,staff_id,weekday,start,end) VALUES (?,?,?,?,?)');
    for (const d of [1, 2, 3, 4, 5, 6]) wh.run(org.id, id, d, '09:00', '18:00');
    for (const s of db.prepare('SELECT id FROM services WHERE org_id=? AND active=1').all(org.id)) db.prepare('INSERT OR IGNORE INTO staff_services VALUES (?,?)').run(id, s.id);
    json(c.res, 201, { id });
  }, { admin: true });
  P('patch', '/staff/:id', (c, { org, plan }) => {
    const s = owned('staff', int(c.params.id), org);
    if (c.body.active === true && !s.active && plan.staff_max !== null && db.prepare('SELECT COUNT(*) n FROM staff WHERE org_id=? AND active=1').get(org.id).n >= plan.staff_max) throw new AppError('staff_limit_reached', 402, { max: plan.staff_max });
    db.prepare('UPDATE staff SET name=?, active=? WHERE id=?').run(str(c.body.name, 80) || s.name, c.body.active === false ? 0 : c.body.active === true ? 1 : s.active, s.id);
    json(c.res, 200, { ok: true });
  }, { admin: true });

  // ---- Horaires + indisponibilites
  P('get', '/hours', (c, { org }) => json(c.res, 200, db.prepare('SELECT staff_id,weekday,start,end FROM working_hours WHERE org_id=? ORDER BY staff_id,weekday,start').all(org.id)));
  P('put', '/hours/:staffId', (c, { org }) => {
    const s = owned('staff', int(c.params.staffId), org); const days = c.body.days;
    if (!Array.isArray(days) || days.length > 30) throw new AppError('invalid_hours');
    for (const d of days) if (!(d.weekday >= 0 && d.weekday <= 6) || !isTime(d.start) || !isTime(d.end) || d.end <= d.start) throw new AppError('invalid_hours');
    db.prepare('DELETE FROM working_hours WHERE staff_id=?').run(s.id);
    for (const d of days) db.prepare('INSERT INTO working_hours(org_id,staff_id,weekday,start,end) VALUES (?,?,?,?,?)').run(org.id, s.id, d.weekday, d.start, d.end);
    json(c.res, 200, { ok: true });
  }, { admin: true });
  P('get', '/timeoff', (c, { org }) => json(c.res, 200, decorate(db.prepare('SELECT t.*, s.name staff FROM time_off t JOIN staff s ON s.id=t.staff_id WHERE t.org_id=? AND t.end_ms>? ORDER BY t.start_ms').all(org.id, Date.now()), org.timezone)));
  P('post', '/timeoff', (c, { org }) => {
    const s = owned('staff', int(c.body.staff_id), org); const b = c.body;
    if (!isDate(b.date) || !isTime(b.start) || !isTime(b.end) || b.end <= b.start) throw new AppError('invalid_hours');
    const a = zonedToUtcMs(b.date, b.start, org.timezone), e = zonedToUtcMs(b.date, b.end, org.timezone);
    const clash = db.prepare(`SELECT COUNT(*) n FROM bookings WHERE staff_id=? AND status IN ('pending','confirmed') AND start_ms<? AND occ_end_ms>?`).get(s.id, e, a).n;
    const id = db.prepare('INSERT INTO time_off(org_id,staff_id,start_ms,end_ms,reason) VALUES (?,?,?,?,?)').run(org.id, s.id, a, e, str(b.reason, 120)).lastInsertRowid;
    json(c.res, 201, { id, conflicting_bookings: clash });
  });
  P('delete', '/timeoff/:id', (c, { org }) => { owned('time_off', int(c.params.id), org); db.prepare('DELETE FROM time_off WHERE id=?').run(int(c.params.id)); json(c.res, 200, { ok: true }); });

  // ---- Notifications
  P('get', '/notifications', (c, { org }) => {
    ensureNotifDefaults(db, org.id);
    json(c.res, 200, { settings: db.prepare('SELECT event,channel,enabled,lead_hours FROM notif_settings WHERE org_id=?').all(org.id),
      outbox: db.prepare('SELECT id,audience,channel,event,recipient,body,send_at,status FROM outbox WHERE org_id=? ORDER BY id DESC LIMIT 40').all(org.id),
      providers: { email: !!process.env.RESEND_API_KEY, whatsapp: !!process.env.WHATSAPP_API_URL, sms: !!process.env.SMS_API_URL } });
  });
  P('put', '/notifications', (c, { org, plan }) => {
    for (const s of c.body.settings || []) {
      if ((s.channel !== 'email' || s.lead_hours !== undefined) && !plan.adv_notifications && (s.channel !== 'email')) throw new AppError('plan_required', 402, { feature: 'adv_notifications' });
      db.prepare('UPDATE notif_settings SET enabled=?, lead_hours=COALESCE(?,lead_hours) WHERE org_id=? AND event=? AND channel=?').run(s.enabled ? 1 : 0, s.lead_hours == null ? null : Math.min(168, Math.max(1, int(s.lead_hours))), org.id, str(s.event, 30), str(s.channel, 10));
    }
    json(c.res, 200, { ok: true });
  }, { admin: true });

  // ---- Statistiques (Pro+) et rapports (Business)
  P('get', '/stats', (c, { org, plan }) => {
    need(plan, 'stats');
    const days = Math.min(90, Math.max(7, int(c.query.days, 30))); const since = Date.now() - days * 864e5;
    const byDay = {}; for (const b of db.prepare(`SELECT start_ms,status,price FROM bookings WHERE org_id=? AND start_ms>=?`).all(org.id, since)) {
      const d = localDate(b.start_ms, org.timezone); byDay[d] ||= { date: d, bookings: 0, cancelled: 0, revenue: 0 };
      if (b.status === 'cancelled') byDay[d].cancelled++; else byDay[d].bookings++; if (b.status === 'completed') byDay[d].revenue += b.price; }
    json(c.res, 200, { days, by_day: Object.values(byDay).sort((a, b) => a.date < b.date ? -1 : 1),
      top_services: db.prepare(`SELECT s.name, COUNT(*) n, COALESCE(SUM(CASE WHEN b.status='completed' THEN b.price END),0) revenue FROM bookings b JOIN services s ON s.id=b.service_id WHERE b.org_id=? AND b.start_ms>=? AND b.status<>'cancelled' GROUP BY s.id ORDER BY n DESC LIMIT 6`).all(org.id, since),
      by_staff: db.prepare(`SELECT st.name, COUNT(*) n FROM bookings b JOIN staff st ON st.id=b.staff_id WHERE b.org_id=? AND b.start_ms>=? AND b.status<>'cancelled' GROUP BY st.id ORDER BY n DESC`).all(org.id, since),
      new_customers: db.prepare('SELECT COUNT(*) n FROM customers WHERE org_id=? AND created_at>=?').get(org.id, since).n });
  });
  P('get', '/report.csv', (c, { org, plan }) => {
    need(plan, 'reports');
    const rows = decorate(db.prepare(BK + ' ORDER BY b.start_ms').all(org.id), org.timezone);
    const esc = (v) => { v = String(v ?? ''); if (/^[=+\-@]/.test(v)) v = "'" + v; return `"${v.replace(/"/g, '""')}"`; };
    const csv = ['date,heure,client,telephone,prestation,employe,statut,prix', ...rows.map(b => [b.date, b.time, b.customer, b.phone, b.service, b.staff, b.status, b.price].map(esc).join(','))].join('\n');
    c.res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="rapport-reservations.csv"' }); c.res.end(csv);
  });

  // ---- Parametres / page publique
  P('get', '/settings', (c, { org, role }) => json(c.res, 200, { ...org, my_role: role }));
  P('patch', '/settings', (c, { org, plan, user }) => {
    const b = c.body; const cat = b.category ? db.prepare('SELECT slug FROM categories WHERE slug=?').get(str(b.category, 40)) : null;
    let accent = org.accent;
    if (b.accent && /^#[0-9a-fA-F]{6}$/.test(b.accent)) { need(plan, 'customization'); accent = b.accent; }
    db.prepare(`UPDATE orgs SET name=?,bio=?,address=?,phone=?,city=?,category=?,accent=?,cancel_window_hours=?,min_notice_min=? WHERE id=?`).run(
      str(b.name, 80) || org.name, str(b.bio ?? org.bio, 600), str(b.address ?? org.address, 160), str(b.phone ?? org.phone, 30), str(b.city ?? org.city, 60),
      cat ? cat.slug : org.category, accent, Math.min(168, Math.max(0, int(b.cancel_window_hours ?? org.cancel_window_hours))), Math.min(1440, Math.max(0, int(b.min_notice_min ?? org.min_notice_min))), org.id);
    log(db, org.id, user.id, 'org.updated'); json(c.res, 200, { ok: true });
  }, { admin: true });

  P('get', '/reviews', (c, { org }) => json(c.res, 200, db.prepare('SELECT * FROM reviews WHERE org_id=? ORDER BY created_at DESC').all(org.id)));
  P('patch', '/reviews/:id', (c, { org }) => { owned('reviews', int(c.params.id), org); db.prepare('UPDATE reviews SET published=? WHERE id=?').run(c.body.published ? 1 : 0, int(c.params.id)); json(c.res, 200, { ok: true }); }, { admin: true });

  // ---- Equipe (Business : multi-utilisateurs)
  P('get', '/members', (c, { org }) => json(c.res, 200, db.prepare('SELECT u.id,u.name,u.email,m.role FROM members m JOIN users u ON u.id=m.user_id WHERE m.org_id=?').all(org.id)));
  P('post', '/members', (c, { org, plan, user }) => {
    need(plan, 'multi_user'); const b = c.body; const email = str(b.email, 120).toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || String(b.password || '').length < 8 || str(b.name, 80).length < 2) throw new AppError('invalid_member');
    if (!['admin', 'staff'].includes(b.role)) throw new AppError('invalid_role');
    let u = db.prepare('SELECT id FROM users WHERE email=?').get(email);
    if (!u) u = { id: db.prepare('INSERT INTO users(email,pass_hash,name,created_at) VALUES (?,?,?,?)').run(email, hashPassword(String(b.password)), str(b.name, 80), Date.now()).lastInsertRowid };
    db.prepare('INSERT OR REPLACE INTO members VALUES (?,?,?)').run(org.id, u.id, b.role); log(db, org.id, user.id, 'member.added', { email });
    json(c.res, 201, { ok: true });
  }, { admin: true });

  // ---- Abonnement
  P('get', '/subscription', (c, { org }) => {
    json(c.res, 200, { subscription: db.prepare('SELECT * FROM subscriptions WHERE org_id=?').get(org.id), plans: db.prepare('SELECT * FROM plans ORDER BY sort').all(),
      invoices: db.prepare('SELECT * FROM invoices WHERE org_id=? ORDER BY id DESC').all(org.id), payment_mode: process.env.PAYMENT_PROVIDER_URL ? 'provider' : (process.env.PAYMENT_MODE || 'test'),
      providers: JSON.parse(db.prepare('SELECT providers FROM countries WHERE code=?').get(org.country).providers) });
  });
  P('post', '/subscription/change', (c, { org, user }) => {
    const plan = db.prepare('SELECT * FROM plans WHERE code=?').get(str(c.body.plan, 20)); if (!plan) throw new AppError('invalid_plan');
    const sub = db.prepare('SELECT * FROM subscriptions WHERE org_id=?').get(org.id);
    const staffCount = db.prepare('SELECT COUNT(*) n FROM staff WHERE org_id=? AND active=1').get(org.id).n;
    if (plan.staff_max !== null && staffCount > plan.staff_max) throw new AppError('too_many_staff_for_plan', 409, { max: plan.staff_max, current: staffCount });
    const number = `RV-${new Date().getFullYear()}-${String(db.prepare('SELECT COUNT(*)+1 n FROM invoices').get().n).padStart(5, '0')}`;
    db.prepare('UPDATE subscriptions SET plan=? WHERE org_id=?').run(plan.code, org.id);
    const id = db.prepare("INSERT INTO invoices(org_id,number,plan,amount,currency,status,issued_ms) VALUES (?,?,?,?,?,'open',?)").run(org.id, number, plan.code, plan.price_xof, 'XOF', Date.now()).lastInsertRowid;
    log(db, org.id, user.id, 'subscription.changed', { from: sub.plan, to: plan.code }); json(c.res, 200, { invoice_id: id, number });
  }, { admin: true });
  P('post', '/invoices/:id/pay', async (c, { org, user }) => {
    const inv = owned('invoices', int(c.params.id), org); if (inv.status !== 'open') throw new AppError('invoice_not_open', 409);
    let provider = 'test', ref = 'test-' + inv.number;
    if (process.env.PAYMENT_PROVIDER_URL) {   // prestataire agree : cree une session de paiement hebergee, le webhook confirme ensuite
      const r = await fetch(process.env.PAYMENT_PROVIDER_URL, { method: 'POST', headers: { Authorization: `Bearer ${process.env.PAYMENT_PROVIDER_KEY || ''}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ reference: inv.number, amount: inv.amount, currency: inv.currency, return_url: `${process.env.BASE_URL || ''}/app#abonnement` }) });
      if (!r.ok) throw new AppError('provider_error', 502);
      const d = await r.json(); return json(c.res, 200, { redirect: d.checkout_url });
    }
    if ((process.env.PAYMENT_MODE || 'test') !== 'test') throw new AppError('payment_provider_not_configured', 501);
    db.prepare("UPDATE invoices SET status='paid', paid_ms=?, provider=?, provider_ref=? WHERE id=?").run(Date.now(), provider, ref, inv.id);
    db.prepare("UPDATE subscriptions SET status='active', period_end_ms=? WHERE org_id=?").run(Date.now() + 30 * 864e5, org.id);
    log(db, org.id, user.id, 'invoice.paid', { number: inv.number, mode: 'test' }); json(c.res, 200, { ok: true, mode: 'test' });
  }, { admin: true });

  // ---- Plusieurs etablissements (Business) : meme compte, nouvel espace independant
  P('post', '/establishments', (c, { org, plan, user }) => {
    need(plan, 'multi_user');
    const slug = str(c.body.slug, 40).toLowerCase(), name = str(c.body.name, 80);
    if (!/^[a-z0-9-]{3,40}$/.test(slug) || RESERVED.has(slug)) throw new AppError('invalid_slug');
    if (name.length < 2) throw new AppError('invalid_name');
    const sub = db.prepare('SELECT * FROM subscriptions WHERE org_id=?').get(org.id);
    let id;
    try {
      id = tx(db, () => {
        const oid = db.prepare('INSERT INTO orgs(slug,name,category,city,country,timezone,currency,created_at) VALUES (?,?,?,?,?,?,?,?)')
          .run(slug, name, org.category, str(c.body.city, 60) || org.city, org.country, org.timezone, org.currency, Date.now()).lastInsertRowid;
        db.prepare("INSERT INTO members VALUES (?,?,'owner')").run(oid, user.id);
        db.prepare('INSERT INTO subscriptions(org_id,plan,status,trial_ends_ms,period_end_ms) VALUES (?,?,?,?,?)').run(oid, 'business', sub.status, sub.trial_ends_ms, sub.period_end_ms);
        const sid = db.prepare('INSERT INTO staff(org_id,name) VALUES (?,?)').run(oid, user.name).lastInsertRowid;
        for (const d of [1, 2, 3, 4, 5, 6]) db.prepare('INSERT INTO working_hours(org_id,staff_id,weekday,start,end) VALUES (?,?,?,?,?)').run(oid, sid, d, '09:00', '18:00');
        ensureNotifDefaults(db, oid); log(db, oid, user.id, 'org.created', { slug, from: org.id }); return oid;
      });
    } catch (e) { if (/UNIQUE.*slug/.test(e.message)) throw new AppError('slug_taken', 409); throw e; }
    json(c.res, 201, { id });
  }, { admin: true });
}
