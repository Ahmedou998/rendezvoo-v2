// Notifications : file d'attente (outbox) + envoi via prestataires configures par variables d'environnement.
// Sans identifiants, les messages restent visibles dans l'outbox avec le statut "test" (aucun envoi reel).
import { localDate, localTime } from './time.js';

const DEFAULTS = [
  ['booking_confirmed','email',1,null],['booking_confirmed','whatsapp',1,null],['booking_confirmed','sms',0,null],
  ['reminder','email',1,24],['reminder','whatsapp',1,24],['reminder','sms',0,24],
  ['booking_cancelled','email',1,null],['booking_cancelled','whatsapp',1,null],['booking_modified','email',1,null],['booking_modified','whatsapp',1,null]];

export function ensureNotifDefaults(db, orgId) {
  const s = db.prepare('INSERT OR IGNORE INTO notif_settings(org_id,event,channel,enabled,lead_hours) VALUES (?,?,?,?,?)');
  for (const [e, c, en, l] of DEFAULTS) s.run(orgId, e, c, en, l);
}

const T = {
  booking_confirmed: (c) => ({ client: `Bonjour ${c.customer}, votre rendez-vous « ${c.service} » chez ${c.org} est confirmé le ${c.date} à ${c.time}. Gérer ou annuler : ${c.link}`,
    pro: `Nouvelle réservation : ${c.customer} (${c.phone}) – ${c.service} le ${c.date} à ${c.time}.` }),
  reminder: (c) => ({ client: `Rappel : rendez-vous « ${c.service} » chez ${c.org} le ${c.date} à ${c.time}. Gérer : ${c.link}`, pro: null }),
  booking_cancelled: (c) => ({ client: `Votre rendez-vous « ${c.service} » du ${c.date} à ${c.time} chez ${c.org} est annulé.`,
    pro: `Annulation : ${c.customer} – ${c.service} le ${c.date} à ${c.time}.` }),
  booking_modified: (c) => ({ client: `Votre rendez-vous chez ${c.org} est déplacé au ${c.date} à ${c.time} (${c.service}). Gérer : ${c.link}`,
    pro: `Rendez-vous modifié : ${c.customer} – ${c.service}, maintenant le ${c.date} à ${c.time}.` }),
};

export function queueForBooking(db, bookingId, event, baseUrl = process.env.BASE_URL || 'http://localhost:3000') {
  const b = db.prepare(`SELECT b.*, o.name org, o.timezone tz, o.phone org_phone, s.name service, c.name customer, c.phone, c.email,
    (SELECT u.email FROM members m JOIN users u ON u.id=m.user_id WHERE m.org_id=o.id AND m.role='owner') owner_email
    FROM bookings b JOIN orgs o ON o.id=b.org_id JOIN services s ON s.id=b.service_id JOIN customers c ON c.id=b.customer_id WHERE b.id=?`).get(bookingId);
  if (!b) return;
  const ctx = { org: b.org, service: b.service, customer: b.customer, phone: b.phone, date: localDate(b.start_ms, b.tz),
    time: localTime(b.start_ms, b.tz), link: `${baseUrl}/r/${b.token}` };
  const msg = T[event](ctx);
  const sets = db.prepare('SELECT channel, enabled, lead_hours FROM notif_settings WHERE org_id=? AND event=? AND enabled=1').all(b.org_id, event);
  const ins = db.prepare('INSERT INTO outbox(org_id,booking_id,audience,channel,event,recipient,body,send_at) VALUES (?,?,?,?,?,?,?,?)');
  const t = Date.now();
  for (const s of sets) {
    const sendAt = event === 'reminder' ? b.start_ms - (s.lead_hours ?? 24) * 3600e3 : t;
    if (event === 'reminder' && sendAt <= t) continue;
    if (msg.client) {
      const to = s.channel === 'email' ? b.email : b.phone;
      if (to) ins.run(b.org_id, b.id, 'client', s.channel, event, to, msg.client, sendAt);
    }
    if (msg.pro && s.channel === 'email' && b.owner_email) ins.run(b.org_id, b.id, 'pro', 'email', event, b.owner_email, msg.pro, t);
  }
}

export function cancelPendingReminders(db, bookingId) {
  db.prepare("UPDATE outbox SET status='skipped' WHERE booking_id=? AND event='reminder' AND status='queued'").run(bookingId);
}

async function send(row) {
  const { channel, recipient, body } = row;
  if (channel === 'email' && process.env.RESEND_API_KEY) {
    const r = await fetch('https://api.resend.com/emails', { method: 'POST',
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM || 'RENDEZVOO <no-reply@rendezvoo.com>', to: [recipient], subject: 'RENDEZVOO', text: body }) });
    if (!r.ok) throw new Error('email_provider_' + r.status);
    return 'sent';
  }
  const url = channel === 'whatsapp' ? process.env.WHATSAPP_API_URL : channel === 'sms' ? process.env.SMS_API_URL : null;
  const token = channel === 'whatsapp' ? process.env.WHATSAPP_API_TOKEN : process.env.SMS_API_TOKEN;
  if (url && token) {
    const r = await fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: recipient, text: body }) });
    if (!r.ok) throw new Error('provider_' + r.status);
    return 'sent';
  }
  return 'test'; // aucun identifiant configure : message conserve, rien n'est envoye
}

export async function flushOutbox(db, limit = 50) {
  const rows = db.prepare("SELECT * FROM outbox WHERE status='queued' AND send_at<=? ORDER BY send_at LIMIT ?").all(Date.now(), limit);
  for (const row of rows) {
    try { const st = await send(row);
      db.prepare('UPDATE outbox SET status=?, sent_at=? WHERE id=?').run(st, Date.now(), row.id);
    } catch (e) { db.prepare("UPDATE outbox SET status='failed', error=? WHERE id=?").run(String(e.message), row.id); }
  }
  return rows.length;
}
