// Couche donnees : SQLite embarque (node:sqlite). Schema equivalent a supabase/migrations.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

export function openDb(file = process.env.DB_FILE || 'data/rendezvoo.db') {
  if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  return db;
}

export const SCHEMA = `
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL, name TEXT NOT NULL,
  platform_role TEXT CHECK (platform_role IN ('superadmin','support','finance')),
  suspended INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS categories(
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, label TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS countries(
  code TEXT PRIMARY KEY, name TEXT NOT NULL, currency TEXT NOT NULL, timezone TEXT NOT NULL,
  dial TEXT NOT NULL, providers TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS orgs(
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, category TEXT, city TEXT,
  country TEXT NOT NULL DEFAULT 'SN' REFERENCES countries(code), timezone TEXT NOT NULL, currency TEXT NOT NULL,
  bio TEXT DEFAULT '', address TEXT DEFAULT '', phone TEXT DEFAULT '', accent TEXT DEFAULT '#2A3FFF',
  cancel_window_hours INTEGER NOT NULL DEFAULT 24, min_notice_min INTEGER NOT NULL DEFAULT 60,
  suspended INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS members(
  org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('owner','admin','staff')), PRIMARY KEY(org_id,user_id));
CREATE TABLE IF NOT EXISTS staff(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS services(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  name TEXT NOT NULL, description TEXT DEFAULT '', duration_min INTEGER NOT NULL CHECK (duration_min BETWEEN 5 AND 720),
  buffer_min INTEGER NOT NULL DEFAULT 0 CHECK (buffer_min >= 0), price INTEGER NOT NULL CHECK (price >= 0),
  active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS staff_services(
  staff_id INTEGER NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  service_id INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE, PRIMARY KEY(staff_id,service_id));
CREATE TABLE IF NOT EXISTS working_hours(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  staff_id INTEGER NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  weekday INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6), start TEXT NOT NULL, end TEXT NOT NULL CHECK (end > start));
CREATE TABLE IF NOT EXISTS time_off(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  staff_id INTEGER NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL CHECK (end_ms > start_ms), reason TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS customers(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT DEFAULT '', notes TEXT DEFAULT '', created_at INTEGER NOT NULL,
  UNIQUE(org_id, phone));
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  staff_id INTEGER NOT NULL REFERENCES staff(id), service_id INTEGER NOT NULL REFERENCES services(id),
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL, occ_end_ms INTEGER NOT NULL,
  price INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','cancelled','completed','no_show')),
  token TEXT UNIQUE NOT NULL, notes TEXT DEFAULT '', source TEXT NOT NULL DEFAULT 'online',
  created_at INTEGER NOT NULL, CHECK (end_ms > start_ms AND occ_end_ms >= end_ms));
CREATE INDEX IF NOT EXISTS idx_b_staff ON bookings(staff_id, start_ms);
CREATE INDEX IF NOT EXISTS idx_b_org ON bookings(org_id, start_ms);
-- Garde-fou base de donnees : aucun chevauchement actif pour un meme employe
CREATE TRIGGER IF NOT EXISTS bookings_no_overlap_ins BEFORE INSERT ON bookings
WHEN NEW.status IN ('pending','confirmed')
BEGIN SELECT RAISE(ABORT,'slot_unavailable') WHERE EXISTS(
  SELECT 1 FROM bookings b WHERE b.staff_id=NEW.staff_id AND b.status IN ('pending','confirmed')
  AND b.start_ms < NEW.occ_end_ms AND NEW.start_ms < b.occ_end_ms); END;
CREATE TRIGGER IF NOT EXISTS bookings_no_overlap_upd BEFORE UPDATE OF start_ms,occ_end_ms,staff_id,status ON bookings
WHEN NEW.status IN ('pending','confirmed')
BEGIN SELECT RAISE(ABORT,'slot_unavailable') WHERE EXISTS(
  SELECT 1 FROM bookings b WHERE b.id<>NEW.id AND b.staff_id=NEW.staff_id AND b.status IN ('pending','confirmed')
  AND b.start_ms < NEW.occ_end_ms AND NEW.start_ms < b.occ_end_ms); END;
CREATE TABLE IF NOT EXISTS plans(
  code TEXT PRIMARY KEY, label TEXT NOT NULL, price_xof INTEGER NOT NULL, staff_max INTEGER,
  stats INTEGER NOT NULL, adv_notifications INTEGER NOT NULL, multi_user INTEGER NOT NULL, reports INTEGER NOT NULL,
  customization INTEGER NOT NULL, sort INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS subscriptions(
  org_id INTEGER PRIMARY KEY REFERENCES orgs(id) ON DELETE CASCADE, plan TEXT NOT NULL REFERENCES plans(code),
  status TEXT NOT NULL CHECK (status IN ('trialing','active','past_due','cancelled')),
  trial_ends_ms INTEGER NOT NULL, period_end_ms INTEGER);
CREATE TABLE IF NOT EXISTS invoices(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  number TEXT UNIQUE NOT NULL, plan TEXT NOT NULL, amount INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'XOF',
  status TEXT NOT NULL CHECK (status IN ('open','paid','void')), provider TEXT, provider_ref TEXT,
  issued_ms INTEGER NOT NULL, paid_ms INTEGER);
CREATE TABLE IF NOT EXISTS notif_settings(
  org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE, event TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('email','sms','whatsapp')), enabled INTEGER NOT NULL DEFAULT 1,
  lead_hours INTEGER, PRIMARY KEY(org_id,event,channel));
CREATE TABLE IF NOT EXISTS outbox(
  id INTEGER PRIMARY KEY, org_id INTEGER REFERENCES orgs(id) ON DELETE CASCADE,
  booking_id INTEGER REFERENCES bookings(id) ON DELETE CASCADE, audience TEXT NOT NULL CHECK (audience IN ('client','pro')),
  channel TEXT NOT NULL, event TEXT NOT NULL, recipient TEXT NOT NULL, body TEXT NOT NULL,
  send_at INTEGER NOT NULL, sent_at INTEGER, status TEXT NOT NULL DEFAULT 'queued', error TEXT);
CREATE TABLE IF NOT EXISTS reviews(
  id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  booking_id INTEGER UNIQUE REFERENCES bookings(id), author TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5), comment TEXT DEFAULT '',
  published INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS logs(
  id INTEGER PRIMARY KEY, org_id INTEGER, actor INTEGER, action TEXT NOT NULL, detail TEXT, ts INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS reset_tokens(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_ms INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS site_content(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS complaints(
  id INTEGER PRIMARY KEY, org_id INTEGER REFERENCES orgs(id) ON DELETE SET NULL, from_name TEXT NOT NULL,
  contact TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS offers(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, label TEXT NOT NULL, trial_days INTEGER NOT NULL DEFAULT 14,
  percent_off INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
`;

export const now = () => Date.now();

// Transaction immediate : verrou d'ecriture pris avant toute lecture de disponibilite
export function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
}

export function seedReference(db) {
  const c = db.prepare('INSERT OR IGNORE INTO countries(code,name,currency,timezone,dial,providers) VALUES (?,?,?,?,?,?)');
  c.run('SN','Sénégal','XOF','Africa/Dakar','+221','["wave","orange_money"]');
  c.run('CI',"Côte d'Ivoire",'XOF','Africa/Abidjan','+225','["wave","orange_money","mtn_momo"]');
  c.run('BJ','Bénin','XOF','Africa/Porto-Novo','+229','["mtn_momo","moov_money"]');
  c.run('TG','Togo','XOF','Africa/Lome','+228','["tmoney","moov_money"]');
  c.run('CM','Cameroun','XAF','Africa/Douala','+237','["mtn_momo","orange_money"]');
  c.run('FR','France','EUR','Europe/Paris','+33','["card"]');
  const cat = db.prepare('INSERT OR IGNORE INTO categories(slug,label) VALUES (?,?)');
  for (const [s,l] of [['coiffure','Coiffure'],['barbier','Barbier'],['beaute','Institut de beauté'],['spa','Spa et bien-être'],
    ['photographe','Photographe'],['coach','Coach sportif'],['consultant','Consultant'],['formation','Centre de formation'],['sante','Cabinet professionnel']]) cat.run(s,l);
  const p = db.prepare('INSERT OR IGNORE INTO plans VALUES (?,?,?,?,?,?,?,?,?,?)');
  p.run('starter','Starter',5000,1,0,0,0,0,0,1);
  p.run('pro','Pro',10000,10,1,1,0,0,1,2);
  p.run('business','Business',20000,null,1,1,1,1,1,3);
  db.prepare("INSERT OR IGNORE INTO site_content(key,value) VALUES ('trial_days','14')").run();
  db.prepare("INSERT OR IGNORE INTO offers(code,label,trial_days) VALUES ('LANCEMENT','Essai prolongé de lancement',30)").run();
}
