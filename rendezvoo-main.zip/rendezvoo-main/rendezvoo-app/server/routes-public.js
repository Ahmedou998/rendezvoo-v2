import { createHash, randomBytes, createHmac, timingSafeEqual } from 'node:crypto';
import { hashPassword, verifyPassword, signSession, cookie } from './auth.js';
import { AppError, availableSlots, createBooking, cancelBooking, rescheduleBooking } from './booking.js';
import { json, str, int, limit, currentUser, log, RESERVED } from './core.js';
import { ensureNotifDefaults } from './notify.js';
import { localDate, localTime, isDate } from './time.js';
import { tx } from './db.js';

export function publicOrg(db, org) {
  const services = db.prepare('SELECT id,name,description,duration_min,price FROM services WHERE org_id=? AND active=1 ORDER BY id').all(org.id);
  const staff = db.prepare('SELECT id,name FROM staff WHERE org_id=? AND active=1 ORDER BY id').all(org.id);
  for (const s of staff) s.service_ids = db.prepare('SELECT service_id FROM staff_services WHERE staff_id=?').all(s.id).map(r => r.service_id);
  const hours = db.prepare(`SELECT weekday, MIN(start) start, MAX(end) end FROM working_hours WHERE org_id=? GROUP BY weekday ORDER BY weekday`).all(org.id);
  const reviews = db.prepare('SELECT author,rating,comment,created_at FROM reviews WHERE org_id=? AND published=1 ORDER BY created_at DESC LIMIT 20').all(org.id);
  const agg = db.prepare('SELECT COUNT(*) n, AVG(rating) avg FROM reviews WHERE org_id=? AND published=1').get(org.id);
  const cat = db.prepare('SELECT label FROM categories WHERE slug=?').get(org.category);
  return { slug: org.slug, name: org.name, category: org.category, category_label: cat?.label || '', city: org.city, country: org.country, timezone: org.timezone,
    currency: org.currency, bio: org.bio, address: org.address, phone: org.phone, accent: org.accent, cancel_window_hours: org.cancel_window_hours,
    services, staff, hours, reviews, rating: agg.n ? { count: agg.n, average: Math.round(agg.avg * 10) / 10 } : null };
}

const bookingView = (db, b) => {
  const o = db.prepare('SELECT name,slug,timezone,cancel_window_hours,address,phone FROM orgs WHERE id=?').get(b.org_id);
  const s = db.prepare('SELECT name FROM services WHERE id=?').get(b.service_id);
  const st = db.prepare('SELECT name FROM staff WHERE id=?').get(b.staff_id);
  const c = db.prepare('SELECT name FROM customers WHERE id=?').get(b.customer_id);
  const review = db.prepare('SELECT rating FROM reviews WHERE booking_id=?').get(b.id);
  return { token: b.token, status: b.status, start_ms: b.start_ms, end_ms: b.end_ms, date: localDate(b.start_ms, o.timezone), time: localTime(b.start_ms, o.timezone),
    price: b.price, service: s.name, staff: st.name, customer: c.name, org: o, can_cancel: ['pending', 'confirmed'].includes(b.status) && b.start_ms - Date.now() >= o.cancel_window_hours * 3600e3,
    can_review: b.status === 'completed' && !review, reviewed: !!review };
};

export function registerPublic(r, db) {
  r.get('/api/public/categories', (c) => json(c.res, 200, db.prepare('SELECT slug,label FROM categories WHERE active=1 ORDER BY label').all()));
  r.get('/api/public/countries', (c) => json(c.res, 200, db.prepare('SELECT code,name,currency,timezone,dial FROM countries WHERE active=1').all()));
  r.get('/api/public/plans', (c) => json(c.res, 200, { plans: db.prepare('SELECT * FROM plans ORDER BY sort').all(), trial_days: int(db.prepare("SELECT value FROM site_content WHERE key='trial_days'").get()?.value, 14) }));
  r.get('/api/public/content', (c) => json(c.res, 200, Object.fromEntries(db.prepare("SELECT key,value FROM site_content WHERE key LIKE 'home.%'").all().map(x => [x.key, x.value]))));

  r.get('/api/public/search', (c) => {
    const q = str(c.query.q, 60).toLowerCase(), cat = str(c.query.category, 40), city = str(c.query.city, 60).toLowerCase();
    const rows = db.prepare(`SELECT id FROM orgs WHERE suspended=0 AND (?='' OR category=?) AND (?='' OR lower(city)=?) AND (?='' OR lower(name) LIKE ? OR lower(bio) LIKE ?)
      AND EXISTS(SELECT 1 FROM subscriptions s WHERE s.org_id=orgs.id AND s.status<>'cancelled') ORDER BY name LIMIT 30`).all(cat, cat, city, city, q, `%${q}%`, `%${q}%`);
    json(c.res, 200, rows.map(x => { const o = publicOrg(db, db.prepare('SELECT * FROM orgs WHERE id=?').get(x.id));
      return { slug: o.slug, name: o.name, city: o.city, category_label: o.category_label, rating: o.rating, from_price: o.services.length ? Math.min(...o.services.map(s => s.price)) : null, currency: o.currency }; }));
  });

  r.get('/api/public/org/:slug', (c) => {
    const org = db.prepare('SELECT * FROM orgs WHERE slug=?').get(c.params.slug);
    if (!org || org.suspended) throw new AppError('not_found', 404);
    json(c.res, 200, publicOrg(db, org));
  });

  r.get('/api/public/slots', (c) => {
    limit(c.req, 'slots', 120, 60e3);
    const org = db.prepare('SELECT * FROM orgs WHERE slug=? AND suspended=0').get(str(c.query.slug, 40));
    if (!org) throw new AppError('not_found', 404);
    const date = str(c.query.date, 10); if (!isDate(date)) throw new AppError('invalid_date');
    const slots = availableSlots(db, org.id, int(c.query.service), date, int(c.query.staff) || null);
    // Sans preference d'employe : un seul creneau par heure de debut
    const seen = new Set(); const out = [];
    for (const s of slots) { if (!c.query.staff && seen.has(s.start_ms)) continue; seen.add(s.start_ms); out.push({ ...s, time: localTime(s.start_ms, org.timezone) }); }
    json(c.res, 200, { date, timezone: org.timezone, slots: out });
  });

  r.post('/api/public/book', (c) => {
    limit(c.req, 'book', 8, 60e3);
    const b = c.body; const org = db.prepare('SELECT * FROM orgs WHERE slug=?').get(str(b.slug, 40));
    if (!org) throw new AppError('not_found', 404);
    const bk = createBooking(db, { orgId: org.id, serviceId: int(b.service_id), staffId: int(b.staff_id) || null, startMs: int(b.start_ms),
      name: b.name, phone: b.phone, email: b.email, notes: b.notes, source: 'online' });
    json(c.res, 201, bookingView(db, bk));
  });

  const byToken = (t) => { const b = db.prepare('SELECT * FROM bookings WHERE token=?').get(str(t, 64)); if (!b) throw new AppError('not_found', 404); return b; };
  r.get('/api/public/booking/:token', (c) => json(c.res, 200, bookingView(db, byToken(c.params.token))));
  r.post('/api/public/booking/:token/cancel', (c) => {
    limit(c.req, 'cancel', 10, 60e3);
    const b = byToken(c.params.token); cancelBooking(db, b, { byClient: true });
    json(c.res, 200, bookingView(db, byToken(c.params.token)));
  });
  r.post('/api/public/booking/:token/reschedule', (c) => {
    limit(c.req, 'resched', 10, 60e3);
    const b = byToken(c.params.token); const org = db.prepare('SELECT * FROM orgs WHERE id=?').get(b.org_id);
    if (!['pending', 'confirmed'].includes(b.status)) throw new AppError('not_modifiable', 409);
    if (b.start_ms - Date.now() < org.cancel_window_hours * 3600e3) throw new AppError('too_late_to_cancel', 409, { hours: org.cancel_window_hours });
    const startMs = int(c.body.start_ms); const date = localDate(startMs, org.timezone);
    const ok = availableSlots(db, org.id, b.service_id, date, b.staff_id, { excludeBooking: b.id }).some(s => s.start_ms === startMs);
    if (!ok) throw new AppError('slot_unavailable', 409);
    rescheduleBooking(db, b, startMs);
    json(c.res, 200, bookingView(db, byToken(c.params.token)));
  });
  r.post('/api/public/booking/:token/review', (c) => {
    limit(c.req, 'review', 5, 60e3);
    const b = byToken(c.params.token); if (b.status !== 'completed') throw new AppError('not_completed', 409);
    const rating = int(c.body.rating); if (rating < 1 || rating > 5) throw new AppError('invalid_rating');
    const cu = db.prepare('SELECT name FROM customers WHERE id=?').get(b.customer_id);
    try { db.prepare('INSERT INTO reviews(org_id,booking_id,author,rating,comment,created_at) VALUES (?,?,?,?,?,?)').run(b.org_id, b.id, cu.name.split(' ')[0], rating, str(c.body.comment, 600), Date.now()); }
    catch { throw new AppError('already_reviewed', 409); }
    json(c.res, 201, { ok: true });
  });
  r.post('/api/public/complaints', (c) => {
    limit(c.req, 'complaint', 3, 3600e3);
    const org = c.body.slug ? db.prepare('SELECT id FROM orgs WHERE slug=?').get(str(c.body.slug, 40)) : null;
    if (str(c.body.message, 2000).length < 10) throw new AppError('message_too_short');
    db.prepare('INSERT INTO complaints(org_id,from_name,contact,message,created_at) VALUES (?,?,?,?,?)').run(org?.id ?? null, str(c.body.name, 80) || 'Anonyme', str(c.body.contact, 120), str(c.body.message, 2000), Date.now());
    json(c.res, 201, { ok: true });
  });

  // ---- Authentification
  r.post('/api/auth/register', (c) => {
    limit(c.req, 'register', 5, 3600e3);
    const b = c.body; const email = str(b.email, 120).toLowerCase(), pw = String(b.password || ''), name = str(b.name, 80), biz = str(b.business, 80);
    const slug = str(b.slug, 40).toLowerCase().replace(/^@/, '');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new AppError('invalid_email');
    if (pw.length < 8 || pw.length > 128) throw new AppError('weak_password');
    if (name.length < 2 || biz.length < 2) throw new AppError('invalid_name');
    if (!/^[a-z0-9-]{3,40}$/.test(slug) || RESERVED.has(slug)) throw new AppError('invalid_slug');
    const country = db.prepare('SELECT * FROM countries WHERE code=? AND active=1').get(str(b.country, 2).toUpperCase() || 'SN');
    if (!country) throw new AppError('invalid_country');
    const cat = db.prepare('SELECT slug FROM categories WHERE slug=? AND active=1').get(str(b.category, 40));
    const offer = b.offer ? db.prepare('SELECT * FROM offers WHERE code=? AND active=1').get(str(b.offer, 30).toUpperCase()) : null;
    const trial = offer ? offer.trial_days : int(db.prepare("SELECT value FROM site_content WHERE key='trial_days'").get()?.value, 14);
    let orgId, uid;
    try {
      tx(db, () => {
        uid = db.prepare('INSERT INTO users(email,pass_hash,name,created_at) VALUES (?,?,?,?)').run(email, hashPassword(pw), name, Date.now()).lastInsertRowid;
        orgId = db.prepare(`INSERT INTO orgs(slug,name,category,city,country,timezone,currency,created_at) VALUES (?,?,?,?,?,?,?,?)`)
          .run(slug, biz, cat?.slug ?? null, str(b.city, 60), country.code, country.timezone, country.currency, Date.now()).lastInsertRowid;
        db.prepare("INSERT INTO members VALUES (?,?,'owner')").run(orgId, uid);
        db.prepare("INSERT INTO subscriptions(org_id,plan,status,trial_ends_ms) VALUES (?,'starter','trialing',?)").run(orgId, Date.now() + trial * 864e5);
        const sid = db.prepare('INSERT INTO staff(org_id,name) VALUES (?,?)').run(orgId, name).lastInsertRowid;
        const wh = db.prepare('INSERT INTO working_hours(org_id,staff_id,weekday,start,end) VALUES (?,?,?,?,?)');
        for (const d of [1, 2, 3, 4, 5, 6]) wh.run(orgId, sid, d, '09:00', '18:00');
        ensureNotifDefaults(db, orgId); log(db, orgId, uid, 'org.created', { slug });
      });
    } catch (e) {
      if (/UNIQUE.*users\.email/.test(e.message)) throw new AppError('email_taken', 409);
      if (/UNIQUE.*orgs\.slug/.test(e.message)) throw new AppError('slug_taken', 409);
      throw e;
    }
    json(c.res, 201, { ok: true, slug }, { 'Set-Cookie': cookie(signSession(uid)) });
  });
  r.post('/api/auth/login', (c) => {
    limit(c.req, 'login', 10, 600e3);
    const u = db.prepare('SELECT * FROM users WHERE email=?').get(str(c.body.email, 120).toLowerCase());
    if (!u || u.suspended || !verifyPassword(String(c.body.password || ''), u.pass_hash)) throw new AppError('invalid_credentials', 401);
    json(c.res, 200, { ok: true, platform_role: u.platform_role }, { 'Set-Cookie': cookie(signSession(u.id)) });
  });
  r.post('/api/auth/forgot', (c) => {
    limit(c.req, 'forgot', 5, 3600e3);
    const u = db.prepare('SELECT id,email FROM users WHERE email=? AND suspended=0').get(str(c.body.email, 120).toLowerCase());
    if (u) {
      const token = randomBytes(24).toString('hex'); const link = `${(process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '')}/reset?token=${token}`;
      db.prepare('INSERT INTO reset_tokens(token_hash,user_id,expires_ms) VALUES (?,?,?)').run(createHash('sha256').update(token).digest('hex'), u.id, Date.now() + 3600e3);
      db.prepare("INSERT INTO outbox(org_id,booking_id,audience,channel,event,recipient,body,send_at) VALUES (NULL,NULL,'client','email','password_reset',?,?,?)").run(u.email, `Pour choisir un nouveau mot de passe RENDEZVOO (valable 1 heure) : ${link}`, Date.now());
      if (!process.env.RESEND_API_KEY) console.log(`[DEV] Lien de reinitialisation pour ${u.email} : ${link}`);   // sans prestataire e-mail, le lien n'est visible que dans les journaux du serveur
    }
    json(c.res, 200, { ok: true });   // meme reponse que le compte existe ou non
  });
  r.post('/api/auth/reset', (c) => {
    limit(c.req, 'reset', 10, 3600e3);
    const pw = String(c.body.password || ''); if (pw.length < 8 || pw.length > 128) throw new AppError('weak_password');
    const th = createHash('sha256').update(str(c.body.token, 80)).digest('hex');
    const t = db.prepare('SELECT * FROM reset_tokens WHERE token_hash=? AND used=0 AND expires_ms>?').get(th, Date.now()); if (!t) throw new AppError('invalid_token', 400);
    tx(db, () => { db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(hashPassword(pw), t.user_id); db.prepare('UPDATE reset_tokens SET used=1 WHERE user_id=?').run(t.user_id); });
    log(db, null, t.user_id, 'auth.password_reset'); json(c.res, 200, { ok: true });
  });
  // Webhook du prestataire de paiement : signature HMAC-SHA256 du corps brut (PAYMENT_WEBHOOK_SECRET)
  r.post('/api/webhooks/payment', (c) => {
    const secret = process.env.PAYMENT_WEBHOOK_SECRET; if (!secret) throw new AppError('webhook_not_configured', 501);
    const sig = Buffer.from(String(c.req.headers['x-signature'] || ''), 'hex'), good = createHmac('sha256', secret).update(c.req.rawBody || '').digest();
    if (sig.length !== good.length || !timingSafeEqual(sig, good)) throw new AppError('bad_signature', 401);
    const inv = db.prepare('SELECT * FROM invoices WHERE number=?').get(str(c.body.reference, 40)); if (!inv) throw new AppError('not_found', 404);
    if (c.body.status === 'paid' && inv.status === 'open' && int(c.body.amount) === inv.amount) {
      db.prepare("UPDATE invoices SET status='paid', paid_ms=?, provider=?, provider_ref=? WHERE id=?").run(Date.now(), str(c.body.provider, 30) || 'provider', str(c.body.provider_ref, 80), inv.id);
      db.prepare("UPDATE subscriptions SET status='active', period_end_ms=? WHERE org_id=?").run(Date.now() + 30 * 864e5, inv.org_id); log(db, inv.org_id, null, 'invoice.paid', { number: inv.number, mode: 'webhook' });
    }
    json(c.res, 200, { ok: true });
  });
  r.post('/api/auth/logout', (c) => json(c.res, 200, { ok: true }, { 'Set-Cookie': cookie('', 0) }));
  r.get('/api/me', (c) => {
    const u = currentUser(db, c.req); if (!u) throw new AppError('unauthorized', 401);
    const orgs = db.prepare('SELECT o.id,o.slug,o.name,m.role FROM members m JOIN orgs o ON o.id=m.org_id WHERE m.user_id=?').all(u.id);
    json(c.res, 200, { user: u, orgs });
  });
}
