import { readSession, parseCookies, rateLimit } from './auth.js';
import { AppError } from './booking.js';

export const json = (res, status, data, headers = {}) => {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
};
export function readBody(req, limit = 100_000) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0, over = false;
    req.on('data', (c) => { size += c.length; if (size > limit) { over = true; chunks.length = 0; } else if (!over) chunks.push(c); });  // on vide le flux sans le stocker
    req.on('error', reject);
    req.on('end', () => {
      if (over) return reject(new AppError('payload_too_large', 413));
      if (!size) return resolve({});
      try { const raw = Buffer.concat(chunks).toString(); req.rawBody = raw; resolve(JSON.parse(raw)); } catch { reject(new AppError('invalid_json')); }
    });
  });
}
// X-Forwarded-For n'est cru que derriere un proxy declare (TRUST_PROXY=1), sinon il serait falsifiable
export const ip = (req) => ((process.env.TRUST_PROXY === '1' && req.headers['x-forwarded-for']) || req.socket.remoteAddress || '').toString().split(',')[0].trim();
export const limit = (req, name, max, win) => { if (!rateLimit(name + ':' + ip(req), max, win)) throw new AppError('rate_limited', 429); };
export const str = (v, max = 200) => String(v ?? '').trim().slice(0, max);
export const int = (v, d = 0) => { const n = Math.trunc(Number(v)); return Number.isFinite(n) ? n : d; };

export function currentUser(db, req) {
  const s = readSession(parseCookies(req.headers.cookie).rv_session);
  if (!s) return null;
  const u = db.prepare('SELECT id,email,name,platform_role,suspended FROM users WHERE id=?').get(s.uid);
  return u && !u.suspended ? u : null;
}
export function proContext(db, req) {
  const user = currentUser(db, req); if (!user) throw new AppError('unauthorized', 401);
  const wanted = int(req.headers['x-org-id']);
  const mem = db.prepare(`SELECT m.org_id, m.role FROM members m WHERE m.user_id=? ${wanted ? 'AND m.org_id=?' : ''} ORDER BY m.org_id LIMIT 1`).get(...(wanted ? [user.id, wanted] : [user.id]));
  if (!mem) throw new AppError('no_organization', 403);
  const org = db.prepare('SELECT * FROM orgs WHERE id=?').get(mem.org_id);
  const plan = db.prepare('SELECT p.* FROM subscriptions s JOIN plans p ON p.code=s.plan WHERE s.org_id=?').get(org.id);
  return { user, org, role: mem.role, plan };
}
export const needAdmin = (c) => { if (!['owner', 'admin'].includes(c.role)) throw new AppError('forbidden', 403); };
export function log(db, orgId, actor, action, detail) {
  db.prepare('INSERT INTO logs(org_id,actor,action,detail,ts) VALUES (?,?,?,?,?)').run(orgId ?? null, actor ?? null, action, detail ? JSON.stringify(detail) : null, Date.now());
}
export const RESERVED = new Set(['admin', 'app', 'api', 'login', 'register', 'static', 'r', 'metier', 'tarifs', 'sitemap', 'robots', 'rendezvoo', 'www', 'support', 'help']);
