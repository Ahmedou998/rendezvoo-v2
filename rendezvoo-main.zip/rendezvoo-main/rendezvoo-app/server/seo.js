// Pages indexables rendues cote serveur : profils /@slug, pages metier x ville, sitemap, robots
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', 'public');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const slugify = (s) => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const base = () => (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
const tpl = (name) => readFileSync(join(ROOT, name), 'utf8');

function inject(html, { title, desc, url, image, ld, bodyData }) {
  const head = `<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${esc(url)}">
<meta property="og:type" content="website"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${esc(url)}">
<meta property="og:image" content="${esc(image || base() + '/img/og.svg')}"><meta name="twitter:card" content="summary_large_image">
${ld ? `<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, '\\u003c')}</script>` : ''}`;
  return html.replace('<!--SEO-->', head).replace('<!--DATA-->', bodyData || '');
}
const send = (res, status, html, type = 'text/html; charset=utf-8') => { res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-cache' }); res.end(html); };

export function seo(db, publicOrg) {
  return async (req, res, path, url) => {
    let m;
    if (path === '/robots.txt') { send(res, 200, `User-agent: *\nAllow: /\nDisallow: /app\nDisallow: /admin\nDisallow: /api/\nDisallow: /r/\nSitemap: ${base()}/sitemap.xml\n`, 'text/plain; charset=utf-8'); return true; }
    if (path === '/sitemap.xml') {
      const urls = [base() + '/', base() + '/tarifs'];
      for (const o of db.prepare('SELECT slug FROM orgs WHERE suspended=0').all()) urls.push(`${base()}/@${o.slug}`);
      for (const p of db.prepare("SELECT DISTINCT category cat, city FROM orgs WHERE suspended=0 AND category IS NOT NULL AND city<>''").all()) urls.push(`${base()}/metier/${p.cat}/${slugify(p.city)}`);
      send(res, 200, `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(u => `<url><loc>${esc(u)}</loc></url>`).join('')}</urlset>`, 'application/xml'); return true;
    }
    if ((m = path.match(/^\/@([a-z0-9-]{3,40})$/))) {
      const org = db.prepare('SELECT * FROM orgs WHERE slug=?').get(m[1]);
      if (!org || org.suspended) { send(res, 404, tpl('404.html')); return true; }
      const o = publicOrg(db, org);
      const ld = { '@context': 'https://schema.org', '@type': 'LocalBusiness', name: o.name, description: o.bio || undefined, url: `${base()}/@${o.slug}`, telephone: o.phone || undefined,
        address: o.address || o.city ? { '@type': 'PostalAddress', streetAddress: o.address || undefined, addressLocality: o.city || undefined, addressCountry: o.country } : undefined,
        aggregateRating: o.rating ? { '@type': 'AggregateRating', ratingValue: o.rating.average, reviewCount: o.rating.count } : undefined,
        makesOffer: o.services.map(s => ({ '@type': 'Offer', priceCurrency: o.currency, price: s.price, itemOffered: { '@type': 'Service', name: s.name } })) };
      const fallback = `<noscript><h1>${esc(o.name)}</h1><p>${esc(o.bio)}</p><ul>${o.services.map(s => `<li>${esc(s.name)} – ${s.duration_min} min – ${s.price} ${esc(o.currency)}</li>`).join('')}</ul></noscript>`;
      send(res, 200, inject(tpl('book.html'), { title: `${o.name} – Réserver en ligne | RENDEZVOO`, desc: (o.bio || `Réservez chez ${o.name}${o.city ? ' à ' + o.city : ''} en quelques secondes.`).slice(0, 155), url: `${base()}/@${o.slug}`, ld, bodyData: fallback })); return true;
    }
    if ((m = path.match(/^\/r\/([a-f0-9]{32})$/))) { send(res, 200, inject(tpl('manage.html'), { title: 'Votre rendez-vous | RENDEZVOO', desc: 'Gérez votre rendez-vous.', url: base() + path }).replace('<head>', '<head><meta name="robots" content="noindex">')); return true; }
    if ((m = path.match(/^\/metier\/([a-z0-9-]+)\/([a-z0-9-]+)$/))) {
      const cat = db.prepare('SELECT * FROM categories WHERE slug=? AND active=1').get(m[1]);
      const orgs = cat ? db.prepare('SELECT id,city FROM orgs WHERE suspended=0 AND category=?').all(cat.slug).filter(o => slugify(o.city) === m[2]) : [];
      if (!cat || !orgs.length) { send(res, 404, tpl('404.html')); return true; }
      const city = orgs[0].city, list = orgs.map(o => publicOrg(db, db.prepare('SELECT * FROM orgs WHERE id=?').get(o.id)));
      const body = `<ul class="dir">${list.map(o => `<li><a href="/@${esc(o.slug)}"><strong>${esc(o.name)}</strong><span>${esc(city)}${o.services.length ? ' · dès ' + Math.min(...o.services.map(s => s.price)) + ' ' + esc(o.currency) : ''}</span></a></li>`).join('')}</ul>`;
      const html = inject(tpl('directory.html'), { title: `${cat.label} à ${city} – Réservation en ligne | RENDEZVOO`, desc: `Réservez en ligne un rendez-vous chez ${list.length} professionnel(s) : ${cat.label.toLowerCase()} à ${city}.`, url: `${base()}${path}`,
        ld: { '@context': 'https://schema.org', '@type': 'ItemList', itemListElement: list.map((o, i) => ({ '@type': 'ListItem', position: i + 1, url: `${base()}/@${o.slug}`, name: o.name })) } })
        .replace('{{H1}}', esc(`${cat.label} à ${city}`)).replace('{{LIST}}', body);
      send(res, 200, html); return true;
    }
    return false;
  };
}
