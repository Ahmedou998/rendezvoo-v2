import { createServer } from 'node:http';
import { openDb, seedReference } from './db.js';
import { createApp } from './app.js';
import { flushOutbox } from './notify.js';

const db = openDb(); seedReference(db);
const PORT = Number(process.env.PORT || 3000);
const server = createServer(createApp(db));
server.listen(PORT, () => console.log(`RENDEZVOO sur http://localhost:${PORT}`));
const timer = setInterval(() => flushOutbox(db).catch(e => console.error('outbox', e)), 30_000); timer.unref();
const stop = () => { clearInterval(timer); server.close(() => { db.close(); process.exit(0); }); setTimeout(() => process.exit(0), 3000).unref(); };
process.on('SIGTERM', stop); process.on('SIGINT', stop);
