import { hashPassword, can } from './auth.js';
import { AppError } from './booking.js';
import { json, str, int, currentUser, log } from './core.js';

export function registerAdmin(r, db) {
  const A = (method, path, perm, fn) => r[method]('/api/admin' + path, (c) => {
    const u = currentUser(db, c.req); if (!u || !u.platform_role) throw new AppError('forbidden', 403);
    if (!can(u.platform_role, perm)) throw new AppError('forbidden', 403, { needs: perm });
    return fn(c, u);
  });
  const count = (sql, ...a) => db.prepare(sql).get(...a).n;

  A('get', '/overview', 'orgs.read', (c, u) => {
    const mrr = db.prepare("SELECT COALESCE(SUM(p.price_xof),0) v FROM subscriptions s JOIN plans p ON p.code=s.plan WHERE s.status='active'").get().v;
    json(c.res, 200, { role: u.platform_role, orgs: count('SELECT COUNT(*) n FROM orgs'), suspended: count('SELECT COUNT(*) n FROM orgs WHERE suspended=1'),
      trialing: count("SELECT COUNT(*) n FROM subscriptions WHERE status='trialing'"), active: count("SELECT COUNT(*) n FROM subscriptions WHERE status='active'"),
      past_due: count("SELECT COUNT(*) n FROM subscriptions WHERE status='past_due'"), bookings: count('SELECT COUNT(*) n FROM bookings'),
      bookings_30d: count('SELECT COUNT(*) n FROM bookings WHERE created_at>?', Date.now() - 30 * 864e5), customers: count('SELECT COUNT(*) n FROM customers'),
      mrr_xof: can(u.platform_role, 'stats') ? mrr : null, open_complaints: count("SELECT COUNT(*) n FROM complaints WHERE status='open'"),
      by_plan: db.prepare('SELECT plan, COUNT(*) n FROM subscriptions GROUP BY plan').all() });
  });
  A('get', '/orgs', 'orgs.read', (c) => {
    const q = `%${str(c.query.q, 60).toLowerCase()}%`;
    json(c.res, 200, db.prepare(`SELECT o.id,o.slug,o.name,o.city,o.country,o.category,o.suspended,o.created_at,s.plan,s.status sub_status,s.trial_ends_ms,
      (SELECT COUNT(*) FROM bookings b WHERE b.org_id=o.id) bookings, (SELECT u.email FROM members m JOIN users u ON u.id=m.user_id WHERE m.org_id=o.id AND m.role='owner') owner
      FROM orgs o JOIN subscriptions s ON s.org_id=o.id WHERE lower(o.name) LIKE ? OR o.slug LIKE ? ORDER BY o.id DESC LIMIT 300`).all(q, q));
  });
  A('patch', '/orgs/:id/suspend', 'orgs.suspend', (c, u) => {
    const id = int(c.params.id); if (!db.prepare('SELECT 1 FROM orgs WHERE id=?').get(id)) throw new AppError('not_found', 404);
    db.prepare('UPDATE orgs SET suspended=? WHERE id=?').run(c.body.suspended ? 1 : 0, id); log(db, id, u.id, c.body.suspended ? 'admin.org.suspended' : 'admin.org.restored', { reason: str(c.body.reason, 200) });
    json(c.res, 200, { ok: true });
  });
  A('get', '/users', 'users.read', (c) => json(c.res, 200, db.prepare('SELECT id,email,name,platform_role,suspended,created_at FROM users ORDER BY id DESC LIMIT 300').all()));
  A('patch', '/users/:id', '*', (c, u) => {
    const id = int(c.params.id);
    if (c.body.platform_role !== undefined) {
      if (c.body.platform_role !== null && !['superadmin', 'support', 'finance'].includes(c.body.platform_role)) throw new AppError('invalid_role');
      if (id === u.id && c.body.platform_role !== 'superadmin') throw new AppError('cannot_demote_self', 409);
      db.prepare('UPDATE users SET platform_role=? WHERE id=?').run(c.body.platform_role, id);
    }
    if (c.body.suspended !== undefined) { if (id === u.id) throw new AppError('cannot_suspend_self', 409); db.prepare('UPDATE users SET suspended=? WHERE id=?').run(c.body.suspended ? 1 : 0, id); }
    log(db, null, u.id, 'admin.user.updated', { id, ...c.body }); json(c.res, 200, { ok: true });
  });
  A('post', '/users', '*', (c, u) => {
    const b = c.body; if (!['superadmin', 'support', 'finance'].includes(b.platform_role) || String(b.password || '').length < 12 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(str(b.email))) throw new AppError('invalid_user');
    try { db.prepare('INSERT INTO users(email,pass_hash,name,platform_role,created_at) VALUES (?,?,?,?,?)').run(str(b.email, 120).toLowerCase(), hashPassword(b.password), str(b.name, 80) || 'Admin', b.platform_role, Date.now()); }
    catch { throw new AppError('email_taken', 409); }
    log(db, null, u.id, 'admin.user.created', { email: b.email, role: b.platform_role }); json(c.res, 201, { ok: true });
  });
  A('get', '/subscriptions', 'subscriptions', (c) => json(c.res, 200, db.prepare('SELECT s.*, o.name, o.slug FROM subscriptions s JOIN orgs o ON o.id=s.org_id ORDER BY s.org_id DESC LIMIT 300').all()));
  A('patch', '/subscriptions/:orgId', 'subscriptions', (c, u) => {
    const orgId = int(c.params.orgId); const s = db.prepare('SELECT * FROM subscriptions WHERE org_id=?').get(orgId); if (!s) throw new AppError('not_found', 404);
    const plan = c.body.plan ?? s.plan, status = c.body.status ?? s.status;
    if (!db.prepare('SELECT 1 FROM plans WHERE code=?').get(plan) || !['trialing', 'active', 'past_due', 'cancelled'].includes(status)) throw new AppError('invalid_subscription');
    const trial = c.body.extend_trial_days ? s.trial_ends_ms + int(c.body.extend_trial_days) * 864e5 : s.trial_ends_ms;
    db.prepare('UPDATE subscriptions SET plan=?, status=?, trial_ends_ms=? WHERE org_id=?').run(plan, status, trial, orgId); log(db, orgId, u.id, 'admin.subscription.updated', c.body);
    json(c.res, 200, { ok: true });
  });
  A('get', '/invoices', 'invoices', (c) => json(c.res, 200, db.prepare('SELECT i.*, o.name org FROM invoices i JOIN orgs o ON o.id=i.org_id ORDER BY i.id DESC LIMIT 300').all()));
  A('patch', '/invoices/:id', 'invoices', (c, u) => {
    const inv = db.prepare('SELECT * FROM invoices WHERE id=?').get(int(c.params.id)); if (!inv) throw new AppError('not_found', 404);
    if (c.body.status === 'paid') { db.prepare("UPDATE invoices SET status='paid', paid_ms=?, provider='manual' WHERE id=?").run(Date.now(), inv.id); db.prepare("UPDATE subscriptions SET status='active', period_end_ms=? WHERE org_id=?").run(Date.now() + 30 * 864e5, inv.org_id); }
    else if (c.body.status === 'void') db.prepare("UPDATE invoices SET status='void' WHERE id=?").run(inv.id); else throw new AppError('invalid_status');
    log(db, inv.org_id, u.id, 'admin.invoice.' + c.body.status, { number: inv.number }); json(c.res, 200, { ok: true });
  });
  A('get', '/complaints', 'complaints', (c) => json(c.res, 200, db.prepare('SELECT c.*, o.name org FROM complaints c LEFT JOIN orgs o ON o.id=c.org_id ORDER BY c.id DESC LIMIT 200').all()));
  A('patch', '/complaints/:id', 'complaints', (c, u) => { db.prepare('UPDATE complaints SET status=? WHERE id=?').run(c.body.status === 'resolved' ? 'resolved' : 'open', int(c.params.id)); log(db, null, u.id, 'admin.complaint.updated', { id: int(c.params.id) }); json(c.res, 200, { ok: true }); });
  A('get', '/offers', 'offers', (c) => json(c.res, 200, db.prepare('SELECT * FROM offers ORDER BY id DESC').all()));
  A('post', '/offers', 'offers', (c, u) => {
    const code = str(c.body.code, 30).toUpperCase(); if (!/^[A-Z0-9_-]{3,30}$/.test(code) || str(c.body.label, 80).length < 3) throw new AppError('invalid_offer');
    try { db.prepare('INSERT INTO offers(code,label,trial_days,percent_off) VALUES (?,?,?,?)').run(code, str(c.body.label, 80), Math.min(365, Math.max(0, int(c.body.trial_days, 14))), Math.min(100, Math.max(0, int(c.body.percent_off)))); }
    catch { throw new AppError('code_taken', 409); } log(db, null, u.id, 'admin.offer.created', { code }); json(c.res, 201, { ok: true });
  });
  A('patch', '/offers/:id', 'offers', (c) => { db.prepare('UPDATE offers SET active=? WHERE id=?').run(c.body.active ? 1 : 0, int(c.params.id)); json(c.res, 200, { ok: true }); });
  A('get', '/categories', 'content', (c) => json(c.res, 200, db.prepare('SELECT * FROM categories ORDER BY label').all()));
  A('post', '/categories', 'content', (c, u) => {
    const slug = str(c.body.slug, 40).toLowerCase(); if (!/^[a-z0-9-]{2,40}$/.test(slug) || str(c.body.label, 60).length < 2) throw new AppError('invalid_category');
    try { db.prepare('INSERT INTO categories(slug,label) VALUES (?,?)').run(slug, str(c.body.label, 60)); } catch { throw new AppError('slug_taken', 409); }
    log(db, null, u.id, 'admin.category.created', { slug }); json(c.res, 201, { ok: true });
  });
  A('patch', '/categories/:id', 'content', (c) => { db.prepare('UPDATE categories SET label=COALESCE(?,label), active=COALESCE(?,active) WHERE id=?').run(c.body.label ? str(c.body.label, 60) : null, c.body.active === undefined ? null : (c.body.active ? 1 : 0), int(c.params.id)); json(c.res, 200, { ok: true }); });
  A('get', '/content', 'content', (c) => json(c.res, 200, Object.fromEntries(db.prepare('SELECT key,value FROM site_content').all().map(x => [x.key, x.value]))));
  A('put', '/content', 'content', (c, u) => {
    for (const [k, v] of Object.entries(c.body)) { if (!/^(home\.[a-z_]{1,40}|trial_days)$/.test(k)) throw new AppError('invalid_key'); db.prepare('INSERT INTO site_content(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, str(v, 300)); }
    log(db, null, u.id, 'admin.content.updated', Object.keys(c.body)); json(c.res, 200, { ok: true });
  });
  A('get', '/logs', 'logs.read', (c) => json(c.res, 200, db.prepare('SELECT l.*, o.name org, u.email actor_email FROM logs l LEFT JOIN orgs o ON o.id=l.org_id LEFT JOIN users u ON u.id=l.actor ORDER BY l.id DESC LIMIT 200').all()));
  A('get', '/outbox', 'orgs.read', (c) => json(c.res, 200, db.prepare('SELECT status, COUNT(*) n FROM outbox GROUP BY status').all()));
}
