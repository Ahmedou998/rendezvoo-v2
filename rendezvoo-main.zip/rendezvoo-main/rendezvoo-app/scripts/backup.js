// Sauvegarde coherente a chaud : node scripts/backup.js [dossier]  (utilise VACUUM INTO, sans arreter le serveur)
import { DatabaseSync } from 'node:sqlite'; import { mkdirSync, readdirSync, rmSync } from 'node:fs'; import { join } from 'node:path';
const dir = process.argv[2] || process.env.BACKUP_DIR || 'backups'; mkdirSync(dir, { recursive: true });
const db = new DatabaseSync(process.env.DB_FILE || 'data/rendezvoo.db'); const out = join(dir, `rendezvoo-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`); db.close(); console.log('Sauvegarde :', out);
const keep = Number(process.env.BACKUP_KEEP || 14); const all = readdirSync(dir).filter(f => f.startsWith('rendezvoo-')).sort(); for (const f of all.slice(0, Math.max(0, all.length - keep))) rmSync(join(dir, f));
