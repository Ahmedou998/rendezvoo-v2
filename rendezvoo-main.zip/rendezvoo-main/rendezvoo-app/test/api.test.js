import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { openDb, seedReference } from '../server/db.js';
import { createApp } from '../server/app.js';
import { hashPassword } from '../server/auth.js';
import { flushOutbox } from '../server/notify.js';
import { addDays, localDate } from '../server/time.js';

process.env.SESSION_SECRET = 'test-secret'; process.env.PAYMENT_MODE = 'test'; process.env.TRUST_PROXY = '1';
let db, server, base;
const jar = {};
async function api(method, path, body, who) {
  const headers = { 'Content-Type': 'application/json' }; if (who && jar[who]) headers.Cookie = jar[who];
  const r = await fetch(base + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'); if (sc && who) jar[who] = sc.split(';')[0];
  const ct = r.headers.get('content-type') || ''; return { status: r.status, data: ct.includes('json') ? await r.json() : await r.text(), headers: r.headers };
}
const workday = () => { let d = addDays(localDate(Date.now(), 'Africa/Dakar'), 2); while ([0].includes(new Date(d + 'T00:00:00Z').getUTCDay())) d = addDays(d, 1); return d; };
const reg = (n, extra = {}) => ({ email: `${n}@test.sn`, password: 'motdepasse-solide', name: 'Awa Diop', business: 'Salon ' + n, slug: 'salon-' + n, category: 'coiffure', city: 'Dakar', country: 'SN', ...extra });

before(async () => {
  db = openDb(':memory:'); seedReference(db);
  db.prepare("INSERT INTO users(email,pass_hash,name,platform_role,created_at) VALUES (?,?,?,?,?)").run('root@rv.com', hashPassword('administrateur-long'), 'Root', 'superadmin', Date.now());
  db.prepare("INSERT INTO users(email,pass_hash,name,platform_role,created_at) VALUES (?,?,?,?,?)").run('help@rv.com', hashPassword('support-long-pass'), 'Help', 'support', Date.now());
  server = createServer(createApp(db)); await new Promise(r => server.listen(0, r)); base = 'http://127.0.0.1:' + server.address().port;
});
after(() => { server.close(); db.close(); });

test('inscription, session et profil', async () => {
  assert.equal((await api('POST', '/api/auth/register', reg('a'), 'a')).status, 201);
  assert.equal((await api('POST', '/api/auth/register', reg('a'), 'x')).status, 409);              // email deja pris
  assert.equal((await api('POST', '/api/auth/register', reg('zz', { password: 'court' }))).data.error, 'weak_password');
  assert.equal((await api('POST', '/api/auth/register', reg('b', { slug: 'admin' }))).data.error, 'invalid_slug');
  const me = await api('GET', '/api/me', null, 'a'); assert.equal(me.status, 200); assert.equal(me.data.orgs[0].slug, 'salon-a');
  assert.equal((await api('GET', '/api/me')).status, 401);
  assert.equal((await api('POST', '/api/auth/login', { email: 'a@test.sn', password: 'faux' })).status, 401);
});

let date, svcId, staffId;
test('prestation, horaires et creneaux calcules cote serveur', async () => {
  const s = await api('POST', '/api/pro/services', { name: 'Coupe', duration_min: 30, buffer_min: 15, price: 5000 }, 'a'); assert.equal(s.status, 201); svcId = s.data.id;
  staffId = (await api('GET', '/api/pro/staff', null, 'a')).data[0].id;
  date = workday();
  const sl = await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`); assert.equal(sl.status, 200);
  assert.ok(sl.data.slots.length > 10); assert.equal(sl.data.slots[0].time, '09:00');
  const last = sl.data.slots.at(-1); assert.equal(last.time, '17:30');                               // 18:00 - 30 min
});

let first;
test('reservation sans compte + confirmation + notifications en file', async () => {
  const slots = (await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`)).data.slots; first = slots[0];
  const b = await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: first.start_ms, name: 'Fatou Ndiaye', phone: '+221 77 000 00 01', email: 'fatou@mail.sn' });
  assert.equal(b.status, 201); assert.equal(b.data.time, '09:00'); assert.match(b.data.token, /^[a-f0-9]{32}$/);
  // le temps de preparation (15 min) bloque 09:30 puis libere 09:45
  const after = (await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`)).data.slots.map(s => s.time);
  assert.ok(!after.includes('09:00') && !after.includes('09:15') && !after.includes('09:30')); assert.ok(after.includes('09:45'));
  const out = db.prepare("SELECT channel,audience,event FROM outbox WHERE org_id=(SELECT id FROM orgs WHERE slug='salon-a')").all();
  assert.ok(out.some(o => o.event === 'booking_confirmed' && o.audience === 'client' && o.channel === 'whatsapp'));
  assert.ok(out.some(o => o.audience === 'pro'));
  assert.ok(out.some(o => o.event === 'reminder'));
  await flushOutbox(db); assert.ok(db.prepare("SELECT COUNT(*) n FROM outbox WHERE status='test'").get().n > 0);   // pas de prestataire => statut test, rien d'envoye
});

test('refus du meme creneau et des creneaux invalides', async () => {
  const dup = await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: first.start_ms, name: 'Autre Client', phone: '+221770000002' });
  assert.equal(dup.status, 409); assert.equal(dup.data.error, 'slot_unavailable');
  assert.equal((await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: first.start_ms + 7 * 60e3, name: 'Hors grille', phone: '+221770000003' })).status, 409);
  assert.equal((await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: Date.now() - 1e6, name: 'Passe', phone: '+221770000004' })).status, 409);
  assert.equal((await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: first.start_ms, name: 'X', phone: '12' })).data.error, 'invalid_name');
});

test('concurrence : 12 reservations simultanees du meme creneau -> une seule reussit', async () => {
  const slots = (await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`)).data.slots; const target = slots[4];
  const res = await Promise.all(Array.from({ length: 12 }, (_, i) => fetch(base + '/api/public/book', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '10.0.0.' + i },
    body: JSON.stringify({ slug: 'salon-a', service_id: svcId, start_ms: target.start_ms, name: 'Client ' + i, phone: '+22177100000' + (i % 10) + i }) }).then(r => r.status)));
  assert.equal(res.filter(s => s === 201).length, 1); assert.equal(res.filter(s => s === 409).length, 11);
});

test('le declencheur SQL bloque aussi une ecriture directe qui chevauche', () => {
  const b = db.prepare("SELECT * FROM bookings WHERE status='confirmed' LIMIT 1").get();
  assert.throws(() => db.prepare(`INSERT INTO bookings(org_id,staff_id,service_id,customer_id,start_ms,end_ms,occ_end_ms,token,created_at) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(b.org_id, b.staff_id, b.service_id, b.customer_id, b.start_ms + 60000, b.end_ms, b.occ_end_ms, 'dup' + Date.now(), Date.now()), /slot_unavailable/);
});

test('annulation client par jeton selon la regle du professionnel', async () => {
  const slots = (await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`)).data.slots;
  const b = (await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: slots.at(-1).start_ms, name: 'Moussa Fall', phone: '+221770000009' })).data;
  assert.equal(b.can_cancel, true);
  db.prepare('UPDATE orgs SET cancel_window_hours=24*30 WHERE slug=?').run('salon-a');
  assert.equal((await api('POST', `/api/public/booking/${b.token}/cancel`)).data.error, 'too_late_to_cancel');
  db.prepare('UPDATE orgs SET cancel_window_hours=24 WHERE slug=?').run('salon-a');
  const c = await api('POST', `/api/public/booking/${b.token}/cancel`); assert.equal(c.status, 200); assert.equal(c.data.status, 'cancelled');
  assert.ok((await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`)).data.slots.some(s => s.start_ms === slots.at(-1).start_ms));  // creneau libere
  assert.equal((await api('POST', `/api/public/booking/${b.token}/cancel`)).status, 409);
});

test('deplacement par le client', async () => {
  const slots = (await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${date}`)).data.slots;
  const b = (await api('POST', '/api/public/book', { slug: 'salon-a', service_id: svcId, start_ms: slots[10].start_ms, name: 'Ibou Sy', phone: '+221770000010' })).data;
  const mv = await api('POST', `/api/public/booking/${b.token}/reschedule`, { start_ms: slots[12].start_ms }); assert.equal(mv.status, 200); assert.equal(mv.data.start_ms, slots[12].start_ms);
});

test('isolation entre organisations (multi-tenant)', async () => {
  await api('POST', '/api/auth/register', reg('b'), 'b');
  const mine = (await api('GET', `/api/pro/bookings?from=${date}&to=${date}`, null, 'b')).data; assert.equal(mine.length, 0);
  const clients = (await api('GET', '/api/pro/customers', null, 'b')).data; assert.equal(clients.length, 0);
  const bid = db.prepare("SELECT id FROM bookings LIMIT 1").get().id;
  assert.equal((await api('PATCH', `/api/pro/bookings/${bid}`, { status: 'completed' }, 'b')).status, 404);       // reservation d'une autre org
  assert.equal((await api('PUT', `/api/pro/services/${svcId}`, { name: 'Pirate', duration_min: 30, price: 1 }, 'b')).status, 404);
  assert.equal((await api('GET', '/api/pro/overview', null, 'b')).data.month_bookings, 0);
});

test('tableau de bord : reservations, statut termine, chiffre d\'affaires', async () => {
  const list = (await api('GET', `/api/pro/bookings?from=${date}&to=${date}`, null, 'a')).data; assert.ok(list.length >= 3);
  const one = list.find(b => b.status === 'confirmed');
  assert.equal((await api('PATCH', `/api/pro/bookings/${one.id}`, { status: 'completed' }, 'a')).status, 200);
  const manual = await api('POST', '/api/pro/bookings', { date, time: '16:00', service_id: svcId, staff_id: staffId, name: 'Client Comptoir', phone: '+221770000011' }, 'a'); assert.equal(manual.status, 201);
  assert.equal((await api('POST', '/api/pro/bookings', { date, time: '16:10', service_id: svcId, staff_id: staffId, name: 'Chevauche', phone: '+221770000012' }, 'a')).status, 409);
  const cust = (await api('GET', '/api/pro/customers?q=fatou', null, 'a')).data; assert.equal(cust.length, 1); assert.equal(cust[0].visits, 1);
});

test('limites de formule : employes, statistiques, rapports', async () => {
  assert.equal((await api('POST', '/api/pro/staff', { name: 'Coiffeur 2' }, 'a')).data.error, 'staff_limit_reached');   // Starter = 1 employe
  assert.equal((await api('GET', '/api/pro/stats', null, 'a')).status, 402);
  const ch = await api('POST', '/api/pro/subscription/change', { plan: 'pro' }, 'a'); assert.equal(ch.status, 200);
  const pay = await api('POST', `/api/pro/invoices/${ch.data.invoice_id}/pay`, {}, 'a'); assert.equal(pay.data.mode, 'test');
  assert.equal((await api('POST', '/api/pro/staff', { name: 'Coiffeur 2' }, 'a')).status, 201);
  const st = await api('GET', '/api/pro/stats', null, 'a'); assert.equal(st.status, 200); assert.ok(st.data.top_services.length >= 1);
  assert.equal((await api('GET', '/api/pro/report.csv', null, 'a')).status, 402);
  assert.equal((await api('POST', '/api/pro/subscription/change', { plan: 'starter' }, 'a')).data.error, 'too_many_staff_for_plan');
});

test('indisponibilites : conge retire les creneaux', async () => {
  const d2 = addDays(date, 1); const t = await api('POST', '/api/pro/timeoff', { staff_id: staffId, date: d2, start: '09:00', end: '12:00', reason: 'Formation' }, 'a'); assert.equal(t.status, 201);
  const times = (await api('GET', `/api/public/slots?slug=salon-a&service=${svcId}&date=${d2}&staff=${staffId}`)).data.slots.map(s => s.time);
  if (new Date(d2 + 'T00:00:00Z').getUTCDay() !== 0) { assert.ok(!times.includes('10:00')); assert.ok(times.includes('13:00')); }
});

test('avis : uniquement apres un rendez-vous termine, moderation par le pro', async () => {
  const done = db.prepare("SELECT token FROM bookings WHERE status='completed' LIMIT 1").get();
  const pending = db.prepare("SELECT token FROM bookings WHERE status='confirmed' LIMIT 1").get();
  assert.equal((await api('POST', `/api/public/booking/${pending.token}/review`, { rating: 5 })).status, 409);
  assert.equal((await api('POST', `/api/public/booking/${done.token}/review`, { rating: 5, comment: 'Parfait' })).status, 201);
  assert.equal((await api('POST', `/api/public/booking/${done.token}/review`, { rating: 5 })).status, 409);
  assert.equal((await api('GET', '/api/public/org/salon-a')).data.reviews.length, 0);                       // non publie tant que non valide
  const rv = (await api('GET', '/api/pro/reviews', null, 'a')).data[0]; await api('PATCH', `/api/pro/reviews/${rv.id}`, { published: true }, 'a');
  assert.equal((await api('GET', '/api/public/org/salon-a')).data.rating.count, 1);
});

test('back-office : roles et permissions, suspension, journal', async () => {
  assert.equal((await api('GET', '/api/admin/overview', null, 'a')).status, 403);                           // un pro n'est pas admin
  await api('POST', '/api/auth/login', { email: 'root@rv.com', password: 'administrateur-long' }, 'root');
  await api('POST', '/api/auth/login', { email: 'help@rv.com', password: 'support-long-pass' }, 'help');
  const ov = await api('GET', '/api/admin/overview', null, 'root'); assert.equal(ov.status, 200); assert.ok(ov.data.orgs >= 2); assert.equal(ov.data.mrr_xof, 10000);
  assert.equal((await api('GET', '/api/admin/invoices', null, 'help')).status, 403);                         // support : pas de finances
  assert.equal((await api('GET', '/api/admin/invoices', null, 'root')).status, 200);
  const orgId = db.prepare("SELECT id FROM orgs WHERE slug='salon-b'").get().id;
  assert.equal((await api('PATCH', `/api/admin/orgs/${orgId}/suspend`, { suspended: true, reason: 'test' }, 'help')).status, 200);
  assert.equal((await api('GET', '/api/public/org/salon-b')).status, 404);                                  // page publique coupee
  assert.equal((await api('PATCH', `/api/admin/orgs/${orgId}/suspend`, { suspended: false }, 'help')).status, 200);
  assert.ok((await api('GET', '/api/admin/logs', null, 'help')).data.some(l => l.action === 'admin.org.suspended'));
});

test('SEO : profil indexable, sitemap, robots, pages metier x ville', async () => {
  const p = await api('GET', '/@salon-a'); assert.equal(p.status, 200);
  assert.match(p.data, /<title>Salon a – Réserver en ligne/); assert.match(p.data, /LocalBusiness/); assert.match(p.data, /og:title/);
  assert.equal((await api('GET', '/@inconnu-xyz')).status, 404);
  assert.match((await api('GET', '/sitemap.xml')).data, /\/@salon-a/);
  assert.match((await api('GET', '/robots.txt')).data, /Disallow: \/api\//);
  const d = await api('GET', '/metier/coiffure/dakar'); assert.equal(d.status, 200); assert.match(d.data, /Coiffure à Dakar/);
});

test('securite : en-tetes, origine croisee, charge utile, traversee de chemin', async () => {
  const h = (await fetch(base + '/')).headers; assert.match(h.get('content-security-policy'), /default-src 'self'/); assert.equal(h.get('x-frame-options'), 'DENY');
  const x = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example' }, body: '{}' }); assert.equal(x.status, 403);
  const big = await fetch(base + '/api/public/book', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ a: 'x'.repeat(200000) }) }); assert.equal(big.status, 413);
  assert.equal((await fetch(base + '/..%2f..%2fetc%2fpasswd')).status, 404);
  assert.equal((await fetch(base + '/api/public/org/x%27%20OR%201=1')).status, 404);
});

test('mot de passe oublie : lien a usage unique, reponse identique pour un compte inconnu', async () => {
  const a = await api('POST', '/api/auth/forgot', { email: 'a@test.sn' }); const b = await api('POST', '/api/auth/forgot', { email: 'inconnu@test.sn' });
  assert.deepEqual(a.data, b.data);
  const row = db.prepare("SELECT body FROM outbox WHERE event='password_reset' AND recipient='a@test.sn'").get(); const token = row.body.match(/token=([a-f0-9]+)/)[1];
  assert.equal((await api('POST', '/api/auth/reset', { token, password: 'court' })).data.error, 'weak_password');
  assert.equal((await api('POST', '/api/auth/reset', { token, password: 'nouveau-mot-de-passe' })).status, 200);
  assert.equal((await api('POST', '/api/auth/reset', { token, password: 'encore-un-autre-1' })).data.error, 'invalid_token');   // usage unique
  assert.equal((await api('POST', '/api/auth/login', { email: 'a@test.sn', password: 'motdepasse-solide' })).status, 401);
  assert.equal((await api('POST', '/api/auth/login', { email: 'a@test.sn', password: 'nouveau-mot-de-passe' }, 'a2')).status, 200);
});

test('webhook de paiement : signature obligatoire, montant verifie', async () => {
  assert.equal((await api('POST', '/api/webhooks/payment', { reference: 'x' })).status, 501);                // non configure
  process.env.PAYMENT_WEBHOOK_SECRET = 'whsec_test';
  const { createHmac } = await import('node:crypto');
  const inv = db.prepare("INSERT INTO invoices(org_id,number,plan,amount,status,issued_ms) VALUES ((SELECT id FROM orgs WHERE slug='salon-a'),'RV-TEST-1','pro',10000,'open',?) RETURNING id").get(Date.now());
  const send = (body, sig) => fetch(base + '/api/webhooks/payment', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Signature': sig ?? createHmac('sha256', 'whsec_test').update(body).digest('hex') }, body });
  assert.equal((await send(JSON.stringify({ reference: 'RV-TEST-1', status: 'paid', amount: 10000 }), 'deadbeef')).status, 401);
  assert.equal((await send(JSON.stringify({ reference: 'RV-TEST-1', status: 'paid', amount: 1 }))).status, 200);   // mauvais montant : ignore
  assert.equal(db.prepare('SELECT status FROM invoices WHERE id=?').get(inv.id).status, 'open');
  assert.equal((await send(JSON.stringify({ reference: 'RV-TEST-1', status: 'paid', amount: 10000, provider: 'wave' }))).status, 200);
  assert.equal(db.prepare('SELECT status FROM invoices WHERE id=?').get(inv.id).status, 'paid'); delete process.env.PAYMENT_WEBHOOK_SECRET;
});

test('PWA : manifeste valide, icones presentes, service worker sans cache long, pages liees', async () => {
  const m = await fetch(base + '/manifest.webmanifest'); assert.equal(m.status, 200); const man = await m.json();
  assert.equal(man.display, 'standalone'); assert.ok(man.icons.some(i => i.sizes === '512x512' && i.purpose === 'maskable')); assert.ok(man.icons.some(i => i.sizes === '192x192'));
  for (const i of man.icons) { const r = await fetch(base + i.src); assert.equal(r.status, 200); assert.equal(r.headers.get('content-type'), 'image/png'); }
  const sw = await fetch(base + '/sw.js'); assert.equal(sw.status, 200); assert.match(sw.headers.get('cache-control'), /no-cache/); assert.equal(sw.headers.get('service-worker-allowed'), '/');
  assert.match(await sw.text(), /startsWith\('\/api\/'\)/);                                              // les donnees ne sont jamais mises en cache
  for (const p of ['/', '/app', '/login', '/@salon-a', '/offline.html']) { const h = await (await fetch(base + p)).text(); if (p !== '/offline.html') assert.match(h, /rel="manifest"/, p); }
});
