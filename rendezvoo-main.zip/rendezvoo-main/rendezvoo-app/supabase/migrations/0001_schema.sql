-- RENDEZVOO — 0001 : schéma multi-tenant
create extension if not exists btree_gist;
create extension if not exists pgcrypto;

-- Types
create type member_role as enum ('owner','admin','staff');
create type booking_status as enum ('pending','confirmed','cancelled','completed','no_show');
create type plan_code as enum ('starter','pro','business');
create type sub_status as enum ('trialing','active','past_due','cancelled');
create type notif_channel as enum ('email','sms','whatsapp');

-- Pays / configuration régionale
create table countries (
  code text primary key,               -- 'SN','CI','BJ','TG'
  name text not null,
  currency text not null,              -- 'XOF','XAF','EUR'
  default_timezone text not null,
  dial_code text not null,
  payment_providers jsonb not null default '[]'
);
insert into countries values
 ('SN','Sénégal','XOF','Africa/Dakar','+221','["wave","orange_money"]'),
 ('CI','Côte d''Ivoire','XOF','Africa/Abidjan','+225','["wave","orange_money","mtn_momo"]'),
 ('BJ','Bénin','XOF','Africa/Porto-Novo','+229','["mtn_momo","moov_money"]'),
 ('TG','Togo','XOF','Africa/Lome','+228','["tmoney","moov_money"]');

-- Profils (liés à auth.users)
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  locale text not null default 'fr',
  is_platform_admin boolean not null default false,
  created_at timestamptz not null default now()
);

-- Organisations = tenants
create table organizations (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null check (slug ~ '^[a-z0-9-]{3,40}$'),
  name text not null,
  category text,
  city text,
  country_code text not null references countries(code) default 'SN',
  timezone text not null default 'Africa/Dakar',
  currency text not null default 'XOF',
  bio text, logo_url text, cover_url text, address text,
  cancel_window_hours int not null default 24,
  is_suspended boolean not null default false,
  created_at timestamptz not null default now()
);

create table memberships (
  org_id uuid not null references organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role member_role not null default 'staff',
  primary key (org_id, user_id)
);

-- Employés / ressources réservables
create table staff (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  user_id uuid references auth.users(id),
  display_name text not null,
  active boolean not null default true
);

create table services (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  description text,
  duration_min int not null check (duration_min between 5 and 720),
  buffer_min int not null default 0 check (buffer_min >= 0),
  price_amount int not null check (price_amount >= 0),   -- unité mineure = unité (XOF sans décimales)
  active boolean not null default true
);

create table staff_services (
  staff_id uuid references staff(id) on delete cascade,
  service_id uuid references services(id) on delete cascade,
  primary key (staff_id, service_id)
);

-- Horaires hebdomadaires (heure locale de l'organisation)
create table working_hours (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  staff_id uuid not null references staff(id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6), -- 0 = dimanche
  start_time time not null,
  end_time time not null,
  check (end_time > start_time)
);

-- Indisponibilités ponctuelles
create table time_off (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  staff_id uuid not null references staff(id) on delete cascade,
  period tstzrange not null,
  reason text
);

create table customers (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  full_name text not null,
  phone text,
  email text,
  created_at timestamptz not null default now()
);
create index on customers(org_id, phone);

create table bookings (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  staff_id uuid not null references staff(id),
  service_id uuid not null references services(id),
  customer_id uuid not null references customers(id),
  period tstzrange not null,             -- inclut le temps de préparation
  status booking_status not null default 'confirmed',
  manage_token text not null default encode(gen_random_bytes(16),'hex'),
  notes text,
  created_at timestamptz not null default now(),
  -- Anti double-réservation garanti par la base, même en concurrence
  constraint no_overlap exclude using gist
    (staff_id with =, period with &&) where (status in ('pending','confirmed'))
);
create index on bookings(org_id, lower(period));

create table plans (
  code plan_code primary key,
  price_xof int not null,
  features jsonb not null default '{}'
);
insert into plans values
 ('starter',5000,'{"staff_max":1,"stats":false}'),
 ('pro',10000,'{"staff_max":10,"stats":true,"advanced_notifications":true}'),
 ('business',20000,'{"staff_max":null,"multi_location":true,"reports":true}');

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null unique references organizations(id) on delete cascade,
  plan plan_code not null default 'starter',
  status sub_status not null default 'trialing',
  trial_ends_at timestamptz not null default now() + interval '14 days',
  current_period_end timestamptz
);

create table payments (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  booking_id uuid references bookings(id),
  subscription_id uuid references subscriptions(id),
  amount int not null, currency text not null,
  provider text, provider_ref text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table notification_settings (
  org_id uuid not null references organizations(id) on delete cascade,
  event text not null,                    -- 'booking_confirmed','reminder','cancelled'...
  channel notif_channel not null,
  enabled boolean not null default true,
  lead_hours int,
  primary key (org_id, event, channel)
);

create table notifications_outbox (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  booking_id uuid references bookings(id) on delete cascade,
  channel notif_channel not null,
  event text not null,
  send_at timestamptz not null default now(),
  sent_at timestamptz,
  error text
);

create table reviews (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  booking_id uuid unique references bookings(id),
  rating smallint not null check (rating between 1 and 5),
  comment text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table activity_logs (
  id bigserial primary key,
  org_id uuid references organizations(id) on delete cascade,
  actor uuid,
  action text not null,
  detail jsonb,
  created_at timestamptz not null default now()
);
