-- RENDEZVOO — 0002 : RLS, helpers, moteur de disponibilités et de réservation

-- Helpers (security definer pour éviter la récursion RLS)
create or replace function is_member(p_org uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where org_id = p_org and user_id = auth.uid());
$$;

create or replace function is_org_admin(p_org uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
    where org_id = p_org and user_id = auth.uid() and role in ('owner','admin'));
$$;

create or replace function is_platform_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_platform_admin from profiles where id = auth.uid()), false);
$$;

-- Activer RLS partout
do $$
declare t text;
begin
  for t in select unnest(array['profiles','organizations','memberships','staff','services',
    'staff_services','working_hours','time_off','customers','bookings','subscriptions',
    'payments','notification_settings','notifications_outbox','reviews','activity_logs'])
  loop execute format('alter table %I enable row level security', t); end loop;
end $$;

alter table countries enable row level security;
alter table plans enable row level security;
create policy countries_read on countries for select using (true);
create policy plans_read on plans for select using (true);

-- profiles
create policy profiles_self on profiles for select using (id = auth.uid() or is_platform_admin());
create policy profiles_self_update on profiles for update using (id = auth.uid())
  with check (id = auth.uid() and is_platform_admin = (select is_platform_admin from profiles where id = auth.uid()));

-- organizations : lecture publique des organisations actives (profil public), écriture membres admin
create policy org_public_read on organizations for select
  using (not is_suspended or is_member(id) or is_platform_admin());
create policy org_admin_update on organizations for update
  using (is_org_admin(id)) with check (is_org_admin(id));
create policy org_insert on organizations for insert to authenticated with check (true);

create policy mem_read on memberships for select using (user_id = auth.uid() or is_org_admin(org_id) or is_platform_admin());
create policy mem_admin_write on memberships for all using (is_org_admin(org_id)) with check (is_org_admin(org_id));

-- Tables du catalogue : lecture publique (page de réservation), écriture membres
create policy staff_read on staff for select using (active or is_member(org_id));
create policy staff_write on staff for all using (is_org_admin(org_id)) with check (is_org_admin(org_id));
create policy services_read on services for select using (active or is_member(org_id));
create policy services_write on services for all using (is_org_admin(org_id)) with check (is_org_admin(org_id));
create policy ss_read on staff_services for select using (true);
create policy ss_write on staff_services for all
  using (exists (select 1 from staff s where s.id = staff_id and is_org_admin(s.org_id)))
  with check (exists (select 1 from staff s where s.id = staff_id and is_org_admin(s.org_id)));
create policy wh_read on working_hours for select using (true);
create policy wh_write on working_hours for all using (is_org_admin(org_id)) with check (is_org_admin(org_id));

-- Données privées : membres uniquement
create policy to_member on time_off for all using (is_member(org_id)) with check (is_member(org_id));
create policy cust_member on customers for all using (is_member(org_id)) with check (is_member(org_id));
create policy book_member on bookings for all using (is_member(org_id)) with check (is_member(org_id));
create policy sub_read on subscriptions for select using (is_member(org_id) or is_platform_admin());
create policy sub_admin on subscriptions for all using (is_platform_admin()) with check (is_platform_admin());
create policy pay_read on payments for select using (is_org_admin(org_id) or is_platform_admin());
create policy ns_admin on notification_settings for all using (is_org_admin(org_id)) with check (is_org_admin(org_id));
create policy outbox_read on notifications_outbox for select using (is_member(org_id));
create policy rev_public on reviews for select using (published or is_member(org_id));
create policy rev_member on reviews for update using (is_org_admin(org_id));
create policy log_read on activity_logs for select using (is_org_admin(org_id) or is_platform_admin());

-- Création d'organisation : le créateur devient owner + abonnement d'essai
create or replace function create_organization(p_slug text, p_name text, p_country text default 'SN')
returns uuid language plpgsql security definer set search_path = public as $$
declare v_org uuid; v_tz text; v_cur text;
begin
  if auth.uid() is null then raise exception 'auth required'; end if;
  select default_timezone, currency into v_tz, v_cur from countries where code = p_country;
  insert into organizations(slug,name,country_code,timezone,currency)
    values (p_slug,p_name,p_country,v_tz,v_cur) returning id into v_org;
  insert into memberships(org_id,user_id,role) values (v_org,auth.uid(),'owner');
  insert into subscriptions(org_id) values (v_org);
  insert into activity_logs(org_id,actor,action) values (v_org,auth.uid(),'org.created');
  return v_org;
end $$;

-- Disponibilités calculées côté serveur (pas de 15 min), accessibles au public
create or replace function get_available_slots(
  p_org uuid, p_service uuid, p_day date, p_staff uuid default null
) returns table(staff_id uuid, slot_start timestamptz, slot_end timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare v_dur int; v_buf int; v_tz text; v_step interval := interval '15 minutes';
begin
  select duration_min, buffer_min into v_dur, v_buf from services
    where id = p_service and org_id = p_org and active;
  if not found then return; end if;
  select timezone into v_tz from organizations where id = p_org and not is_suspended;
  if not found then return; end if;

  return query
  with hours as (
    select wh.staff_id,
           (p_day + wh.start_time) at time zone v_tz as ws,
           (p_day + wh.end_time)   at time zone v_tz as we
    from working_hours wh
    join staff s on s.id = wh.staff_id and s.active
    join staff_services ss on ss.staff_id = s.id and ss.service_id = p_service
    where wh.org_id = p_org and wh.weekday = extract(dow from p_day)
      and (p_staff is null or wh.staff_id = p_staff)
  ),
  cand as (
    select h.staff_id, g as st, g + make_interval(mins => v_dur) as en,
           tstzrange(g, g + make_interval(mins => v_dur + v_buf)) as occ
    from hours h, generate_series(h.ws, h.we - make_interval(mins => v_dur), v_step) g
  )
  select c.staff_id, c.st, c.en from cand c
  where c.st > now()
    and not exists (select 1 from bookings b where b.staff_id = c.staff_id
        and b.status in ('pending','confirmed') and b.period && c.occ)
    and not exists (select 1 from time_off t where t.staff_id = c.staff_id and t.period && c.occ)
  order by c.st, c.staff_id;
end $$;

-- Réservation publique sans compte : la contrainte d'exclusion tranche les conflits
create or replace function create_public_booking(
  p_org uuid, p_service uuid, p_staff uuid, p_start timestamptz,
  p_name text, p_phone text, p_email text default null
) returns table(booking_id uuid, manage_token text)
language plpgsql security definer set search_path = public as $$
declare v_dur int; v_buf int; v_cust uuid; v_b bookings;
begin
  if length(trim(coalesce(p_name,''))) < 2 or length(coalesce(p_phone,'')) < 6 then
    raise exception 'invalid_customer';
  end if;
  select duration_min, buffer_min into v_dur, v_buf from services
    where id = p_service and org_id = p_org and active;
  if not found then raise exception 'service_not_found'; end if;

  -- le créneau doit appartenir aux disponibilités calculées
  if not exists (select 1 from get_available_slots(p_org, p_service,
        (p_start at time zone (select timezone from organizations where id = p_org))::date, p_staff) s
      where s.staff_id = p_staff and s.slot_start = p_start) then
    raise exception 'slot_unavailable';
  end if;

  select id into v_cust from customers where org_id = p_org and phone = p_phone limit 1;
  if v_cust is null then
    insert into customers(org_id,full_name,phone,email) values (p_org,p_name,p_phone,p_email)
      returning id into v_cust;
  end if;

  begin
    insert into bookings(org_id,staff_id,service_id,customer_id,period)
      values (p_org,p_staff,p_service,v_cust,
              tstzrange(p_start, p_start + make_interval(mins => v_dur + v_buf)))
      returning * into v_b;
  exception when exclusion_violation then
    raise exception 'slot_unavailable';
  end;

  insert into notifications_outbox(org_id,booking_id,channel,event)
    values (p_org, v_b.id, 'email', 'booking_confirmed');
  return query select v_b.id, v_b.manage_token;
end $$;

-- Annulation par le client via son jeton, selon la règle du professionnel
create or replace function cancel_booking_by_token(p_token text) returns void
language plpgsql security definer set search_path = public as $$
declare v_b bookings; v_hours int;
begin
  select * into v_b from bookings where manage_token = p_token and status in ('pending','confirmed');
  if not found then raise exception 'not_found'; end if;
  select cancel_window_hours into v_hours from organizations where id = v_b.org_id;
  if lower(v_b.period) - now() < make_interval(hours => v_hours) then
    raise exception 'too_late_to_cancel';
  end if;
  update bookings set status = 'cancelled' where id = v_b.id;
  insert into notifications_outbox(org_id,booking_id,channel,event) values (v_b.org_id,v_b.id,'email','booking_cancelled');
end $$;

revoke all on function create_organization(text,text,text) from public, anon;
grant execute on function create_organization(text,text,text) to authenticated;
grant execute on function get_available_slots(uuid,uuid,date,uuid) to anon, authenticated;
grant execute on function create_public_booking(uuid,uuid,uuid,timestamptz,text,text,text) to anon, authenticated;
grant execute on function cancel_booking_by_token(text) to anon, authenticated;
