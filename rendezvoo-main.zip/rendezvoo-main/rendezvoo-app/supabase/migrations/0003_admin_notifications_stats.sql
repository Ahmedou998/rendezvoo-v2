-- RENDEZVOO — 0003 : administration, rôles, notifications, statistiques, limites de plan

-- Rôles plateforme
alter table profiles add column if not exists platform_role text
  check (platform_role in ('super_admin','support','finance'));
update profiles set platform_role = 'super_admin' where is_platform_admin;

create or replace function is_platform_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select platform_role is not null from profiles where id = auth.uid()), false);
$$;

create or replace function platform_has(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select case platform_role
      when 'super_admin' then true
      when 'support' then p in ('orgs','claims','content')
      when 'finance' then p in ('payments','subscriptions','offers')
      else false end
    from profiles where id = auth.uid()), false);
$$;

drop policy if exists profiles_self_update on profiles;
create policy profiles_self_update on profiles for update
  using (id = auth.uid())
  with check (id = auth.uid()
    and platform_role is not distinct from (select platform_role from profiles where id = auth.uid())
    and is_platform_admin = (select is_platform_admin from profiles where id = auth.uid()));

-- Paramètres plateforme (mode de paiement)
create table app_settings (key text primary key, value text not null);
insert into app_settings values ('payment_mode','test');
alter table app_settings enable row level security;
create policy settings_super on app_settings for all
  using (platform_has('settings')) with check (platform_has('settings'));

-- Tables back-office
create table categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null, label_fr text not null, label_en text not null,
  active boolean not null default true
);
insert into categories(slug,label_fr,label_en) values
 ('coiffure','Coiffure','Hair salon'),('barbier','Barbier','Barber'),
 ('beaute','Institut de beauté','Beauty salon'),('spa','Spa & bien-être','Spa & wellness'),
 ('photographe','Photographe','Photographer'),('coach','Coach sportif','Fitness coach'),
 ('consultant','Consultant','Consultant'),('formation','Centre de formation','Training center');
alter table categories enable row level security;
create policy cat_read on categories for select using (active or is_platform_admin());
create policy cat_write on categories for all using (platform_has('content')) with check (platform_has('content'));

create table offers (
  id uuid primary key default gen_random_uuid(),
  code text unique not null, label text not null,
  discount_percent int not null check (discount_percent between 1 and 100),
  active boolean not null default true, created_at timestamptz not null default now()
);
alter table offers enable row level security;
create policy offers_admin on offers for all using (platform_has('offers')) with check (platform_has('offers'));

create table claims (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id) on delete set null,
  author_name text not null, author_contact text, message text not null,
  status text not null default 'open' check (status in ('open','in_progress','resolved')),
  created_at timestamptz not null default now()
);
alter table claims enable row level security;
create policy claims_admin on claims for all using (platform_has('claims')) with check (platform_has('claims'));
create policy claims_member_insert on claims for insert to authenticated with check (org_id is null or is_member(org_id));

create table content_blocks (key text primary key, body jsonb not null default '{}');
alter table content_blocks enable row level security;
create policy content_read on content_blocks for select using (true);
create policy content_write on content_blocks for all using (platform_has('content')) with check (platform_has('content'));

-- Accès plateforme aux données (selon le rôle)
create policy org_platform on organizations for all using (platform_has('orgs')) with check (platform_has('orgs'));
create policy bookings_platform_read on bookings for select using (is_platform_admin());
create policy customers_platform_read on customers for select using (platform_has('orgs'));
create policy pay_platform on payments for all using (platform_has('payments')) with check (platform_has('payments'));
drop policy if exists sub_admin on subscriptions;
create policy sub_platform on subscriptions for all using (platform_has('subscriptions')) with check (platform_has('subscriptions'));
create policy mem_platform_read on memberships for select using (is_platform_admin());

-- Essai sur la formule Pro
alter table subscriptions alter column plan set default 'pro';

-- Limite d'employés selon la formule
create or replace function enforce_staff_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_max int;
begin
  select (p.features->>'staff_max')::int into v_max
    from subscriptions s join plans p on p.code = s.plan where s.org_id = new.org_id;
  if v_max is not null and (select count(*) from staff where org_id = new.org_id and active) >= v_max then
    raise exception 'plan_limit_staff';
  end if;
  return new;
end $$;
create trigger staff_limit before insert on staff for each row execute function enforce_staff_limit();

-- Journal d'activité automatique
create or replace function log_change() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_org uuid; v_row jsonb := to_jsonb(new);
begin
  v_org := coalesce((v_row->>'org_id')::uuid,
                    case when tg_table_name = 'organizations' then (v_row->>'id')::uuid end);
  insert into activity_logs(org_id, actor, action, detail)
    values (v_org, auth.uid(), tg_table_name || '.' || lower(tg_op), jsonb_build_object('id', v_row->>'id'));
  return new;
end $$;
create trigger log_bookings after insert or update on bookings for each row execute function log_change();
create trigger log_services after insert or update on services for each row execute function log_change();
create trigger log_orgs after update on organizations for each row execute function log_change();
create trigger log_subs after insert or update on subscriptions for each row execute function log_change();
create trigger log_payments after insert on payments for each row execute function log_change();

-- Notifications : file d'envoi alimentée à chaque réservation
create or replace function enqueue_booking_notifications() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into notifications_outbox(org_id, booking_id, channel, event, send_at)
    values (new.org_id, new.id, 'email', 'pro_new_booking', now());
  if lower(new.period) - interval '24 hours' > now() then
    insert into notifications_outbox(org_id, booking_id, channel, event, send_at)
      values (new.org_id, new.id, 'email', 'reminder', lower(new.period) - interval '24 hours');
  end if;
  return new;
end $$;
create trigger bookings_notify after insert on bookings for each row execute function enqueue_booking_notifications();

create or replace function enqueue_booking_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.period is distinct from new.period and new.status in ('pending','confirmed') then
    insert into notifications_outbox(org_id, booking_id, channel, event) values (new.org_id, new.id, 'email', 'booking_modified');
  end if;
  return new;
end $$;
create trigger bookings_notify_update after update on bookings for each row execute function enqueue_booking_update();

create unique index if not exists outbox_unique_event on notifications_outbox(booking_id, channel, event)
  where sent_at is null;

-- Lecture publique d'une réservation par jeton
create or replace function get_booking_by_token(p_token text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('id', b.id, 'status', b.status, 'start', lower(b.period),
    'service', s.name, 'duration', s.duration_min, 'price', s.price_amount, 'currency', o.currency,
    'org_name', o.name, 'org_slug', o.slug, 'timezone', o.timezone, 'address', o.address,
    'staff', st.display_name, 'cancel_window_hours', o.cancel_window_hours)
  from bookings b join services s on s.id = b.service_id
  join organizations o on o.id = b.org_id join staff st on st.id = b.staff_id
  where b.manage_token = p_token;
$$;
grant execute on function get_booking_by_token(text) to anon, authenticated;

-- Statistiques (security invoker : la RLS s'applique)
create or replace function org_stats(p_org uuid, p_from timestamptz, p_to timestamptz) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'bookings', count(*) filter (where b.status <> 'cancelled'),
    'cancelled', count(*) filter (where b.status = 'cancelled'),
    'revenue', coalesce(sum(s.price_amount) filter (where b.status in ('confirmed','completed')), 0),
    'cancel_rate', case when count(*) = 0 then 0
        else round(100.0 * count(*) filter (where b.status = 'cancelled') / count(*), 1) end,
    'upcoming', count(*) filter (where b.status in ('pending','confirmed') and lower(b.period) > now()))
  from bookings b join services s on s.id = b.service_id
  where b.org_id = p_org and lower(b.period) >= p_from and lower(b.period) < p_to;
$$;

create or replace function org_stats_daily(p_org uuid, p_from date, p_to date)
returns table(day date, bookings int, revenue int)
language sql stable set search_path = public as $$
  select d::date, count(b.id)::int, coalesce(sum(s.price_amount), 0)::int
  from generate_series(p_from, p_to, interval '1 day') d
  join organizations o on o.id = p_org
  left join bookings b on b.org_id = p_org and b.status in ('confirmed','completed')
       and (lower(b.period) at time zone o.timezone)::date = d::date
  left join services s on s.id = b.service_id
  group by d order by d;
$$;

create or replace function admin_stats() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_platform_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'organizations', (select count(*) from organizations),
    'suspended', (select count(*) from organizations where is_suspended),
    'bookings', (select count(*) from bookings),
    'customers', (select count(*) from customers),
    'active_subscriptions', (select count(*) from subscriptions where status = 'active'),
    'trialing', (select count(*) from subscriptions where status = 'trialing'),
    'mrr', (select coalesce(sum(p.price_xof), 0) from subscriptions s join plans p on p.code = s.plan where s.status = 'active'));
end $$;
grant execute on function admin_stats() to authenticated;

-- Changement de formule : mode test uniquement tant qu'aucun prestataire n'est branché
create or replace function change_plan(p_org uuid, p_plan plan_code) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_org_admin(p_org) then raise exception 'forbidden'; end if;
  if (select value from app_settings where key = 'payment_mode') <> 'test' then
    raise exception 'payment_required';
  end if;
  update subscriptions set plan = p_plan, status = 'active',
    current_period_end = now() + interval '30 days' where org_id = p_org;
  insert into payments(org_id, subscription_id, amount, currency, provider, status)
    select p_org, s.id, pl.price_xof, 'XOF', 'test', 'paid'
    from subscriptions s join plans pl on pl.code = p_plan where s.org_id = p_org;
end $$;
grant execute on function change_plan(uuid, plan_code) to authenticated;

-- Activation par le webhook du prestataire (clé service uniquement)
create or replace function activate_subscription(p_org uuid, p_plan plan_code, p_provider text, p_ref text, p_amount int)
returns void language plpgsql security definer set search_path = public as $$
begin
  update subscriptions set plan = p_plan, status = 'active',
    current_period_end = greatest(coalesce(current_period_end, now()), now()) + interval '30 days'
    where org_id = p_org;
  insert into payments(org_id, subscription_id, amount, currency, provider, provider_ref, status)
    select p_org, id, p_amount, 'XOF', p_provider, p_ref, 'paid' from subscriptions where org_id = p_org;
end $$;
revoke all on function activate_subscription(uuid, plan_code, text, text, int) from public, anon, authenticated;
grant execute on function activate_subscription(uuid, plan_code, text, text, int) to service_role;
