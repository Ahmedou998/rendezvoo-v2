# RENDEZVOO

Plateforme de réservation et de gestion de clientèle pour professionnels (salons, barbiers, spas, coachs, consultants…), pensée pour le Sénégal puis l'Afrique francophone.

**Une seule dépendance : Node.js 22.5 ou plus.** Aucun `npm install`, aucun service externe pour démarrer.

## Démarrer en 2 minutes

```bash
ADMIN_EMAIL=vous@exemple.com ADMIN_PASSWORD='un-mot-de-passe-long-12+' SEED_DEMO=1 npm run seed
npm start                      # http://localhost:3000
npm test                       # 19 tests (réservation, concurrence, isolation, sécurité, SEO, paiement, PWA…)
```

| Adresse | Rôle |
|---|---|
| `/` | Site public (animations, démonstration, tarifs) |
| `/@maison-teranga` | Page de réservation d'un professionnel (données de démo) |
| `/inscription` | Création d'un espace professionnel (essai gratuit) |
| `/app` | Espace professionnel : 11 sections |
| `/admin` | Back-office RENDEZVOO (rôles superadmin, support, finance) |
| `/r/<jeton>` | Le client gère, déplace ou annule son rendez-vous |

Compte professionnel de démonstration (uniquement avec `SEED_DEMO=1`) : `demo@rendezvoo.com` / `demo-rendezvoo-2026`.

## Ce qui est réellement opérationnel

- **Réservation sans compte**, disponibilités calculées **côté serveur** (horaires, durée, temps de préparation, congés, fuseau de l'organisation).
- **Zéro doublon**, garanti à trois niveaux : transaction `BEGIN IMMEDIATE`, revérification du créneau dans la transaction, et déclencheur SQL qui refuse tout chevauchement. Testé avec 12 réservations simultanées : 1 réussit, 11 refusées.
- **Multi-tenant** : chaque requête est filtrée par l'organisation de la session ; testé (un professionnel ne lit ni ne modifie les données d'un autre).
- **Formules** Starter / Pro / Business appliquées côté serveur (nombre d'employés, statistiques, personnalisation, rapports CSV, multi-utilisateurs, plusieurs établissements), essai gratuit configurable, factures, changement de formule.
- **Back-office** : professionnels, utilisateurs et rôles, abonnements, factures, réclamations, offres, catégories, contenus, journal d'activité. Les permissions sont vérifiées par le serveur.
- **SEO** : pages `/@slug` rendues côté serveur (métadonnées, Open Graph, données structurées LocalBusiness), pages `/metier/<métier>/<ville>`, `sitemap.xml`, `robots.txt`.
- **Sécurité** : mots de passe scrypt, sessions signées HttpOnly/SameSite, contrôle d'origine, CSP stricte sans script en ligne, limitation de débit, taille de corps limitée, aucune injection HTML côté interface, export CSV protégé contre l'injection de formules.
- **Accessibilité et mouvement** : `prefers-reduced-motion` respecté, mode allégé sur appareils peu puissants ou avec économie de données, focus visible, navigation clavier.

## Application installable (PWA)

RENDEZVOO s'installe comme une application, sur téléphone et ordinateur : icône, plein écran, raccourcis (Calendrier, Réservations, Clients).

- **Android, Chrome, Edge** : bouton « Installer l'application » en haut du tableau de bord (ou menu du navigateur).
- **iPhone, iPad** : Safari, bouton Partager, puis « Sur l'écran d'accueil » (le tableau de bord l'explique).
- **Hors ligne** : l'interface s'ouvre sans réseau ; les données (rendez-vous, clients) ne sont jamais mises en cache, donc rien de périmé ni de confidentiel n'est stocké sur l'appareil. Sans réseau, un écran propose de réessayer.
- **Exigence** : l'installation n'est proposée que sur **HTTPS** (ou `localhost`). Derrière votre reverse proxy HTTPS, tout fonctionne sans réglage.
- **Mises à jour** : incrémentez `VERSION` dans `public/sw.js` à chaque livraison pour renouveler le cache des appareils.

## Ce qui dépend de VOS identifiants (et n'est pas simulé)

| Fonction | Sans identifiants | Avec identifiants |
|---|---|---|
| E-mails, WhatsApp, SMS | Messages préparés et **conservés en statut « test »** ; rien n'est envoyé | `RESEND_API_KEY`, `WHATSAPP_API_URL/TOKEN`, `SMS_API_URL/TOKEN` |
| Paiement des abonnements | **Mode test** annoncé par un bandeau : la facture est validée sans débit | `PAYMENT_MODE=live`, `PAYMENT_PROVIDER_URL`, webhook signé `/api/webhooks/payment` |
| Réinitialisation du mot de passe | Le lien est écrit dans les journaux du serveur (`[DEV]`) | `RESEND_API_KEY` |

Le contrat attendu des prestataires de paiement et de messagerie est décrit dans `.env.example`. Vos prestataires WhatsApp Business et mobile money (Wave, Orange Money…) ont chacun leur API : l'adaptateur se limite à `server/notify.js` (`send`) et à `routes-pro.js` (`/invoices/:id/pay`).

## Choix techniques, à lire

- **Pile : Node 22 + SQLite embarqué (`node:sqlite`) + HTML/CSS/JS modules.** Le cahier des charges proposait Next.js, Tailwind, GSAP et Supabase. L'environnement de construction n'avait pas accès au registre npm : ces bibliothèques n'ont donc pas pu être installées ni testées. Plutôt que de livrer du code jamais compilé, tout a été écrit sans dépendance et testé pour de vrai. Les animations (révélations par masque, parallaxe, boutons magnétiques, inclinaison 3D, transitions de page, scène du hero pilotée par `Web Animations`) sont faites maison dans `public/js/motion.js`.
- **Défilement fluide type Lenis : volontairement absent**, car détourner le défilement nuit à l'accessibilité. Three.js : non utilisé, aucune scène 3D n'apportait de valeur.
- **Supabase** : le schéma PostgreSQL équivalent, avec politiques RLS et moteur de réservation (contrainte d'exclusion `gist`), est dans `supabase/migrations`. Il a été testé sur PostgreSQL 16, mais **l'application ne s'y connecte pas aujourd'hui**. Migrer vers Supabase + Next.js demande de réécrire la couche `server/` ; les règles métier et les tests (`test/api.test.js`) servent de spécification.
- **SQLite** convient à un serveur unique (des milliers de réservations par jour). Au-delà, ou pour plusieurs serveurs, passez à PostgreSQL.
- **Polices** : Bricolage Grotesque et Newsreader sont chargées depuis Google Fonts ; sans accès, des polices système prennent le relais. Pour tout héberger vous-même, déposez les fichiers `woff2` dans `public/fonts` et remplacez l'`@import` de `public/css/base.css`.
- **Images** : aucune photo de stock n'est incluse. Le design repose sur la typographie et des motifs vectoriels ; ajoutez vos propres visuels.
- **Langues** : site public, réservation, gestion du rendez-vous et connexion sont en français et en anglais. Le tableau de bord et le back-office sont en français uniquement.
- **Pays** : Sénégal, Côte d'Ivoire, Bénin, Togo, Cameroun et France sont configurés (devise, fuseau, indicatif, moyens de paiement prévus). Ajouter un pays = une ligne dans la table `countries`.

## Déployer

```bash
docker build -t rendezvoo .
docker run -d --name rendezvoo -p 3000:3000 -v rendezvoo-data:/data --env-file .env rendezvoo
docker exec rendezvoo node --disable-warning=ExperimentalWarning server/seed.js   # crée le super-admin (ADMIN_EMAIL / ADMIN_PASSWORD)
```

### Installation en une commande (serveur Ubuntu/Debian neuf)

```bash
sudo bash deploy/install-vps.sh votre-domaine.com vous@exemple.com
```

Installe Docker, génère les secrets, démarre le site en HTTPS, crée le super-admin et planifie les sauvegardes. Test local sans rien installer : `bash LANCER-EN-LOCAL.sh`.

### Trois chemins prêts à l'emploi

| Option | Fichier | Commande |
|---|---|---|
| **VPS** (Hetzner, OVH, Scaleway) avec HTTPS automatique et sauvegarde quotidienne | `deploy/docker-compose.yml` + `deploy/Caddyfile` | `cp .env.example .env` puis `DOMAIN=rendezvoo.com docker compose -f deploy/docker-compose.yml up -d --build` |
| **Render** (disque persistant requis, offre payante) | `render.yaml` | « New > Blueprint » sur votre dépôt, puis renseigner `BASE_URL`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` |
| **Fly.io** | `fly.toml` | `fly launch --copy-config --no-deploy`, `fly volumes create data --size 1 --region cdg`, `fly secrets set SESSION_SECRET=$(openssl rand -hex 32) BASE_URL=https://VOTRE-APP.fly.dev`, `fly deploy` |

Après le premier démarrage, créez le super-admin : `node --disable-warning=ExperimentalWarning server/seed.js` (dans le conteneur) avec `ADMIN_EMAIL` et `ADMIN_PASSWORD` (12 caractères minimum).
SQLite exige un disque persistant et **une seule instance** : n'utilisez pas de plateforme sans volume.
Validé ici : démarrage en production dans un dossier propre (`/healthz`, accueil, sitemap). Le `docker build` n'a pas pu être exécuté dans mon environnement (pas de démon Docker) : lancez-le une fois chez vous.

1. Placez un reverse proxy HTTPS devant (Caddy : `rendezvoo.com { reverse_proxy localhost:3000 }`), puis `TRUST_PROXY=1`.
2. Renseignez `BASE_URL`, `SESSION_SECRET` (`openssl rand -hex 32`) et vos prestataires dans `.env`.
3. **Sauvegardes** : `node scripts/backup.js` (à chaud), à planifier chaque nuit via cron ; les 14 dernières sont conservées. Copiez-les hors du serveur.
4. **Supervision** : `GET /healthz` pour votre outil de surveillance ; `ERROR_WEBHOOK_URL` reçoit chaque erreur 500.
5. Les rappels et envois sont traités toutes les 30 secondes par le processus serveur ; ne lancez qu'une instance.

## Structure

```
server/   db.js (schéma) · booking.js (moteur) · routes-*.js (API) · notify.js · seo.js · app.js
public/   index.html (site) · book.html · manage.html · app.html · admin.html · css/ · js/
test/     api.test.js
supabase/ migrations PostgreSQL + RLS (cible de migration, non branchée)
```
