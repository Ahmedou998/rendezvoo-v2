#!/usr/bin/env bash
# Installation clé en main sur un serveur Ubuntu/Debian neuf (root ou sudo).
# Usage : sudo bash deploy/install-vps.sh votre-domaine.com vous@exemple.com
# Prérequis : le DNS du domaine (enregistrement A) pointe déjà vers ce serveur.
set -euo pipefail
DOMAIN="${1:?Usage: install-vps.sh DOMAINE EMAIL_ADMIN}"
ADMIN_EMAIL="${2:?Usage: install-vps.sh DOMAINE EMAIL_ADMIN}"
cd "$(dirname "$0")/.."

if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sh
fi

if [ ! -f .env ]; then
  ADMIN_PASSWORD="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-16)Aa1"
  cat > .env <<ENV
BASE_URL=https://$DOMAIN
SESSION_SECRET=$(openssl rand -hex 32)
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_PASSWORD=$ADMIN_PASSWORD
PAYMENT_MODE=test
ENV
  chmod 600 .env
  echo "$ADMIN_PASSWORD" > .admin-password.txt && chmod 600 .admin-password.txt
fi

export DOMAIN
docker compose -f deploy/docker-compose.yml up -d --build
sleep 5
docker compose -f deploy/docker-compose.yml exec -T app node --disable-warning=ExperimentalWarning server/seed.js

echo
echo "RENDEZVOO est en ligne : https://$DOMAIN"
echo "Admin : https://$DOMAIN/admin   identifiant : $ADMIN_EMAIL"
echo "Mot de passe : voir .admin-password.txt (changez-le puis supprimez ce fichier)"
echo "Sauvegardes quotidiennes : deploy/backups/"
