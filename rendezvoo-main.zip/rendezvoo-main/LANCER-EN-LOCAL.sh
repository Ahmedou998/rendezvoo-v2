#!/usr/bin/env bash
# Double-cliquez ou lancez : bash LANCER-EN-LOCAL.sh   (Node 22+ requis)
cd "$(dirname "$0")"
[ -f .env ] || cp .env.example .env
SEED_DEMO=1 ADMIN_EMAIL=admin@local.test ADMIN_PASSWORD='admin-local-2026-ok' node --disable-warning=ExperimentalWarning server/seed.js
echo "Ouvrez http://localhost:3000  |  demo@rendezvoo.com / demo-rendezvoo-2026"
exec node --disable-warning=ExperimentalWarning server/index.js
