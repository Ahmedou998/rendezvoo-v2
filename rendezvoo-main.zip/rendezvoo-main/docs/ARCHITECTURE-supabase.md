# RENDEZVOO — Architecture & état d'avancement

## État réel (honnête)

| Étape | Statut |
|---|---|
| 2. Architecture | Fait (ce document) |
| 8-9. Base de données + sécurité | Fait et testé : schéma multi-tenant, RLS, moteur de réservation |
| 3-7. Design system, site public, parcours client, dashboard, back-office | **À faire** (aucune ligne de front n'existe encore) |
| Notifications, paiements, SEO | Tables prêtes (`notifications_outbox`, `payments`), connecteurs à écrire |

## Décisions d'architecture

- **Multi-tenant par `org_id`** sur chaque table, isolation par RLS (fonctions `is_member`, `is_org_admin`, `is_platform_admin` en `security definer`).
- **Anti double-réservation garanti par PostgreSQL** : contrainte `EXCLUDE USING gist (staff_id =, period &&)`. Testé : 8 réservations simultanées du même créneau → 1 succès, 7 refus.
- **Disponibilités calculées côté serveur** : `get_available_slots()` (horaires, durée, temps de préparation, congés, réservations existantes, fuseau de l'organisation).
- **Réservation sans compte** : `create_public_booking()` revalide le créneau côté serveur ; le client reçoit un `manage_token` pour annuler (`cancel_booking_by_token()`, respecte `cancel_window_hours`).
- **Multi-pays** : table `countries` (devise, fuseau, indicatif, moyens de paiement), organisation avec `country_code`, `currency`, `timezone`. Langues FR/EN via `profiles.locale`.
- **Abonnements** : tables `plans` (5 000 / 10 000 / 20 000 FCFA) et `subscriptions` (essai 14 jours configurable).
- Les clés secrètes (service role, WhatsApp, paiements) restent côté serveur (Route Handlers / Edge Functions), jamais dans le navigateur.

## Points à connaître

- Les montants sont en unité entière (XOF/XAF sans décimales) ; pour l'EUR il faudra passer en centimes.
- Le rappel avant rendez-vous demande une tâche planifiée (pg_cron ou Supabase Edge Function) qui lit `notifications_outbox`.
- Le dépôt `tests/00_supabase_stub.sql` simule `auth` pour tester hors Supabase : ne pas le lancer sur un vrai projet.
- Les politiques d'insertion publique (clients, réservations) passent uniquement par les fonctions RPC ; aucune écriture directe pour `anon`.
- Restent à renforcer : limitation de débit sur `create_public_booking` (anti-spam), vérification du plan avant création d'employés, journalisation automatique par triggers.

## Lancer les tests

```bash
psql -d test -f supabase/tests/00_supabase_stub.sql
psql -d test -f supabase/migrations/0001_schema.sql
psql -d test -f supabase/migrations/0002_rls_and_booking_engine.sql
psql -d test -f supabase/tests/01_booking.sql
psql -d test -f supabase/tests/02_rls_isolation.sql
```

## Prochaines étapes proposées

1. Design system + landing (Next.js, Tailwind, GSAP) avec le hero interactif.
2. Parcours de réservation `/@slug` branché sur les fonctions RPC.
3. Dashboard professionnel (calendrier jour/semaine/mois).
4. Back-office admin, puis notifications et paiements.
