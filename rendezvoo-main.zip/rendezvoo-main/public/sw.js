// Service worker RENDEZVOO : coquille de l'application disponible hors ligne. Les donnees (/api) ne sont JAMAIS mises en cache.
const VERSION = 'rv-v2';   // a incrementer a chaque livraison pour renouveler le cache
const SHELL = ['/offline.html', '/css/base.css', '/css/app.css', '/css/landing.css', '/css/book.css', '/css/auth.css', '/js/ui.js', '/js/app.js', '/js/app2.js', '/js/auth.js', '/js/book.js', '/js/manage.js', '/js/landing.js', '/js/motion.js', '/js/pwa.js', '/img/favicon.svg', '/img/icon-192.png', '/app.html', '/login.html'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(VERSION).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => null)))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const req = e.request; const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/') || url.pathname === '/healthz' || url.pathname === '/sw.js') return;
  if (req.mode === 'navigate') {   // pages : reseau d'abord (contenu a jour), repli sur la coquille puis sur la page hors ligne
    e.respondWith(fetch(req).then(r => { if (r.ok && !url.pathname.startsWith('/admin')) { const c = r.clone(); caches.open(VERSION).then(x => x.put(req, c)); } return r; })
      .catch(async () => (await caches.match(req)) || (url.pathname.startsWith('/app') && await caches.match('/app.html')) || (await caches.match('/offline.html'))));
    return;
  }
  e.respondWith(caches.match(req).then(hit => { const net = fetch(req).then(r => { if (r.ok) { const c = r.clone(); caches.open(VERSION).then(x => x.put(req, c)); } return r; }).catch(() => hit); return hit || net; }));   // ressources : cache d'abord, rafraichi en arriere-plan
});
