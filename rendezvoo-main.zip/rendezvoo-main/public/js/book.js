import { h, $, $$, mount, api, t, addDict, initLang, setLang, getLang, money, icon, errMsg, field, dur, dateShort, dateLong, addDays, todayIn, toast } from './ui.js';

addDict({ 'b.svc': 'Choisissez une prestation', 'b.staff': 'Avec qui ?', 'b.any': 'Peu importe', 'b.date': 'Choisissez un jour et une heure', 'b.you': 'Vos coordonnées', 'b.name': 'Nom et prénom', 'b.phone': 'Téléphone (avec indicatif)', 'b.email': 'E-mail (facultatif)', 'b.notes': 'Message (facultatif)',
  'b.confirm': 'Confirmer le rendez-vous', 'b.none': 'Aucun créneau libre ce jour. Essayez un autre jour.', 'b.loading': 'Chargement des créneaux…', 'b.about': 'À propos', 'b.reviews': 'Avis clients', 'b.ok': 'Rendez-vous confirmé.', 'b.okp': 'Gardez ce lien : il permet de déplacer ou d’annuler.', 'b.manage': 'Gérer mon rendez-vous',
  'b.ics': 'Ajouter à mon agenda', 'b.share': 'Partager cette page', 'b.copy': 'Copier le lien', 'b.copied': 'Lien copié', 'b.when': 'Quand', 'b.what': 'Quoi', 'b.who': 'Avec', 'b.price': 'Prix', 'b.hours': 'Horaires', 'b.notfound': 'Cette page n’existe pas ou n’est plus disponible.', 'b.again': 'Prendre un autre rendez-vous',
  'b.sum': 'Votre rendez-vous', 'b.pick1': 'Choisissez d’abord une prestation.', 'b.pick2': 'Choisissez un créneau.', 'b.wd': ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'], 'b.closed': 'Fermé', 'b.reviewsn': '{n} avis', 'b.tz': 'Heures de {tz}' },
  { 'b.svc': 'Pick a service', 'b.staff': 'With whom?', 'b.any': 'No preference', 'b.date': 'Pick a day and time', 'b.you': 'Your details', 'b.name': 'Full name', 'b.phone': 'Phone (with country code)', 'b.email': 'Email (optional)', 'b.notes': 'Message (optional)',
  'b.confirm': 'Confirm appointment', 'b.none': 'No free slot that day. Try another day.', 'b.loading': 'Loading slots…', 'b.about': 'About', 'b.reviews': 'Client reviews', 'b.ok': 'Appointment confirmed.', 'b.okp': 'Keep this link: it lets you move or cancel.', 'b.manage': 'Manage my appointment',
  'b.ics': 'Add to my calendar', 'b.share': 'Share this page', 'b.copy': 'Copy link', 'b.copied': 'Link copied', 'b.when': 'When', 'b.what': 'What', 'b.who': 'With', 'b.price': 'Price', 'b.hours': 'Hours', 'b.notfound': 'This page does not exist or is no longer available.', 'b.again': 'Book another appointment',
  'b.sum': 'Your appointment', 'b.pick1': 'Pick a service first.', 'b.pick2': 'Pick a time.', 'b.closed': 'Closed', 'b.reviewsn': '{n} reviews', 'b.tz': 'Times in {tz}' });

const slug = decodeURIComponent(location.pathname).replace(/^\/@/, '').replace(/\/$/, '');
const S = { org: null, svc: null, staff: 0, date: null, slot: null, slots: null };
const root = $('#root');

async function load() {
  try { S.org = await api('GET', '/api/public/org/' + encodeURIComponent(slug)); } catch { return mount(root, h('p', { class: 'serif', style: 'padding:4rem 0;font-size:1.4rem' }, t('b.notfound'))); }
  document.documentElement.style.setProperty('--cobalt', S.org.accent); render();
}
const eligible = () => S.org.staff.filter(s => s.service_ids.includes(S.svc?.id));
const workWd = () => new Set(S.org.hours.map(x => x.weekday));
const days = () => { const t0 = todayIn(S.org.timezone); return [...Array(21)].map((_, i) => addDays(t0, i)); };
const wdOf = (iso) => new Date(iso + 'T00:00:00Z').getUTCDay();

function render() {
  const o = S.org; const L = getLang(); $('#lang').textContent = L === 'en' ? 'FR' : 'EN';
  const rating = o.rating && h('span', {}, icon('star'), `${o.rating.average} · ${t('b.reviewsn', { n: o.rating.count })}`);
  const left = h('div', { class: 'sec' }, h('h2', {}, t('b.svc')), h('div', { class: 'svc-list' }, o.services.map(s => h('button', { class: 'svc', 'aria-pressed': String(S.svc?.id === s.id), onclick: () => { S.svc = s; S.slot = null; S.slots = null; S.staff = 0; if (!S.date) S.date = days().find(d => workWd().has(wdOf(d))); render(); loadSlots(); $('#panel').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'nearest' }); } }, h('b', {}, s.name), h('small', {}, [dur(s.duration_min), s.description].filter(Boolean).join(' · ')), h('span', { class: 'pr' }, money(s.price, o.currency))))));
  const revs = o.reviews.length ? h('section', { class: 'sec', style: 'margin-top:4rem' }, h('h2', {}, t('b.reviews')), h('div', { class: 'reviews' }, o.reviews.map(r => h('div', { class: 'rev' }, h('span', { class: 'stars', 'aria-label': `${r.rating}/5` }, '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating)), h('p', {}, r.comment), h('small', { class: 'hint' }, r.author))))) : null;
  mount(root,
    h('section', { class: 'cover' }, h('h1', {}, o.name), h('p', { class: 'meta' }, o.category_label && h('span', {}, o.category_label), o.address && h('span', {}, icon('pin'), o.address), o.phone && h('span', {}, h('a', { href: 'tel:' + o.phone }, o.phone)), rating)),
    o.bio ? h('section', { class: 'about' }, h('p', { class: 'serif' }, o.bio)) : null,
    h('div', { class: 'layout' }, left, h('aside', { class: 'panel', id: 'panel', 'aria-label': t('b.date') }, panel())), revs);
}

function panel() {
  const o = S.org; if (!S.svc) return h('div', { class: 'summary' }, h('b', {}, t('b.date')), h('p', { class: 'hint' }, t('b.pick1')));
  const el = h('div', { class: 'panel' });
  const st = eligible();
  if (st.length > 1) { const sel = h('select', {}, h('option', { value: 0 }, t('b.any')), st.map(s => h('option', { value: s.id, selected: S.staff === s.id }, s.name))); sel.addEventListener('change', () => { S.staff = +sel.value; S.slot = null; loadSlots(); }); el.append(field(t('b.staff'), sel)); }
  const wd = workWd();
  el.append(h('div', {}, h('h2', { style: 'font-size:var(--step-1);margin-bottom:.7rem' }, t('b.date')),
    h('div', { class: 'days', role: 'group', 'aria-label': t('b.date') }, days().map(d => h('button', { class: 'day', disabled: !wd.has(wdOf(d)), 'aria-pressed': String(d === S.date), onclick: () => { S.date = d; S.slot = null; loadSlots(); updatePanel(); } }, h('small', {}, new Intl.DateTimeFormat(getLang() === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'short', timeZone: 'UTC' }).format(new Date(d + 'T00:00:00Z'))), h('b', { class: 'num' }, +d.slice(8)), h('small', {}, new Intl.DateTimeFormat(getLang() === 'en' ? 'en-GB' : 'fr-FR', { month: 'short', timeZone: 'UTC' }).format(new Date(d + 'T00:00:00Z')))))),
    h('p', { class: 'hint', style: 'margin-top:.4rem' }, t('b.tz', { tz: o.timezone }))));
  const slotsBox = h('div', { id: 'slots', 'aria-live': 'polite' }); el.append(slotsBox); fillSlots(slotsBox);
  if (S.slot) el.append(formBlock());
  return el;
}
function updatePanel() { mount($('#panel'), panel()); }
async function loadSlots() {
  if (!S.svc || !S.date) return; S.slots = null; updatePanel(); const mine = [S.svc.id, S.date, S.staff].join();
  try { const r = await api('GET', `/api/public/slots?slug=${encodeURIComponent(slug)}&service=${S.svc.id}&date=${S.date}${S.staff ? '&staff=' + S.staff : ''}`); if (mine !== [S.svc?.id, S.date, S.staff].join()) return; S.slots = r.slots; } catch (e) { S.slots = []; toast(errMsg(e), true); } updatePanel();
}
function fillSlots(box) {
  if (S.slots === null) return box.append(h('p', { class: 'hint' }, t('b.loading')));
  if (!S.slots.length) return box.append(h('p', { class: 'hint' }, t('b.none')));
  box.append(h('div', { class: 'slots', role: 'group', 'aria-label': dateLong(S.date) }, S.slots.map(s => h('button', { class: 'slot', 'aria-pressed': String(S.slot?.start_ms === s.start_ms), onclick: () => { S.slot = s; updatePanel(); $('#bk-name')?.focus(); } }, s.time))));
}
function formBlock() {
  const o = S.org; const name = h('input', { type: 'text', autocomplete: 'name', required: true, maxlength: 80 }), phone = h('input', { type: 'tel', autocomplete: 'tel', inputmode: 'tel', required: true, placeholder: '+221 77 000 00 00' }), email = h('input', { type: 'email', autocomplete: 'email', maxlength: 120 }), notes = h('textarea', { maxlength: 500 });
  const err = h('p', { class: 'err', role: 'alert' }); const btn = h('button', { class: 'btn cobalt', type: 'submit' }, t('b.confirm'));
  const f = field(t('b.name'), name); name.id = 'bk-name';
  const form = h('form', { class: 'stack', novalidate: true, onsubmit: async (e) => { e.preventDefault(); err.textContent = ''; btn.disabled = true;
    try { const b = await api('POST', '/api/public/book', { slug, service_id: S.svc.id, staff_id: S.staff || undefined, start_ms: S.slot.start_ms, name: name.value, phone: phone.value, email: email.value, notes: notes.value }); success(b); }
    catch (x) { err.textContent = errMsg(x); btn.disabled = false; if (x.code === 'slot_unavailable') { S.slot = null; loadSlots(); } } } },
    h('h2', { style: 'font-size:var(--step-1)' }, t('b.you')), h('div', { class: 'summary' }, h('small', { class: 'hint' }, t('b.sum')), h('b', {}, S.svc.name), h('span', { class: 'num' }, `${dateLong(S.date)}, ${S.slot.time} · ${dur(S.svc.duration_min)} · ${money(S.svc.price, o.currency)}`)),
    f, field(t('b.phone'), phone), field(t('b.email'), email), field(t('b.notes'), notes), err, btn);
  return form;
}
function ics(b) { const d = (ms) => new Date(ms).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); const esc = (s) => String(s).replace(/[\;,]/g, '\\$&').replace(/\n/g, '\\n');
  return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//RENDEZVOO//FR', 'BEGIN:VEVENT', `UID:${b.token}@rendezvoo`, `DTSTAMP:${d(Date.now())}`, `DTSTART:${d(b.start_ms)}`, `DTEND:${d(b.end_ms)}`, `SUMMARY:${esc(b.service + ' – ' + b.org.name)}`, `LOCATION:${esc(b.org.address || '')}`, 'END:VEVENT', 'END:VCALENDAR'].join('\r\n'); }
function success(b) {
  const url = `${location.origin}/r/${b.token}`; const page = `${location.origin}/@${slug}`;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('viewBox', '0 0 64 64'); svg.setAttribute('class', 'ok'); for (const [tag, a] of [['rect', { x: 2, y: 2, width: 60, height: 60, stroke: '#0d1b16', 'stroke-width': 2 }], ['path', { d: 'M17 34l10 10 21-24', stroke: S.org.accent, 'stroke-width': 5 }]]) { const e = document.createElementNS('http://www.w3.org/2000/svg', tag); e.setAttribute('fill', 'none'); e.setAttribute('pathLength', 1); for (const [k, v] of Object.entries(a)) e.setAttribute(k, v); svg.append(e); }
  const share = encodeURIComponent(`${S.org.name} – ${page}`);
  const box = h('section', { class: 'success', 'aria-live': 'polite' }, svg, h('h2', {}, t('b.ok')),
    h('dl', { class: 'kv' }, h('dt', {}, t('b.what')), h('dd', {}, b.service), h('dt', {}, t('b.when')), h('dd', { class: 'num' }, `${dateLong(b.date)}, ${b.time}`), h('dt', {}, t('b.who')), h('dd', {}, b.staff), h('dt', {}, t('b.price')), h('dd', {}, money(b.price, S.org.currency))),
    h('p', { class: 'serif' }, t('b.okp')), h('div', { class: 'row' }, h('a', { class: 'btn cobalt', href: '/r/' + b.token }, t('b.manage')),
      h('button', { class: 'btn ghost', onclick: () => { const a = h('a', { href: URL.createObjectURL(new Blob([ics(b)], { type: 'text/calendar' })), download: 'rendez-vous.ics' }); a.click(); } }, t('b.ics'))),
    h('div', { class: 'row' }, h('span', { class: 'hint' }, t('b.share')), h('a', { class: 'btn ghost small', href: `https://wa.me/?text=${share}`, target: '_blank', rel: 'noopener' }, 'WhatsApp'), h('a', { class: 'btn ghost small', href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(page)}`, target: '_blank', rel: 'noopener' }, 'Facebook'),
      h('button', { class: 'btn ghost small', onclick: async () => { if (navigator.share) { try { await navigator.share({ title: S.org.name, url: page }); return; } catch {} } try { await navigator.clipboard.writeText(page); toast(t('b.copied')); } catch { toast(page); } } }, 'Instagram · TikTok · ' + t('b.copy'))),
    h('button', { class: 'link', style: 'justify-self:start', onclick: () => { S.svc = null; S.slot = null; S.slots = null; render(); scrollTo(0, 0); } }, t('b.again')));
  $('.layout').replaceWith(box); box.scrollIntoView({ block: 'start' }); void url;
}
$('#lang').addEventListener('click', () => { setLang(getLang() === 'en' ? 'fr' : 'en'); if (S.org) render(); });
initLang(); load();
