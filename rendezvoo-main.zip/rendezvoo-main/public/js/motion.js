// Moteur d'animation maison : revelations, parallaxe, boutons magnetiques, inclinaison 3D, curseur, menu, transitions de page.
import { $, $$, lowPower } from './ui.js';

const reduce = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
export function splitHeadings() {
  $$('h2[data-split]').forEach(el => {
    if (el.classList.contains('split')) return; const words = el.textContent.trim().split(/\s+/); el.setAttribute('aria-label', el.textContent.trim()); el.textContent = '';
    words.forEach((w, i) => { const o = document.createElement('span'); o.className = 'w'; o.setAttribute('aria-hidden', 'true'); const n = document.createElement('i'); n.textContent = w; n.style.setProperty('--n', i); o.append(n); el.append(o, document.createTextNode(' ')); });
    el.classList.add('split'); if (reduce() || lowPower()) el.classList.add('in'); else io.observe(el);
  });
}
const io = new IntersectionObserver((es) => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.25 });

export function initMotion() {
  const body = document.body, top = $('#top'), low = lowPower(); if (low) body.classList.add('lite');
  // Introduction : une seule fois par session, jamais en mouvement reduit
  const loader = $('#loader'); let seen = false, nav = false; try { seen = sessionStorage.getItem('rv_intro') === '1'; nav = sessionStorage.getItem('rv_trans') === '1'; sessionStorage.removeItem('rv_trans'); } catch {}
  const end = () => { body.classList.remove('is-loading'); setTimeout(() => loader?.remove(), 1200); };
  if (low || seen || nav) { loader?.remove(); body.classList.remove('is-loading'); } else { try { sessionStorage.setItem('rv_intro', '1'); } catch {} setTimeout(() => { loader.classList.add('done'); setTimeout(end, 250); }, 1900); }
  // Transition d'arrivee depuis une autre page
  const curtain = $('#curtain'); if (nav && !low) { curtain.style.transition = 'none'; curtain.classList.add('cover'); curtain.offsetHeight; curtain.style.transition = ''; curtain.classList.remove('cover'); curtain.classList.add('leave'); setTimeout(() => curtain.classList.remove('leave'), 700); curtain.addEventListener('transitionend', () => { curtain.style.transition = 'none'; curtain.classList.remove('leave'); curtain.offsetHeight; curtain.style.transition = ''; }, { once: true }); }
  addEventListener('pageshow', (e) => { if (e.persisted) curtain.classList.remove('cover'); });
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]'); if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target || low) return;
    const u = new URL(a.href, location.href); if (u.origin !== location.origin || (u.pathname === location.pathname && u.hash)) return;
    e.preventDefault(); try { sessionStorage.setItem('rv_trans', '1'); } catch {} curtain.classList.add('cover'); setTimeout(() => { location.href = a.href; }, 480);
  });
  // Menu plein ecran
  const menu = $('#menu'), mb = $('#menu-btn');
  const toggle = (open) => { if (open) { menu.hidden = false; requestAnimationFrame(() => menu.classList.add('open')); } else { menu.classList.remove('open'); setTimeout(() => { if (!menu.classList.contains('open')) menu.hidden = true; }, 700); } mb.setAttribute('aria-expanded', String(open)); body.classList.toggle('menu-open', open); mb.firstElementChild.textContent = open ? (document.documentElement.lang === 'en' ? 'Close' : 'Fermer') : (document.documentElement.lang === 'en' ? 'Menu' : 'Menu'); if (open) menu.querySelector('a').focus(); else mb.focus(); };
  mb.addEventListener('click', () => toggle(!menu.classList.contains('open'))); document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && menu.classList.contains('open')) toggle(false); });
  menu.addEventListener('click', (e) => { if (e.target.closest('a')) { toggle(false); } });
  // Scroll : en-tete, parallaxe, revelation de section
  const plx = () => $$('[data-plx], [data-plx-x]'); let ticking = false; const demo = $('#demo');
  const onScroll = () => { ticking = false; const y = scrollY, vh = innerHeight; top.classList.toggle('scrolled', y > 24);
    if (!low) { for (const el of plx()) { const r = el.getBoundingClientRect(); if (r.bottom < -200 || r.top > vh + 200) continue; const c = (r.top + r.height / 2 - vh / 2); if (el.dataset.plx) el.style.transform = `translate3d(0,${(c * parseFloat(el.dataset.plx)).toFixed(1)}px,0)`; else el.style.transform = `translate3d(${(c * parseFloat(el.dataset.plxX)).toFixed(1)}px,0,0)`; }
      if (demo) { const r = demo.getBoundingClientRect(); demo.style.setProperty('--reveal', Math.min(1, Math.max(0, (vh - r.top) / (vh * 0.55))).toFixed(3)); } } };
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true }); addEventListener('resize', onScroll); onScroll();
  $('.hero-title')?.setAttribute('data-plx', '-0.05'); $('#stage')?.setAttribute('data-plx', '0.04');
  initMotion.refresh = () => { bindPointer(); onScroll(); };
  // Pointeur fin : boutons magnetiques, inclinaison 3D, curseur
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches && !low; let bound = new WeakSet();
  function bindPointer() { if (!fine) return;
    $$('[data-magnetic]').forEach(el => { if (bound.has(el)) return; bound.add(el); el.addEventListener('pointermove', (e) => { const r = el.getBoundingClientRect(); el.style.transform = `translate(${((e.clientX - r.left) / r.width - .5) * 14}px,${((e.clientY - r.top) / r.height - .5) * 10}px)`; }); el.addEventListener('pointerleave', () => { el.style.transform = ''; }); });
    $$('.tilt').forEach(el => { if (bound.has(el)) return; bound.add(el); el.addEventListener('pointermove', (e) => { const r = el.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; el.style.transform = `perspective(900px) rotateY(${(x * 5).toFixed(2)}deg) rotateX(${(-y * 4).toFixed(2)}deg)`; }); el.addEventListener('pointerleave', () => { el.style.transform = ''; }); }); }
  bindPointer();
  if (fine) { const cur = $('#cursor'); body.classList.add('has-cursor'); let x = innerWidth / 2, y = innerHeight / 2, tx = x, ty = y; addEventListener('pointermove', (e) => { tx = e.clientX; ty = e.clientY; }, { passive: true });
    (function loop() { x += (tx - x) * .22; y += (ty - y) * .22; cur.style.transform = `translate(${x}px,${y}px)`; requestAnimationFrame(loop); })();
    document.addEventListener('pointerover', (e) => cur.classList.toggle('big', !!e.target.closest('a,button,summary,.choice,.slot,.day'))); }
}
