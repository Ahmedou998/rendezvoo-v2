import { h, $, $$, mount, clear, api as rawApi, errMsg, money, icon, toast, modal, field, dur, dateLong, dateShort, addDays, todayIn } from './ui.js';
import { pwa } from './pwa.js';
import { servicesView, staffView, hoursView, paymentsView, notificationsView, statsView, settingsView } from './app2.js';

export const ctx = { org: null, orgs: [], me: null, settings: null, staff: [], services: [] };
export const api = (m, p, b) => { const o = localStorage.getItem('rv_org'); return rawApi(m, p, b, o ? { 'X-Org-Id': o } : {}); };
export const fail = (e) => { if (e.status === 401) location.href = '/login?next=/app'; else toast(errMsg(e), true); };
export const money0 = (n) => money(n, ctx.settings?.currency || 'XOF');
const STATUS = { confirmed: 'Confirmé', pending: 'En attente', completed: 'Terminé', cancelled: 'Annulé', no_show: 'Absent' };
export const stBadge = (s) => h('span', { class: 'st ' + s }, STATUS[s] || s);
const NAV = [['accueil', 'Vue générale', 'home'], ['calendrier', 'Calendrier', 'calendar'], ['reservations', 'Réservations', 'list'], ['clients', 'Clients', 'users'], ['prestations', 'Prestations', 'scissors'], ['employes', 'Employés', 'users'],
  ['horaires', 'Horaires', 'clock'], ['paiements', 'Paiements', 'card'], ['notifications', 'Notifications', 'bell'], ['statistiques', 'Statistiques', 'chart'], ['parametres', 'Paramètres', 'gear']];
const VIEWS = { accueil: overview, calendrier: calendarView, reservations: bookingsView, clients: clientsView, prestations: servicesView, employes: staffView, horaires: hoursView, paiements: paymentsView, notifications: notificationsView, statistiques: statsView, parametres: settingsView };

// Bouton « Installer l'application » : natif sur Android/Chrome/Edge ; sur iPhone, explication Partager > Sur l'ecran d'accueil
function installBtn() {
  const b = h('button', { class: 'btn small', hidden: true, onclick: async () => { if (pwa.canPrompt()) { if (await pwa.install()) toast('Application installée'); } else modal('Installer sur iPhone ou iPad', h('ol', { class: 'stack' }, h('li', {}, 'Ouvrez cette page dans Safari.'), h('li', {}, 'Touchez le bouton Partager.'), h('li', {}, 'Choisissez « Sur l’écran d’accueil ».'))); } }, icon('plus'), 'Installer l’application');
  const sync = () => { b.hidden = pwa.standalone() || !(pwa.canPrompt() || pwa.isIos()); }; sync(); document.addEventListener('rv:installable', sync); document.addEventListener('rv:installed', sync); return b;
}
function logoSvg() { const NS = 'http://www.w3.org/2000/svg'; const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 32 32'); s.setAttribute('width', 22); s.setAttribute('height', 22); s.setAttribute('aria-hidden', 'true');
  const r = document.createElementNS(NS, 'rect'); r.setAttribute('width', 32); r.setAttribute('height', 32); r.setAttribute('fill', 'currentColor'); const p = document.createElementNS(NS, 'path'); p.setAttribute('d', 'M8 17l6 6 11-13'); p.setAttribute('fill', 'none'); p.setAttribute('stroke', '#0d1b16'); p.setAttribute('stroke-width', 3.2); s.append(r, p); return s; }
async function boot() {
  try { ctx.me = await api('GET', '/api/me'); } catch (e) {
    if (e.status === 401) return (location.href = '/login?next=/app');
    // Pas de reponse du serveur (hors ligne, serveur arrete) : on ne deconnecte pas, on propose de reessayer
    return mount($('#app'), h('main', { style: 'min-height:100dvh;display:grid;place-content:center;gap:1rem;padding:2rem;max-width:30rem' }, h('h1', { style: 'font-size:var(--step-3)' }, 'Connexion impossible.'),
      h('p', { class: 'serif' }, 'RENDEZVOO ne répond pas. Vérifiez votre connexion : vos rendez-vous et vos données n’ont pas été modifiés.'), h('button', { class: 'btn', onclick: () => location.reload() }, 'Réessayer')));
  }
  ctx.orgs = ctx.me.orgs; if (!ctx.orgs.length) { return mount($('#app'), h('p', { style: 'padding:3rem' }, 'Aucun espace professionnel n’est lié à ce compte. ', h('a', { class: 'link', href: ctx.me.user.platform_role ? '/admin' : '/inscription' }, 'Continuer'))); }
  const saved = +localStorage.getItem('rv_org'); if (!ctx.orgs.some(o => o.id === saved)) localStorage.setItem('rv_org', ctx.orgs[0].id);
  ctx.org = ctx.orgs.find(o => o.id === +localStorage.getItem('rv_org'));
  await refreshRefs(); shell(); route(); addEventListener('hashchange', route);
}
export async function refreshRefs() { [ctx.settings, ctx.staff, ctx.services] = await Promise.all([api('GET', '/api/pro/settings'), api('GET', '/api/pro/staff'), api('GET', '/api/pro/services')]); }

function shell() {
  const nav = h('nav', { class: 'nav', id: 'nav', 'aria-label': 'Navigation de l’espace professionnel' }, NAV.map(([k, l, i]) => h('a', { href: '#' + k, 'data-k': k }, icon(i), l)));
  const tg = h('button', { class: 'side-toggle', 'aria-expanded': 'false', 'aria-controls': 'nav', onclick: () => { const o = nav.classList.toggle('open'); tg.setAttribute('aria-expanded', String(o)); } }, icon('menu'), ' Menu');
  const orgSel = ctx.orgs.length > 1 ? h('select', { class: 'input', style: 'width:auto;min-height:2.3rem', 'aria-label': 'Établissement', onchange: (e) => { localStorage.setItem('rv_org', e.target.value); location.reload(); } }, ctx.orgs.map(o => h('option', { value: o.id, selected: o.id === ctx.org.id }, o.name))) : null;
  mount($('#app'), h('div', { class: 'layout-app' }, h('aside', { class: 'side' }, h('div', { class: 'side-top' }, h('a', { class: 'logo', href: '/' }, logoSvg(), 'rendezvoo'), tg), nav,
    h('div', { class: 'side-foot' }, h('span', {}, ctx.me.user.name), ctx.me.user.platform_role ? h('a', { href: '/admin', class: 'link', style: 'color:#9aa4ff' }, 'Administration') : null, h('button', { class: 'link', style: 'color:#9aa4ff;text-align:left', onclick: async () => { await api('POST', '/api/auth/logout'); location.href = '/login'; } }, 'Se déconnecter'))),
    h('div', { class: 'main' }, h('header', { class: 'topbar' }, h('h1', { id: 'ttl' }), h('div', { class: 'row' }, orgSel, installBtn(), h('a', { class: 'btn ghost small', href: '/@' + ctx.org.slug, target: '_blank', rel: 'noopener' }, icon('link'), 'Ma page publique'))), h('main', { class: 'view', id: 'view', tabindex: '-1' }))));
}
async function route() {
  const k = (location.hash.slice(1).split('?')[0] || 'accueil'); const key = VIEWS[k] ? k : 'accueil'; $$('.nav a').forEach(a => a.dataset.k === key ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  $('#nav').classList.remove('open'); $('#ttl').textContent = NAV.find(n => n[0] === key)[1]; document.title = NAV.find(n => n[0] === key)[1] + ' – RENDEZVOO'; const v = $('#view'); mount(v, h('p', { class: 'hint' }, 'Chargement…'));
  try { await refreshRefs(); const el = await VIEWS[key](); mount(v, el); } catch (e) { fail(e); mount(v, h('p', { class: 'err' }, errMsg(e))); }
}

// ---------- Vue generale
async function overview() {
  const o = await api('GET', '/api/pro/overview'); const sub = o.subscription; const days = Math.ceil((sub.trial_ends_ms - Date.now()) / 864e5);
  const url = `${location.origin}/@${o.org.slug}`;
  const banners = [];
  if (o.org.suspended) banners.push(h('div', { class: 'banner warn', role: 'alert' }, h('span', {}, 'Votre page est suspendue par l’administration RENDEZVOO : les réservations en ligne sont fermées. Contactez le support.')));
  if (sub.status === 'trialing') banners.push(h('div', { class: 'banner ' + (days <= 3 ? 'warn' : 'info') }, h('span', {}, days > 0 ? `Essai gratuit : ${days} jour${days > 1 ? 's' : ''} restant${days > 1 ? 's' : ''}.` : 'Votre essai est terminé : les réservations en ligne sont fermées.'), h('a', { class: 'btn small', style: '--bg:var(--cobalt);--fg:#fff', href: '#paiements' }, 'Choisir une formule')));
  if (sub.status === 'past_due') banners.push(h('div', { class: 'banner warn', role: 'alert' }, 'Paiement en retard.', h('a', { class: 'btn small', href: '#paiements' }, 'Régulariser')));
  const first = location.hash.includes('bienvenue') ? h('section', { class: 'card' }, h('h2', {}, 'Bienvenue. Trois étapes avant la première réservation.'), h('ul', { class: 'check-list' },
    h('li', {}, icon('check'), h('span', {}, h('a', { class: 'link', href: '#prestations' }, 'Ajoutez vos prestations'), ' avec durée et prix.')), h('li', {}, icon('check'), h('span', {}, h('a', { class: 'link', href: '#horaires' }, 'Vérifiez vos horaires'), ' (par défaut du lundi au samedi, 9 h – 18 h).')),
    h('li', {}, icon('check'), h('span', {}, 'Partagez votre lien : '), h('span', { class: 'code' }, url)))) : null;
  return h('div', { class: 'stack' }, ...banners, first,
    h('div', { class: 'kpis' }, h('div', { class: 'kpi' }, h('b', {}, o.month_bookings), h('span', {}, 'Réservations ce mois')), h('div', { class: 'kpi' }, h('b', {}, money(o.revenue_declared, o.org.currency)), h('span', {}, 'Chiffre d’affaires déclaré (terminés)')), h('div', { class: 'kpi' }, h('b', {}, money(o.revenue_expected, o.org.currency)), h('span', {}, 'À venir')), h('div', { class: 'kpi' }, h('b', {}, o.cancel_rate + ' %'), h('span', {}, 'Taux d’annulation'))),
    h('div', { class: 'cols' }, h('section', { class: 'card' }, h('h2', {}, 'Rendez-vous à venir'), o.upcoming.length ? h('div', { class: 'list' }, o.upcoming.map(b => h('button', { class: 'link', style: 'text-decoration:none;color:inherit;text-align:left;width:100%;display:flex;justify-content:space-between;gap:1rem;padding:.7rem 0;border-top:1px solid var(--fil);background:none;border-left:0;border-right:0;border-bottom:0;cursor:pointer', onclick: () => bookingModal(b.id, refreshView) }, h('span', {}, h('b', {}, b.customer), h('br'), h('span', { class: 'hint' }, `${b.service} · ${b.staff}`)), h('span', { class: 'num' }, `${dateShort(b.date)}, ${b.time}`)))) : h('div', { class: 'empty' }, h('p', {}, 'Aucun rendez-vous à venir.'), h('p', { class: 'hint' }, 'Partagez votre lien pour recevoir vos premières réservations :'), h('span', { class: 'code' }, url), h('button', { class: 'btn small', onclick: () => copy(url) }, 'Copier le lien'))),
      h('section', { class: 'card' }, h('h2', {}, 'Clients récents'), o.recent_customers.length ? h('div', { class: 'list' }, o.recent_customers.map(c => h('div', {}, h('span', {}, h('b', {}, c.name), h('br'), h('span', { class: 'hint' }, c.phone)), h('span', { class: 'hint' }, c.visits + ' visite' + (c.visits > 1 ? 's' : ''))))) : h('p', { class: 'hint' }, 'Vos clients apparaîtront ici après leur première réservation.'), h('a', { class: 'link', href: '#clients' }, 'Voir tous les clients'))),
    h('div', { class: 'row' }, h('a', { class: 'btn', href: '#calendrier' }, icon('calendar'), 'Ouvrir le calendrier'), h('button', { class: 'btn ghost', onclick: () => newBookingModal({}, refreshView) }, icon('plus'), 'Nouveau rendez-vous')));
}
export const refreshView = () => route();
const copy = async (v) => { try { await navigator.clipboard.writeText(v); toast('Lien copié'); } catch { toast(v); } };

// ---------- Modales reservation
export function newBookingModal(pre, done) {
  const svc = h('select', {}, ctx.services.filter(s => s.active).map(s => h('option', { value: s.id }, `${s.name} – ${dur(s.duration_min)}`))), st = h('select', {}), date = h('input', { type: 'date', value: pre.date || todayIn(ctx.settings.timezone) }), time = h('input', { type: 'time', value: pre.time || '10:00', step: 900 });
  const name = h('input', { type: 'text', maxlength: 80 }), phone = h('input', { type: 'tel', placeholder: '+221 77 000 00 00' }), email = h('input', { type: 'email' }), notes = h('textarea', {}), err = h('p', { class: 'err', role: 'alert' });
  const fillStaff = () => { const s = ctx.services.find(x => x.id === +svc.value); clear(st).append(...ctx.staff.filter(x => x.active && s?.staff_ids.includes(x.id)).map(x => h('option', { value: x.id, selected: x.id === pre.staff_id }, x.name))); }; svc.addEventListener('change', fillStaff); fillStaff();
  if (!ctx.services.some(s => s.active)) return toast('Ajoutez d’abord une prestation.', true);
  const m = modal('Nouveau rendez-vous', h('form', { class: 'stack', onsubmit: async (e) => { e.preventDefault(); err.textContent = ''; try { await api('POST', '/api/pro/bookings', { service_id: +svc.value, staff_id: +st.value, date: date.value, time: time.value, name: name.value, phone: phone.value, email: email.value, notes: notes.value }); m.close(); toast('Rendez-vous créé'); done?.(); } catch (x) { err.textContent = errMsg(x); } } },
    field('Prestation', svc), field('Employé', st), h('div', { class: 'grid2' }, field('Date', date), field('Heure', time)), field('Nom du client', name), field('Téléphone', phone), field('E-mail (facultatif)', email), field('Notes', notes), err, h('button', { class: 'btn cobalt', type: 'submit' }, 'Créer le rendez-vous')));
}
export async function bookingModal(id, done) {
  let b; try { b = await api('GET', '/api/pro/bookings/' + id); } catch { return toast('Rendez-vous introuvable', true); }
  const date = h('input', { type: 'date', value: b.date }), time = h('input', { type: 'time', value: b.time, step: 900 }), notes = h('textarea', {}, b.notes || ''), err = h('p', { class: 'err', role: 'alert' });
  const act = async (body, msg) => { err.textContent = ''; try { await api('PATCH', '/api/pro/bookings/' + id, body); m.close(); toast(msg); done?.(); } catch (x) { err.textContent = errMsg(x); } };
  const m = modal(b.customer, h('div', { class: 'stack' }, h('div', { class: 'row' }, stBadge(b.status), h('span', { class: 'hint' }, b.source === 'manual' ? 'Créé par vous' : 'Réservé en ligne')),
    h('dl', { class: 'kv', style: 'display:grid;grid-template-columns:auto 1fr;gap:.3rem 1rem;margin:0' }, h('dt', { class: 'hint' }, 'Prestation'), h('dd', { style: 'margin:0;font-weight:600' }, `${b.service} · ${money0(b.price)}`), h('dt', { class: 'hint' }, 'Employé'), h('dd', { style: 'margin:0;font-weight:600' }, b.staff), h('dt', { class: 'hint' }, 'Téléphone'), h('dd', { style: 'margin:0;font-weight:600' }, h('a', { href: 'tel:' + b.phone }, b.phone))),
    ['pending', 'confirmed'].includes(b.status) ? h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: () => act({ status: 'completed' }, 'Marqué terminé') }, icon('check'), 'Terminé'), h('button', { class: 'btn ghost small', onclick: () => act({ status: 'no_show' }, 'Marqué absent') }, 'Absent'), h('button', { class: 'btn danger small', onclick: () => { if (confirm('Annuler ce rendez-vous ? Le client sera prévenu.')) act({ status: 'cancelled' }, 'Rendez-vous annulé'); } }, 'Annuler')) : null,
    ['pending', 'confirmed'].includes(b.status) ? h('div', { class: 'grid2' }, field('Déplacer au', date), field('à', time)) : null, ['pending', 'confirmed'].includes(b.status) ? h('button', { class: 'btn ghost small', style: 'justify-self:start', onclick: () => act({ date: date.value, time: time.value }, 'Rendez-vous déplacé') }, 'Déplacer') : null,
    field('Notes internes', notes), h('button', { class: 'btn ghost small', style: 'justify-self:start', onclick: () => act({ notes: notes.value }, 'Notes enregistrées') }, 'Enregistrer les notes'), err));
}

// ---------- Calendrier
const cs = { view: 'week', date: null, staff: 0 };
async function calendarView() {
  const tz = ctx.settings.timezone; cs.date ||= todayIn(tz); const today = todayIn(tz); const wd = (iso) => new Date(iso + 'T00:00:00Z').getUTCDay(); const monday = (iso) => addDays(iso, -((wd(iso) + 6) % 7));
  let from, to; if (cs.view === 'day') from = to = cs.date; else if (cs.view === 'week') { from = monday(cs.date); to = addDays(from, 6); } else { const f = cs.date.slice(0, 8) + '01'; from = monday(f); const last = addDays(addDays(f, 32).slice(0, 8) + '01', -1); to = addDays(monday(last), 6); }
  const [bks, hours, off] = await Promise.all([api('GET', `/api/pro/bookings?from=${from}&to=${to}${cs.staff ? '&staff=' + cs.staff : ''}`), api('GET', '/api/pro/hours'), api('GET', '/api/pro/timeoff')]); void off;
  const rerender = () => route(); const mins = (s) => +s.slice(0, 2) * 60 + +s.slice(3);
  const h0 = Math.min(8, ...hours.map(x => Math.floor(mins(x.start) / 60))), h1 = Math.max(18, ...hours.map(x => Math.ceil(mins(x.end) / 60))); const HH = 56;
  const step = (n) => { cs.date = cs.view === 'month' ? addDays(cs.date.slice(0, 8) + '01', n > 0 ? 32 : -1).slice(0, 8) + '01' : addDays(cs.date, n * (cs.view === 'week' ? 7 : 1)); rerender(); };
  const title = cs.view === 'month' ? new Intl.DateTimeFormat('fr-FR', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(cs.date + 'T00:00:00Z')) : cs.view === 'week' ? `${dateShort(from)} – ${dateShort(to)}` : dateLong(cs.date);
  const bar = h('div', { class: 'toolbar' }, h('div', { class: 'seg', role: 'group', 'aria-label': 'Vue' }, [['day', 'Jour'], ['week', 'Semaine'], ['month', 'Mois']].map(([k, l]) => h('button', { 'aria-pressed': String(cs.view === k), onclick: () => { cs.view = k; rerender(); } }, l))),
    h('button', { class: 'btn ghost small', 'aria-label': 'Précédent', onclick: () => step(-1) }, icon('left')), h('button', { class: 'btn ghost small', onclick: () => { cs.date = today; rerender(); } }, 'Aujourd’hui'), h('button', { class: 'btn ghost small', 'aria-label': 'Suivant', onclick: () => step(1) }, icon('right')), h('b', { style: 'text-transform:capitalize;min-width:10rem' }, title),
    ctx.staff.filter(s => s.active).length > 1 ? h('select', { class: 'input', style: 'width:auto;min-height:2.3rem', 'aria-label': 'Filtrer par employé', onchange: (e) => { cs.staff = +e.target.value; rerender(); } }, h('option', { value: 0 }, 'Tous les employés'), ctx.staff.filter(s => s.active).map(s => h('option', { value: s.id, selected: cs.staff === s.id }, s.name))) : null,
    h('button', { class: 'btn small', style: 'margin-left:auto', onclick: () => newBookingModal({ date: cs.date, staff_id: cs.staff || undefined }, rerender) }, icon('plus'), 'Nouveau'));
  if (cs.view === 'month') {
    const cells = []; for (let d = from; d <= to; d = addDays(d, 1)) { const list = bks.filter(b => b.date === d && b.status !== 'cancelled'); cells.push(h('button', { class: 'mc' + (d.slice(0, 7) !== cs.date.slice(0, 7) ? ' dim' : '') + (d === today ? ' today' : ''), onclick: () => { cs.date = d; cs.view = 'day'; rerender(); }, 'aria-label': `${dateLong(d)}, ${list.length} rendez-vous` }, h('b', {}, +d.slice(8)), list.slice(0, 3).map(b => h('i', {}, `${b.time} ${b.customer}`)), list.length > 3 ? h('em', {}, `+${list.length - 3}`) : null)); }
    return h('div', { class: 'stack' }, bar, h('div', { class: 'month' }, ['lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.', 'dim.'].map(x => h('div', { class: 'dh' }, x)), cells));
  }
  const cols = cs.view === 'day' ? ctx.staff.filter(s => s.active && (!cs.staff || s.id === cs.staff)).map(s => ({ key: s.id, label: s.name, date: cs.date, staff: s.id })) : [...Array(7)].map((_, i) => { const d = addDays(from, i); return { key: d, label: dateShort(d), date: d, today: d === today }; });
  const hourRows = h1 - h0; const axis = h('div', { class: 'axis', style: `height:${hourRows * HH}px` }, [...Array(hourRows + 1)].map((_, i) => h('span', { style: `top:${i * HH}px` }, `${String(h0 + i).padStart(2, '0')}:00`)));
  const body = h('div', { class: 'cal-body', style: `--cols:${cols.length};--hh:${HH / 2}px` }, axis, cols.map(c => {
    const col = h('div', { class: 'col' + (cs.view === 'day' || hours.some(x => x.weekday === wd(c.date)) ? '' : ' off'), style: `height:${hourRows * HH}px`, role: 'group', 'aria-label': c.label,
      onclick: (e) => { if (e.target !== col) return; const y = e.offsetY / HH * 60 + h0 * 60; const m = Math.round(y / 15) * 15; newBookingModal({ date: c.date, time: `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`, staff_id: c.staff || cs.staff || undefined }, rerender); } });
    const list = bks.filter(b => b.date === c.date && (cs.view === 'week' || b.staff_id === c.staff)); const lanes = [];
    list.forEach(b => { b._s = mins(b.time); b._e = Math.max(mins(b.end_time), b._s + 20); let l = lanes.findIndex(x => x <= b._s); if (l < 0) { l = lanes.length; lanes.push(0); } lanes[l] = b._e; b._l = l; });
    list.forEach(b => { const n = lanes.length; const el = h('button', { class: 'ev ' + b.status, style: `top:${(b._s - h0 * 60) / 60 * HH}px;height:${(b._e - b._s) / 60 * HH - 2}px;left:calc(${b._l / n * 100}% + 2px);width:calc(${100 / n}% - 4px);right:auto`, onclick: (e) => { e.stopPropagation(); bookingModal(b.id, rerender); }, 'aria-label': `${b.time} ${b.customer}, ${b.service}` }, h('b', {}, `${b.time} ${b.customer}`), b.service); col.append(el); });
    return col; }));
  return h('div', { class: 'stack' }, bar, h('div', { class: 'cal-wrap' }, h('div', { class: 'cal-head', style: `--cols:${cols.length}` }, h('div', {}), cols.map(c => h('div', { class: c.today ? 'today' : '' }, c.label))), body), h('p', { class: 'hint' }, 'Cliquez sur une plage libre pour créer un rendez-vous, ou sur un rendez-vous pour le gérer.'));
}

// ---------- Reservations
const bs = { from: null, to: null, status: '' };
async function bookingsView() {
  const tz = ctx.settings.timezone; bs.from ||= todayIn(tz); bs.to ||= addDays(bs.from, 30);
  const list = await api('GET', `/api/pro/bookings?from=${bs.from}&to=${bs.to}${bs.status ? '&status=' + bs.status : ''}`);
  const from = h('input', { type: 'date', value: bs.from, 'aria-label': 'Du' }), to = h('input', { type: 'date', value: bs.to, 'aria-label': 'Au' }), st = h('select', { 'aria-label': 'Statut' }, [['', 'Tous les statuts'], ...Object.entries(STATUS)].map(([k, l]) => h('option', { value: k, selected: k === bs.status }, l)));
  const apply = () => { bs.from = from.value; bs.to = to.value; bs.status = st.value; route(); };
  [from, to, st].forEach(x => { x.classList.add('input'); x.style.width = 'auto'; x.style.minHeight = '2.4rem'; x.addEventListener('change', apply); });
  return h('div', { class: 'stack' }, h('div', { class: 'toolbar' }, from, to, st, h('button', { class: 'btn small', style: 'margin-left:auto', onclick: () => newBookingModal({}, route) }, icon('plus'), 'Nouveau')),
    list.length ? h('div', { class: 'scroll-x' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Date', 'Heure', 'Client', 'Prestation', 'Employé', 'Prix', 'Statut'].map(x => h('th', {}, x)))), h('tbody', {}, list.map(b => h('tr', { style: 'cursor:pointer', tabindex: 0, onclick: () => bookingModal(b.id, route), onkeydown: (e) => { if (e.key === 'Enter') bookingModal(b.id, route); } }, h('td', {}, dateShort(b.date)), h('td', { class: 'num' }, b.time), h('td', {}, h('b', {}, b.customer), h('br'), h('span', { class: 'hint' }, b.phone)), h('td', {}, b.service), h('td', {}, b.staff), h('td', { class: 'num' }, money0(b.price)), h('td', {}, stBadge(b.status))))))) : h('div', { class: 'empty' }, h('p', {}, 'Aucune réservation sur cette période.'), h('button', { class: 'btn small', onclick: () => newBookingModal({}, route) }, 'Créer un rendez-vous')));
}

// ---------- Clients
let cq = '';
async function clientsView() {
  const list = await api('GET', '/api/pro/customers?q=' + encodeURIComponent(cq)); const q = h('input', { type: 'search', placeholder: 'Rechercher par nom ou téléphone', value: cq, class: 'input', style: 'max-width:22rem', 'aria-label': 'Rechercher un client' }); let t; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { cq = q.value; route(); }, 350); });
  return h('div', { class: 'stack' }, q, list.length ? h('div', { class: 'scroll-x' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, ['Client', 'Téléphone', 'Visites', 'Dépensé', 'Dernier rendez-vous'].map(x => h('th', {}, x)))), h('tbody', {}, list.map(c => h('tr', { style: 'cursor:pointer', tabindex: 0, onclick: () => clientModal(c.id), onkeydown: (e) => { if (e.key === 'Enter') clientModal(c.id); } }, h('td', {}, h('b', {}, c.name)), h('td', {}, c.phone), h('td', { class: 'num' }, c.visits), h('td', { class: 'num' }, money0(c.spent)), h('td', {}, c.last_ms ? new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium', timeZone: ctx.settings.timezone }).format(c.last_ms) : '—')))))) : h('div', { class: 'empty' }, h('p', {}, cq ? 'Aucun client ne correspond.' : 'Aucun client pour le moment.'), h('p', { class: 'hint' }, 'Ils sont ajoutés automatiquement à chaque réservation.')));
}
async function clientModal(id) {
  const c = await api('GET', '/api/pro/customers/' + id); const notes = h('textarea', {}, c.notes || ''), name = h('input', { value: c.name }), email = h('input', { type: 'email', value: c.email || '' });
  const m = modal(c.name, h('div', { class: 'stack' }, h('p', {}, h('a', { href: 'tel:' + c.phone }, c.phone), c.email ? ' · ' + c.email : ''), field('Nom', name), field('E-mail', email), field('Notes', notes),
    h('button', { class: 'btn small', style: 'justify-self:start', onclick: async () => { try { await api('PATCH', '/api/pro/customers/' + id, { name: name.value, email: email.value, notes: notes.value }); toast('Client mis à jour'); m.close(); route(); } catch (e) { fail(e); } } }, 'Enregistrer'),
    h('h3', { style: 'font-size:var(--step-0)' }, 'Historique'), h('div', { class: 'list' }, c.bookings.map(b => h('div', {}, h('span', {}, `${dateShort(b.date)}, ${b.time} · ${b.service}`), stBadge(b.status))))));
}

boot();
