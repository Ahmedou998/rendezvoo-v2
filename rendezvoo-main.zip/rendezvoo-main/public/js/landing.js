import { h, $, $$, mount, api, t, addDict, initLang, setLang, getLang, money, icon, lowPower, dur } from './ui.js';
import { initMotion, splitHeadings } from './motion.js';

addDict({
  'skip': 'Aller au contenu', 'nav.metiers': 'Métiers', 'nav.demo': 'Démonstration', 'nav.tarifs': 'Tarifs', 'nav.login': 'Se connecter', 'menu': 'Menu', 'menu.home': 'Accueil', 'menu.pro': 'Espace professionnel',
  'hero.l1': 'Votre temps', 'hero.l2': 'mérite', 'hero.l3': 'mieux.', 'hero.sub': 'La réservation et la gestion de vos rendez-vous, réinventées.', 'cta.discover': 'Découvrir RENDEZVOO', 'cta.create': 'Créer mon espace professionnel', 'scroll': 'Défiler',
  'm.h': 'Chaque métier a son agenda.', 'm.p': 'Durées, temps de préparation, plusieurs employés : vous réglez une fois, vos clients réservent ensuite seuls.',
  'd.h': 'Essayez la réservation, comme vos clients.', 'd.p': 'Démonstration avec des données fictives. Rien n’est enregistré.',
  'p.h': 'Un vrai logiciel, pas un simple formulaire.', 'p.1h': 'Zéro doublon', 'p.1p': 'Les disponibilités sont calculées sur le serveur. Même si dix personnes cliquent au même instant, un seul obtient le créneau.',
  'p.2h': 'Sans compte client', 'p.2p': 'Nom, téléphone, c’est tout. Le client reçoit un lien pour déplacer ou annuler selon vos règles.',
  'p.3h': 'Rappels automatiques', 'p.3p': 'Confirmation et rappel par e-mail, SMS ou WhatsApp via votre prestataire officiel. Vous choisissez quoi envoyer, et quand.',
  'p.4h': 'Des chiffres lisibles', 'p.4p': 'Réservations, annulations, chiffre d’affaires déclaré, prestations les plus demandées : tout est sur une page.',
  't.h': 'Un prix simple, en FCFA.', 'a.h': 'Né à Dakar, prêt pour d’autres villes.',
  'a.p1': 'Chaque espace a son fuseau horaire, sa devise (FCFA XOF ou XAF, euro) et ses numéros internationaux. Le Sénégal ouvre en premier ; la Côte d’Ivoire, le Bénin et le Togo suivent.',
  'a.p2': 'Les paiements d’abonnement passent par un prestataire agréé que vous configurez pays par pays. L’interface est disponible en français et en anglais.',
  'f.h': 'Questions fréquentes', 'f.1q': 'Mes clients doivent-ils créer un compte ?', 'f.1a': 'Non. Ils choisissent une prestation, un créneau, entrent leur nom et leur téléphone. Un lien personnel leur permet de gérer leur rendez-vous.',
  'f.2q': 'Comment fonctionne l’essai gratuit ?', 'f.2a': 'Vous créez votre espace et utilisez toutes les fonctions de base pendant la période d’essai, sans moyen de paiement. Vous choisissez ensuite une formule.',
  'f.3q': 'Les messages WhatsApp sont-ils inclus ?', 'f.3a': 'RENDEZVOO prépare et programme les messages. L’envoi passe par votre compte chez un prestataire officiel (WhatsApp Business, SMS, e-mail) ; sans identifiants, rien n’est envoyé.',
  'f.4q': 'Mes données sont-elles isolées de celles des autres ?', 'f.4a': 'Oui. Chaque professionnel a son espace indépendant, protégé par des règles d’accès au niveau de la base de données.',
  'x.h': 'Votre lien de réservation, prêt en cinq minutes.', 'foot': '© RENDEZVOO. Fait à Dakar.',
  's.cal': 'Choisissez une date', 's.svc': 'Choisissez une prestation', 's.slot': 'Choisissez un créneau', 's.done': 'Réservation confirmée', 's.dash': 'Tableau de bord', 's.booked': 'C’est réservé.',
  's.date': 'Date', 's.service': 'Prestation', 's.time': 'Heure', 's.bk': 'Réservations', 's.cx': 'Annulations', 's.ca': 'CA déclaré', 's.new': 'Nouvelle réservation',
  'tr.trial': 'Essai gratuit de {n} jours, sans carte bancaire.', 'tr.month': '/mois', 'tr.start': 'Commencer l’essai', 'pl.starter': ['Page professionnelle', 'Réservations en ligne', 'Calendrier', 'Gestion des clients'],
  'pl.pro': ['Tout Starter', 'Jusqu’à 10 employés', 'Notifications avancées', 'Statistiques', 'Personnalisation avancée'], 'pl.business': ['Tout Pro', 'Employés illimités', 'Multi-utilisateurs', 'Plusieurs établissements', 'Rapports exportables'],
  'fl.pro': 'Chez qui ?', 'fl.svc': 'Quelle prestation ?', 'fl.date': 'Quel jour, quelle heure ?', 'fl.you': 'Vos coordonnées', 'fl.ok': 'Rendez-vous confirmé', 'fl.name': 'Nom', 'fl.phone': 'Téléphone', 'fl.confirm': 'Confirmer le rendez-vous', 'fl.back': 'Retour', 'fl.again': 'Recommencer',
  'fl.okp': 'Voilà ce que vit votre client, en quelques secondes. Chez vous, il reçoit aussi une confirmation et un rappel.', 'fl.step': ['Professionnel', 'Prestation', 'Date et heure', 'Coordonnées'], 'fl.none': 'Aucun créneau libre ce jour-là.', 'fl.demo': 'Démonstration',
}, {
  'skip': 'Skip to content', 'nav.metiers': 'Trades', 'nav.demo': 'Demo', 'nav.tarifs': 'Pricing', 'nav.login': 'Sign in', 'menu': 'Menu', 'menu.home': 'Home', 'menu.pro': 'Business area',
  'hero.l1': 'Your time', 'hero.l2': 'deserves', 'hero.l3': 'better.', 'hero.sub': 'Booking and appointment management, reinvented.', 'cta.discover': 'Discover RENDEZVOO', 'cta.create': 'Create my business space', 'scroll': 'Scroll',
  'm.h': 'Every trade has its own diary.', 'm.p': 'Durations, preparation time, several staff: set it up once, then your clients book on their own.',
  'd.h': 'Try booking, the way your clients do.', 'd.p': 'Demo with fictional data. Nothing is saved.',
  'p.h': 'Real software, not just a form.', 'p.1h': 'Zero double bookings', 'p.1p': 'Availability is calculated on the server. Even if ten people click at the same instant, only one gets the slot.',
  'p.2h': 'No client account', 'p.2p': 'Name and phone, that’s all. Clients get a link to move or cancel under your rules.',
  'p.3h': 'Automatic reminders', 'p.3p': 'Confirmation and reminder by email, SMS or WhatsApp through your official provider. You choose what to send, and when.',
  'p.4h': 'Readable numbers', 'p.4p': 'Bookings, cancellations, declared revenue, top services: all on one page.',
  't.h': 'Simple pricing, in FCFA.', 'a.h': 'Born in Dakar, ready for more cities.',
  'a.p1': 'Each space has its own time zone, currency (FCFA XOF or XAF, euro) and international phone numbers. Senegal opens first; Côte d’Ivoire, Benin and Togo follow.',
  'a.p2': 'Subscription payments go through a licensed provider that you configure country by country. The interface is available in French and English.',
  'f.h': 'Frequently asked questions', 'f.1q': 'Do my clients need an account?', 'f.1a': 'No. They pick a service and a slot, then enter their name and phone. A personal link lets them manage their appointment.',
  'f.2q': 'How does the free trial work?', 'f.2a': 'You create your space and use all core features during the trial, with no payment method. You pick a plan afterwards.',
  'f.3q': 'Are WhatsApp messages included?', 'f.3a': 'RENDEZVOO prepares and schedules the messages. Sending goes through your own account with an official provider (WhatsApp Business, SMS, email); without credentials, nothing is sent.',
  'f.4q': 'Is my data isolated from other businesses?', 'f.4a': 'Yes. Each business has an independent space, protected by access rules at the database level.',
  'x.h': 'Your booking link, ready in five minutes.', 'foot': '© RENDEZVOO. Made in Dakar.',
  's.cal': 'Pick a date', 's.svc': 'Pick a service', 's.slot': 'Pick a time', 's.done': 'Booking confirmed', 's.dash': 'Dashboard', 's.booked': 'You’re booked.',
  's.date': 'Date', 's.service': 'Service', 's.time': 'Time', 's.bk': 'Bookings', 's.cx': 'Cancellations', 's.ca': 'Declared revenue', 's.new': 'New booking',
  'tr.trial': 'Free {n}-day trial, no credit card.', 'tr.month': '/month', 'tr.start': 'Start the trial', 'pl.starter': ['Business page', 'Online booking', 'Calendar', 'Client management'],
  'pl.pro': ['Everything in Starter', 'Up to 10 staff', 'Advanced notifications', 'Statistics', 'Advanced customisation'], 'pl.business': ['Everything in Pro', 'Unlimited staff', 'Multiple users', 'Multiple locations', 'Exportable reports'],
  'fl.pro': 'Book with…', 'fl.svc': 'Which service?', 'fl.date': 'Which day and time?', 'fl.you': 'Your details', 'fl.ok': 'Appointment confirmed', 'fl.name': 'Name', 'fl.phone': 'Phone', 'fl.confirm': 'Confirm appointment', 'fl.back': 'Back', 'fl.again': 'Start over',
  'fl.okp': 'That is what your client goes through, in seconds. With you, they also get a confirmation and a reminder.', 'fl.step': ['Business', 'Service', 'Date and time', 'Details'], 'fl.none': 'No free slot that day.', 'fl.demo': 'Demo',
});
const L = (k) => { const v = t(k); return v; };
const arr = (k) => { const v = (getLang() === 'en' ? en : fr)[k]; return v; };
// listes (tableaux) : stockees a part car t() renvoie des chaines
const fr = { 'pl.starter': ['Page professionnelle', 'Réservations en ligne', 'Calendrier', 'Gestion des clients'], 'pl.pro': ['Tout Starter', 'Jusqu’à 10 employés', 'Notifications avancées', 'Statistiques', 'Personnalisation avancée'], 'pl.business': ['Tout Pro', 'Employés illimités', 'Multi-utilisateurs', 'Plusieurs établissements', 'Rapports exportables'], 'fl.step': ['Professionnel', 'Prestation', 'Date et heure', 'Coordonnées'] };
const en = { 'pl.starter': ['Business page', 'Online booking', 'Calendar', 'Client management'], 'pl.pro': ['Everything in Starter', 'Up to 10 staff', 'Advanced notifications', 'Statistics', 'Advanced customisation'], 'pl.business': ['Everything in Pro', 'Unlimited staff', 'Multiple users', 'Multiple locations', 'Exportable reports'], 'fl.step': ['Business', 'Service', 'Date and time', 'Details'] };

const METIERS = [
  ['Coiffure', 'Coupe 45 min · Tresses 3 h', 'coiffure'], ['Barbier', 'Coupe 30 min · Barbe 20 min', 'barbier'], ['Institut de beauté', 'Soin visage · Manucure', 'beaute'], ['Spa et bien-être', 'Massage 60 min · Hammam', 'spa'],
  ['Photographe', 'Séance portrait · Mariage', 'photographe'], ['Coach sportif', 'Séance 1 h · Suivi mensuel', 'coach'], ['Consultant', 'Appel 30 min · Atelier', 'consultant'], ['Cabinet professionnel', 'Consultation · Dossier', 'sante'], ['Centre de formation', 'Session · Examen blanc', 'formation'],
];
const METIERS_EN = { 'Coiffure': 'Hair salon', 'Barbier': 'Barber', 'Institut de beauté': 'Beauty salon', 'Spa et bien-être': 'Spa and wellness', 'Photographe': 'Photographer', 'Coach sportif': 'Fitness coach', 'Consultant': 'Consultant', 'Cabinet professionnel': 'Professional practice', 'Centre de formation': 'Training centre' };

function applyStatic() {
  $$('[data-i]').forEach(el => { const v = t(el.dataset.i); if (typeof v === 'string' && v !== el.dataset.i) el.textContent = v; });
  $('#lang').textContent = getLang() === 'en' ? 'FR' : 'EN'; document.title = getLang() === 'en' ? 'RENDEZVOO – Online booking and appointment management' : 'RENDEZVOO – Réservation en ligne et gestion de rendez-vous';
}

// ---------- Metiers
function renderIndex() {
  mount($('#index'), METIERS.map(([n, ex, cat]) => h('li', {}, h('a', { href: '/inscription?category=' + cat }, h('span', { class: 'nm' }, getLang() === 'en' ? METIERS_EN[n] : n), h('span', { class: 'ex' }, ex), h('span', { class: 'ticks', 'aria-hidden': 'true' })))));
}

// ---------- Scene du hero (lecture automatique, pilotable)
function monthGrid(today) {
  const loc = getLang() === 'en' ? 'en-GB' : 'fr-FR'; const y = today.getUTCFullYear(), m = today.getUTCMonth();
  const first = new Date(Date.UTC(y, m, 1)), days = new Date(Date.UTC(y, m + 1, 0)).getUTCDate(); const lead = (first.getUTCDay() + 6) % 7;
  const heads = [...Array(7)].map((_, i) => new Intl.DateTimeFormat(loc, { weekday: 'narrow', timeZone: 'UTC' }).format(new Date(Date.UTC(2024, 0, 1 + i))));
  const cells = []; let pick = null;
  for (let i = 0; i < lead; i++) cells.push(h('span', {}));
  for (let d = 1; d <= days; d++) { const dt = new Date(Date.UTC(y, m, d)); const open = d >= today.getUTCDate() && dt.getUTCDay() !== 0; const el = h('span', { class: open ? 'open' : 'dim' }, d); cells.push(el); if (open && !pick && d >= today.getUTCDate() + 2) pick = el; }
  return { title: new Intl.DateTimeFormat(loc, { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(first), node: h('div', { class: 'cal' }, heads.map(x => h('b', {}, x)), cells), pick };
}
function buildStage() {
  const today = new Date(); const g = monthGrid(today);
  const svc = [['Coupe + soin', 60, 12000], ['Tresses', 180, 25000], ['Brushing', 30, 5000]].map(([n, m, p], i) => h('div', { class: 'opt', 'data-k': i }, h('span', {}, n), h('small', {}, `${dur(m)} · ${money(p)}`)));
  const hours = [['09:00', 'busy'], ['10:00', 'free'], ['11:00', 'busy'], ['12:00', 'free'], ['13:00', 'free'], ['14:30', 'free'], ['15:30', 'busy'], ['16:30', 'free']].map(([x, s]) => h('div', { class: 't ' + s, 'data-h': x }, s === 'free' ? (getLang() === 'en' ? 'Available' : 'Disponible') : '·'));
  const bars = [4, 6, 5, 8, 7, 9, 6, 10, 8, 11, 9, 12].map((v, i, a) => h('i', { class: i === a.length - 1 ? 'hot' : '', style: `height:${v * 8}%` }));
  const newRow = h('div', { class: 'new' }, h('span', {}, L('s.new')), h('span', { class: 'num' }, '14:30'));
  const mark = () => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 64 64'); s.innerHTML = ''; for (const [tag, a] of [['rect', { x: 2, y: 2, width: 60, height: 60 }], ['path', { d: 'M17 34l10 10 21-24' }]]) { const e = document.createElementNS('http://www.w3.org/2000/svg', tag); for (const [k, v] of Object.entries({ ...a, fill: 'none', stroke: tag === 'rect' ? '#0d1b16' : '#2b3cff', 'stroke-width': tag === 'rect' ? 2 : 5, pathLength: 1 })) e.setAttribute(k, v); s.append(e); } return s; };
  const scenes = [
    { title: L('s.cal'), node: h('div', { class: 'scene' }, h('b', { style: 'text-transform:capitalize' }, g.title), g.node), pick: () => g.pick?.classList.add('pick'), reset: () => g.pick?.classList.remove('pick') },
    { title: L('s.svc'), node: h('div', { class: 'scene' }, svc), pick: () => svc[0].classList.add('pick'), reset: () => svc[0].classList.remove('pick') },
    { title: L('s.slot'), node: h('div', { class: 'scene' }, h('div', { class: 'ruler' }, hours)), pick: () => { hours[5].classList.remove('free'); hours[5].classList.add('pick'); hours[5].textContent = '14:30 ✓'; }, reset: () => { hours[5].classList.remove('pick'); hours[5].classList.add('free'); hours[5].textContent = getLang() === 'en' ? 'Available' : 'Disponible'; } },
    { title: L('s.done'), node: h('div', { class: 'scene' }, h('div', { class: 'done-mark' }, mark(), h('h3', {}, L('s.booked')), h('dl', { class: 'kv' }, h('dt', {}, L('s.date')), h('dd', {}, new Intl.DateTimeFormat(getLang() === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(today.getTime() + 3 * 864e5))), h('dt', {}, L('s.service')), h('dd', {}, 'Coupe + soin'), h('dt', {}, L('s.time')), h('dd', { class: 'num' }, '14:30')))) },
    { title: L('s.dash'), node: h('div', { class: 'scene' }, h('div', { class: 'mini-dash' }, h('div', { class: 'kpis' }, h('div', { class: 'kpi' }, h('b', {}, '48'), h('span', {}, L('s.bk'))), h('div', { class: 'kpi' }, h('b', {}, '4 %'), h('span', {}, L('s.cx'))), h('div', { class: 'kpi' }, h('b', {}, '312 k'), h('span', {}, L('s.ca')))), h('div', { class: 'bars', 'aria-hidden': 'true' }, bars),
      h('div', { class: 'rows' }, h('div', {}, h('span', {}, 'Fatou N. · Tresses'), h('span', { class: 'num' }, '10:00')), h('div', {}, h('span', {}, 'Moussa F. · Brushing'), h('span', { class: 'num' }, '12:30')), newRow))), pick: () => newRow.animate([{ opacity: 0, transform: 'translateX(-14px)' }, { opacity: 1, transform: 'none' }], { duration: 600, easing: 'cubic-bezier(.2,.7,.1,1)', fill: 'backwards' }) },
  ];
  return scenes;
}
let stageTimer, stageState;
function initStage() {
  clearTimeout(stageTimer); const body = $('#stage-body'), steps = $('#stage-steps'), title = $('#stage-title'), prog = $('#stage-progress'); const scenes = buildStage();
  mount(body, scenes.map(s => s.node)); mount(steps, scenes.map((s, i) => h('li', {}, h('button', { type: 'button', 'aria-label': `${i + 1}. ${s.title}`, onclick: () => { stageState.paused = false; show(i, true); } }, i + 1))));
  const still = lowPower(); let cur = -1; const DUR = 3800; stageState = { paused: false, visible: true };
  function show(i, user) {
    clearTimeout(stageTimer); cur = i; scenes.forEach((s, k) => { s.node.classList.toggle('on', k === i); if (k !== i) s.reset?.(); });
    $$('button', steps).forEach((b, k) => k === i ? b.setAttribute('aria-current', 'step') : b.removeAttribute('aria-current')); title.textContent = scenes[i].title;
    const sc = scenes[i].node; if (!still) { sc.animate([{ opacity: 0, transform: 'translateY(14px)' }, { opacity: 1, transform: 'none' }], { duration: 520, easing: 'cubic-bezier(.2,.7,.1,1)' }); [...sc.children].forEach((c, k) => c.animate?.([{ opacity: 0 }, { opacity: 1 }], { duration: 400, delay: 80 * k, fill: 'backwards' })); }
    if (still) { scenes[i].pick?.(); prog.style.transform = 'scaleX(1)'; return; }
    prog.getAnimations().forEach(a => a.cancel()); const pa = prog.animate([{ transform: 'scaleX(0)' }, { transform: 'scaleX(1)' }], { duration: DUR, easing: 'linear', fill: 'forwards' });
    stageTimer = setTimeout(() => scenes[i].pick?.(), 1000); pa.onfinish = () => { if (!stageState.paused && stageState.visible) show((cur + 1) % scenes.length); else pa.pause(); };
    stageState.pa = pa; if (stageState.paused) pa.pause();
  }
  show(still ? 2 : 0); const el = $('#stage');
  const pause = (v) => { stageState.paused = v; if (stageState.pa && !still) v ? stageState.pa.pause() : stageState.pa.play(); };
  el.addEventListener('pointerenter', () => pause(true)); el.addEventListener('pointerleave', () => pause(false)); el.addEventListener('focusin', () => pause(true)); el.addEventListener('focusout', () => pause(false));
  new IntersectionObserver(([e]) => { stageState.visible = e.isIntersecting; if (!still && stageState.pa) (e.isIntersecting && !stageState.paused) ? stageState.pa.play() : stageState.pa.pause(); }).observe(el);
}

// ---------- Parcours de reservation interactif (donnees fictives)
const DEMO = [
  { name: 'Maison Teranga', kind: 'Coiffure · Dakar', services: [['Coupe femme', 45, 8000], ['Tresses africaines', 180, 25000], ['Soin profond', 40, 6000]] },
  { name: 'Barber Corniche', kind: 'Barbier · Dakar', services: [['Coupe homme', 30, 3000], ['Barbe', 20, 2000], ['Coupe + barbe', 45, 4500]] },
  { name: 'Spa Baobab', kind: 'Spa · Abidjan', services: [['Massage relaxant', 60, 20000], ['Soin du visage', 45, 15000]] },
];
function demoDays() { const out = []; const d = new Date(); d.setUTCHours(12, 0, 0, 0); while (out.length < 7) { d.setUTCDate(d.getUTCDate() + 1); if (d.getUTCDay() !== 0) out.push(new Date(d)); } return out; }
function demoSlots(pro, svc, day) { const seed = (pro * 31 + svc * 17 + day.getUTCDate() * 13) % 7; const out = []; for (let m = 9 * 60; m <= 17 * 60 + 30; m += 30) { if ((m / 30 + seed) % 3 === 0 || (m / 30 + seed) % 7 === 1) continue; out.push(`${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`); } return out; }
function renderFlow() {
  const root = $('#flow'); const S = { step: 0, pro: null, svc: null, day: null, time: null }; const loc = getLang() === 'en' ? 'en-GB' : 'fr-FR';
  const fmtDay = (d) => new Intl.DateTimeFormat(loc, { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' }).format(d);
  function draw() {
    const names = arr('fl.step'); const questions = [L('fl.pro'), L('fl.svc'), L('fl.date'), L('fl.you'), L('fl.ok')];
    const vals = [S.pro != null ? DEMO[S.pro].name : '', S.svc != null ? DEMO[S.pro].services[S.svc][0] : '', S.time ? `${fmtDay(S.day)}, ${S.time}` : '', ''];
    const recap = h('div', { class: 'flow-recap' }, h('p', { class: 'hint', style: 'color:var(--texte-clair-2)' }, L('fl.demo')), h('div', { class: 'big', 'aria-live': 'polite' }, questions[S.step]), h('ol', {}, names.map((n, i) => h('li', { class: S.step === i ? 'on' : '' }, h('span', {}, n), h('b', {}, vals[i])))));
    const panel = h('div', { class: 'flow-panel' });
    if (S.step === 0) panel.append(h('div', { class: 'choices' }, DEMO.map((p, i) => h('button', { class: 'choice', onclick: () => { S.pro = i; S.step = 1; draw(); } }, h('span', {}, p.name), h('small', {}, p.kind)))));
    if (S.step === 1) panel.append(h('div', { class: 'choices' }, DEMO[S.pro].services.map(([n, m, p], i) => h('button', { class: 'choice', onclick: () => { S.svc = i; S.step = 2; S.day = demoDays()[0]; S.time = null; draw(); } }, h('span', {}, n), h('small', {}, `${dur(m)} · ${money(p)}`)))));
    if (S.step === 2) {
      const days = demoDays(); const slots = demoSlots(S.pro, S.svc, S.day); const slotBox = h('div', { class: 'slots', role: 'group', 'aria-label': L('fl.date') }, slots.length ? slots.map(x => h('button', { class: 'slot', 'aria-pressed': 'false', onclick: () => { S.time = x; S.step = 3; draw(); } }, x)) : h('p', { class: 'hint' }, L('fl.none')));
      panel.append(h('div', { class: 'days' }, days.map(d => h('button', { class: 'day', 'aria-pressed': String(d.getTime() === S.day.getTime()), onclick: () => { S.day = d; draw(); } }, h('small', {}, new Intl.DateTimeFormat(loc, { weekday: 'short', timeZone: 'UTC' }).format(d)), h('b', { class: 'num' }, d.getUTCDate())))), slotBox);
    }
    if (S.step === 3) { const n = h('input', { type: 'text', autocomplete: 'off', placeholder: 'Fatou Ndiaye' }), p = h('input', { type: 'tel', autocomplete: 'off', placeholder: '+221 77 000 00 00' });
      const f = (l, i) => { const id = 'd' + Math.random().toString(36).slice(2, 7); i.id = id; i.classList.add('input'); return h('div', { class: 'field' }, h('label', { for: id }, l), i); };
      panel.append(f(L('fl.name'), n), f(L('fl.phone'), p), h('button', { class: 'btn cobalt', onclick: () => { S.step = 4; draw(); } }, L('fl.confirm'))); }
    if (S.step === 4) panel.append(h('p', { class: 'serif' }, L('fl.okp')), h('dl', { class: 'kv' }, h('dt', {}, L('s.service')), h('dd', {}, DEMO[S.pro].services[S.svc][0]), h('dt', {}, L('s.date')), h('dd', {}, `${fmtDay(S.day)}, ${S.time}`)), h('a', { class: 'btn cobalt', href: '/inscription' }, L('cta.create')));
    if (S.step > 0) panel.append(h('button', { class: 'link', style: 'justify-self:start', onclick: () => { if (S.step === 4) Object.assign(S, { step: 0, pro: null, svc: null, day: null, time: null }); else S.step--; draw(); } }, S.step === 4 ? L('fl.again') : '← ' + L('fl.back')));
    mount(root, recap, panel);
  }
  draw();
}

// ---------- Apercu du tableau de bord, plans, fuseaux
function renderDash() {
  const bars = [3, 5, 4, 7, 6, 8, 5, 9, 7, 10, 8, 11, 9, 12, 10].map((v, i, a) => h('i', { class: i === a.length - 1 ? 'hot' : '', style: `height:${v * 8}%` }));
  mount($('#dash-art'), h('div', { class: 'dash-side' }, [1, 2, 3, 4, 5, 6, 7].map(() => h('i'))), h('div', { class: 'dash-main' },
    h('div', { class: 'kpis' }, h('div', { class: 'kpi' }, h('b', {}, '48'), h('span', {}, L('s.bk'))), h('div', { class: 'kpi' }, h('b', {}, '4 %'), h('span', {}, L('s.cx'))), h('div', { class: 'kpi' }, h('b', {}, '312 k'), h('span', {}, L('s.ca')))),
    h('div', {}, h('h4', {}, '30 j'), h('div', { class: 'bars', 'aria-hidden': 'true', style: 'height:6rem' }, bars)),
    h('div', {}, h('h4', {}, getLang() === 'en' ? 'Upcoming' : 'À venir'), h('div', { class: 'rows' }, [['Fatou N.', 'Tresses', '10:00'], ['Moussa F.', 'Coupe', '12:30'], ['Aminata S.', 'Soin profond', '14:30'], ['Cheikh B.', 'Brushing', '16:00']].map(r => h('div', {}, h('span', {}, r[0] + ' · ' + r[1]), h('span', { class: 'num' }, r[2])))))));
}
async function renderPlans() {
  let data; try { data = await api('GET', '/api/public/plans'); } catch { data = { plans: [{ code: 'starter', label: 'Starter', price_xof: 5000 }, { code: 'pro', label: 'Pro', price_xof: 10000 }, { code: 'business', label: 'Business', price_xof: 20000 }], trial_days: 14 }; }
  $('#trial-line').textContent = t('tr.trial', { n: data.trial_days });
  mount($('#plans'), data.plans.map(p => h('article', { class: 'plan' + (p.code === 'pro' ? ' feat' : '') }, h('h3', { class: 'nm' }, p.label), h('p', { class: 'px' }, money(p.price_xof), ' ', h('small', {}, t('tr.month'))),
    h('ul', {}, arr('pl.' + p.code).map(x => h('li', {}, icon('check'), x))), h('a', { class: 'btn', href: '/inscription?plan=' + p.code, 'data-magnetic': '' }, t('tr.start')))));
  initMotion.refresh?.();
}
function renderZones() {
  const c = [['Dakar', 'UTC+0 · FCFA XOF', 14], ['Abidjan', 'UTC+0 · FCFA XOF', 30], ['Lomé', 'UTC+0 · FCFA XOF', 46], ['Cotonou', 'UTC+1 · FCFA XOF', 64], ['Douala', 'UTC+1 · FCFA XAF', 80], ['Paris', 'UTC+1/+2 · EUR', 94]];
  mount($('#zones'), h('div', { class: 'strip plx', 'data-plx-x': '-0.08' }), c.map(([n, s, x]) => h('div', { class: 'city', style: `left:${x}%` }, n, h('small', {}, s))));
}

function renderAll() { applyStatic(); renderIndex(); initStage(); renderFlow(); renderDash(); renderPlans(); renderZones(); splitHeadings(); }

initLang(); renderAll();
$('#lang').addEventListener('click', () => { setLang(getLang() === 'en' ? 'fr' : 'en'); $$('h2.split').forEach(x => { x.classList.remove('split', 'in'); }); renderAll(); initMotion.refresh?.(); });
initMotion();
