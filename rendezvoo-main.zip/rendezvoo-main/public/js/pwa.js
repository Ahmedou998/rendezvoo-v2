// Enregistrement du service worker + invitation a installer l'application
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  addEventListener('load', () => navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {}));
}
let deferred = null;
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; document.dispatchEvent(new CustomEvent('rv:installable')); });
addEventListener('appinstalled', () => { deferred = null; document.dispatchEvent(new CustomEvent('rv:installed')); });
export const pwa = {
  standalone,
  canPrompt: () => !!deferred,
  isIos: () => /iphone|ipad|ipod/i.test(navigator.userAgent) && !standalone(),
  async install() { if (!deferred) return false; deferred.prompt(); const r = await deferred.userChoice; deferred = null; return r.outcome === 'accepted'; },
};
