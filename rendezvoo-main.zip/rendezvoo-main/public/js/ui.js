// Utilitaires interface partages : DOM, API, i18n, formats, modales, icones. Aucune dependance.
export const h = (tag, attrs = {}, ...kids) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'html') throw new Error('html interdit');            // pas d'innerHTML : protection XSS par construction
    else if (v === true) el.setAttribute(k, ''); else el.setAttribute(k, v);
  }
  for (const k of kids.flat(Infinity)) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
};
export const $ = (s, r = document) => r.querySelector(s); export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const clear = (el) => { while (el.firstChild) el.firstChild.remove(); return el; };
export const mount = (el, ...kids) => { clear(el).append(...kids.flat(Infinity).filter(Boolean)); return el; };

export async function api(method, path, body, headers = {}) {
  const r = await fetch(path, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  const ct = r.headers.get('content-type') || ''; const data = ct.includes('json') ? await r.json().catch(() => ({})) : await r.text();
  if (!r.ok) { const e = new Error(data.error || 'error'); e.code = data.error || 'error'; e.status = r.status; e.data = data; throw e; }
  return data;
}

// ---- i18n (FR par defaut, EN disponible)
const dict = { fr: {}, en: {} }; let lang = 'fr';
export function initLang() { let s = null; try { s = localStorage.getItem('rv_lang'); } catch {} lang = s === 'en' || s === 'fr' ? s : ((navigator.language || 'fr').toLowerCase().startsWith('en') ? 'en' : 'fr'); document.documentElement.lang = lang; return lang; }
export const getLang = () => lang;
export function setLang(l) { lang = l; try { localStorage.setItem('rv_lang', l); } catch {} document.documentElement.lang = l; }
export const addDict = (fr, en) => { Object.assign(dict.fr, fr); Object.assign(dict.en, en); };
export const t = (k, vars = {}) => (dict[lang][k] ?? dict.fr[k] ?? k).replace(/\{(\w+)\}/g, (_, v) => vars[v] ?? '');
addDict({
  'e.slot_unavailable': 'Ce créneau vient d’être pris. Choisissez une autre heure.', 'e.rate_limited': 'Trop de tentatives. Réessayez dans une minute.', 'e.invalid_phone': 'Entrez un numéro valide, avec l’indicatif (ex. +221 77 000 00 00).',
  'e.invalid_name': 'Entrez un nom d’au moins 2 caractères.', 'e.invalid_email': 'Cette adresse e-mail n’est pas valide.', 'e.too_late_to_cancel': 'Le délai d’annulation ({hours} h avant le rendez-vous) est dépassé. Contactez le professionnel.',
  'e.not_found': 'Introuvable.', 'e.subscription_inactive': 'Ce professionnel ne prend plus de réservations en ligne pour le moment.', 'e.org_unavailable': 'Cette page n’est plus disponible.',
  'e.unauthorized': 'Connectez-vous pour continuer.', 'e.invalid_credentials': 'E-mail ou mot de passe incorrect.', 'e.email_taken': 'Un compte existe déjà avec cet e-mail.', 'e.slug_taken': 'Ce lien est déjà pris. Essayez un autre nom.',
  'e.invalid_slug': 'Le lien doit faire 3 à 40 caractères : lettres, chiffres et tirets.', 'e.weak_password': 'Le mot de passe doit faire au moins 8 caractères.', 'e.plan_required': 'Cette fonction demande une formule supérieure.',
  'e.staff_limit_reached': 'Votre formule est limitée à {max} employé(s). Passez à une formule supérieure.', 'e.forbidden': 'Vous n’avez pas la permission de faire cela.', 'e.invalid_service': 'Vérifiez le nom, la durée et le prix.',
  'e.invalid_hours': 'Vérifiez les horaires : la fin doit être après le début.', 'e.too_many_staff_for_plan': 'Réduisez d’abord le nombre d’employés actifs ({max} maximum).', 'e.payment_provider_not_configured': 'Aucun prestataire de paiement n’est configuré.',
  'e.error': 'Une erreur est survenue. Réessayez.', 'e.server_error': 'Le service rencontre un problème. Réessayez dans un instant.', 'e.bad_origin': 'Requête refusée.', 'e.invalid_date': 'Date invalide.',
  'e.not_completed': 'Vous pourrez laisser un avis après le rendez-vous.', 'e.already_reviewed': 'Vous avez déjà laissé un avis.', 'e.message_too_short': 'Décrivez votre problème en quelques mots de plus.',
}, {
  'e.slot_unavailable': 'That slot was just taken. Please pick another time.', 'e.rate_limited': 'Too many attempts. Try again in a minute.', 'e.invalid_phone': 'Enter a valid number with country code (e.g. +221 77 000 00 00).',
  'e.invalid_name': 'Enter a name with at least 2 characters.', 'e.invalid_email': 'This email address is not valid.', 'e.too_late_to_cancel': 'The cancellation window ({hours} h before the appointment) has passed. Please contact the business.',
  'e.not_found': 'Not found.', 'e.subscription_inactive': 'This business is not taking online bookings right now.', 'e.org_unavailable': 'This page is no longer available.',
  'e.unauthorized': 'Sign in to continue.', 'e.invalid_credentials': 'Incorrect email or password.', 'e.email_taken': 'An account already exists with this email.', 'e.slug_taken': 'This link is taken. Try another name.',
  'e.invalid_slug': 'The link must be 3–40 characters: letters, digits and hyphens.', 'e.weak_password': 'Password must be at least 8 characters.', 'e.error': 'Something went wrong. Try again.', 'e.server_error': 'The service has a problem. Try again shortly.',
  'e.not_completed': 'You can leave a review after the appointment.', 'e.already_reviewed': 'You already left a review.', 'e.message_too_short': 'Please describe the issue in a few more words.', 'e.invalid_date': 'Invalid date.',
});
export const errMsg = (e) => t('e.' + (e.code || 'error'), e.data || {});

// ---- Formats
export const money = (n, cur = 'XOF') => { if (cur === 'XOF' || cur === 'XAF') return new Intl.NumberFormat(lang === 'en' ? 'en-GB' : 'fr-FR').format(n).replace(/\u202f|\u00a0/g, '\u00a0') + '\u00a0FCFA'; try { return new Intl.NumberFormat(lang === 'en' ? 'en-GB' : 'fr-FR', { style: 'currency', currency: cur, maximumFractionDigits: cur === 'EUR' ? 2 : 0 }).format(cur === 'EUR' ? n / 100 : n).replace(/ | /g, ' '); } catch { return n + ' ' + cur; } };
export const dateLong = (iso) => new Intl.DateTimeFormat(lang === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' }).format(new Date(iso + 'T00:00:00Z'));
export const dateShort = (iso) => new Intl.DateTimeFormat(lang === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }).format(new Date(iso + 'T00:00:00Z'));
export const todayIn = (tz) => new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date());
export const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
export const dur = (m) => m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? String(m % 60).padStart(2, '0') : ''}` : `${m} min`;

// ---- Icones
const P = { calendar: 'M3 6h18v15H3zM3 10h18M8 3v4M16 3v4', users: 'M16 20v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M9.5 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7M21 20v-1a4 4 0 0 0-3-3.9M16 4.2a3.5 3.5 0 0 1 0 6.6',
  list: 'M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01', scissors: 'M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12', clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 7v5l3 2',
  card: 'M2 5h20v14H2zM2 10h20', bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0', chart: 'M3 3v18h18M7 15l4-4 3 3 5-6', gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1',
  home: 'M3 11 12 3l9 8M5 10v10h14V10', plus: 'M12 5v14M5 12h14', x: 'M18 6 6 18M6 6l12 12', check: 'M20 6 9 17l-5-5', left: 'M15 18l-6-6 6-6', right: 'M9 18l6-6-6-6', menu: 'M3 7h18M3 12h18M3 17h18', out: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  link: 'M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7', pin: 'M12 22s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12M12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5', star: 'M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10', file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6', flag: 'M4 22V4M4 4h13l-2 4 2 4H4', tag: 'M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8M7.5 7.5h.01', down: 'M6 9l6 6 6-6', share: 'M4 12v8h16v-8M12 3v13M7 8l5-5 5 5' };
export const icon = (n) => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'icon'); s.setAttribute('aria-hidden', 'true'); const p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', P[n] || ''); s.append(p); return s; };

// ---- Toast / modale
export function toast(msg, bad = false) {
  let z = $('.toast-zone'); if (!z) { z = h('div', { class: 'toast-zone', role: 'status', 'aria-live': 'polite' }); document.body.append(z); }
  const el = h('div', { class: 'toast' + (bad ? ' bad' : '') }, msg); z.append(el); setTimeout(() => el.remove(), bad ? 6000 : 3500);
}
export function modal(title, body, { onClose } = {}) {
  const prev = document.activeElement; const back = h('div', { class: 'modal-back' });
  const close = () => { back.remove(); document.removeEventListener('keydown', key); prev?.focus?.(); onClose?.(); };
  const key = (e) => { if (e.key === 'Escape') close(); };
  const box = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, h('div', { class: 'row', style: 'justify-content:space-between' }, h('h2', {}, title), h('button', { class: 'btn ghost small', 'aria-label': 'Fermer', onclick: close }, icon('x'))), body);
  back.append(box); back.addEventListener('mousedown', (e) => { if (e.target === back) close(); }); document.addEventListener('keydown', key); document.body.append(back);
  (box.querySelector('input,select,textarea,button.btn:not(.ghost)') || box).focus?.(); return { close, box };
}
export const field = (label, input, hint) => { const id = 'f' + Math.random().toString(36).slice(2, 8); input.id = id; input.classList.add('input'); return h('div', { class: 'field' }, h('label', { for: id }, label), input, hint && h('span', { class: 'hint' }, hint)); };
export const lowPower = () => matchMedia('(prefers-reduced-motion: reduce)').matches || (navigator.hardwareConcurrency || 8) <= 2 || (navigator.deviceMemory || 8) <= 1 || navigator.connection?.saveData === true;
